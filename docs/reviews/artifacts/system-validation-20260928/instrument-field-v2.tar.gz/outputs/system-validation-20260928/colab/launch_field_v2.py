"""Launch the two frozen corrected comparisons sequentially on the task-owned L4."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/content/oa-validation-v2')
delta = json.loads((root / 'field-v2-runner-delta.json').read_text())
proof = json.loads((root / 'field-v2-mock-proof.json').read_text())
runner = root / delta['runner_relative_path']
assert hashlib.sha256(runner.read_bytes()).hexdigest() == delta['runner_sha256'] == delta['remote_verified_sha256'] == proof['runner_sha256']
assert proof['status'] == 'passed' and proof['completed'] == 192
for path, item in json.loads((root / 'capsule-files.json').read_text())['files'].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == item['sha256'], path
assert not (root / 'field-v2-pid.json').exists(), 'already launched; inspect instead of duplicating'
for name in ('calibration', 'qwen-calibration'):
    calibration = json.loads((root / (name + '-status.json')).read_text())
    assert calibration['status'] == 'completed' and calibration['exit_code'] == 0
common = [sys.executable, str(runner), '--max-tokens', '640', '--table-setup-module',
          str(root / 'outputs/system-validation-20260928/cohort/table_setup.py'),
          '--timeout-seconds', '7200', '--cell-timeout-seconds', '600']
jobs = [
    {'name': 'gemma-field-v2', 'count': 192, 'output': 'outputs/gemma-field-v2-192',
     'command': common + ['--model-config', str(root / 'configs/model.yaml'), '--output-dir', str(root / 'outputs/gemma-field-v2-192')]},
    {'name': 'qwen-field-v2', 'count': 96, 'output': 'outputs/qwen-field-v2-96',
     'command': common + ['--model-config', str(root / 'configs/model_qwen35_27b_diagnostic.yaml'),
                         '--arms', 'retrieval_neither,retrieval_both', '--output-dir', str(root / 'outputs/qwen-field-v2-96')]},
]
for job in jobs:
    assert not (root / job['output']).exists()
env = os.environ.copy()
env.update(HF_HOME='/content/oa-validation-hf', HF_HUB_CACHE='/content/oa-validation-hf/hub',
           HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', AGRONOMY_AGENT_PRIVATE_KNOWLEDGE='disabled',
           AGRONOMY_AGENT_MODEL_BACKEND='mlx', PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(root / 'src'))
driver = root / 'field_v2_driver.py'
driver.write_text('''import json, os, signal, subprocess, time
from pathlib import Path
jobs = ''' + repr(jobs) + '''
for job in jobs:
    started = time.time()
    status = dict(status='running', started_epoch=started, command=job['command'])
    target = Path(job['name'] + '-status.json')
    target.write_text(json.dumps(status))
    process = subprocess.Popen(job['command'], start_new_session=True)
    status['runner_pid'] = process.pid
    target.write_text(json.dumps(status))
    try:
        code = process.wait(timeout=7260)
        status['exit_code'] = code
        if code != 0:
            status['status'] = 'failed'
        else:
            rows = [json.loads(line) for line in (Path(job['output']) / 'ledger.jsonl').read_text().splitlines()]
            status['observed_cells'] = len(rows)
            status['failed_cells'] = [row['cell_id'] for row in rows if row['status'] != 'completed_execution']
            status['status'] = 'completed' if len(rows) == job['count'] and not status['failed_cells'] else 'failed_cell_gate'
    except subprocess.TimeoutExpired:
        status['status'] = 'driver_timeout'
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            pass
        # The runner can exit before a grandchild; kill any surviving owned group.
        try:
            os.killpg(process.pid, 0)
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=10)
    except Exception as exc:
        status.update(status='failed_evidence_gate', error_type=type(exc).__name__, error=str(exc)[:1000])
    finally:
        status['seconds'] = time.time() - started
        target.write_text(json.dumps(status))
        print(json.dumps(status), flush=True)
    if status['status'] != 'completed':
        break
''')
log = (root / 'field-v2-driver.log').open('w')
process = subprocess.Popen([sys.executable, str(driver)], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
receipt = {'pid': process.pid, 'jobs': jobs, 'runner_sha256': delta['runner_sha256'],
           'base_capsule_sha256': delta['base_capsule_sha256'],
           'forecast_minutes': [40, 80], 'forecast_increment_CU_at_1_54_per_hour': [1.03, 2.05],
           'bounds': 'Each model job 7200 seconds, each cell 600 seconds. Stop on failed model job.'}
(root / 'field-v2-pid.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
