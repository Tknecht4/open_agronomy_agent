"""Reconcile blind grades with exact run bytes; retain missingness and provenance."""
import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

parser = argparse.ArgumentParser()
for name in ('packet', 'out'):
    parser.add_argument('--' + name, type=Path, required=True)
for name in ('run', 'a', 'b', 'adjudicated'):
    parser.add_argument('--' + name, type=Path, action='append', required=True)
parser.add_argument('--clearances', type=Path)
args = parser.parse_args()
base = Path(__file__).resolve().parents[1]
keys = ('task_completion', 'material_error', 'unnecessary_refusal')
stage_names = ('draft', 'post_verification', 'final')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def readmany(paths):
    out = {}
    for path in paths:
        for row in json.loads(path.read_text()):
            assert row['blind_id'] not in out, row['blind_id']
            out[row['blind_id']] = row
    return out

A, B, J = (readmany(paths) for paths in (args.a, args.b, args.adjudicated))
packet_list = json.loads((args.packet / 'blind_packet.json').read_text())
packet = {x['blind_id']: x for x in packet_list}
assert len(packet) == len(packet_list), 'duplicate packet IDs'
mapping = json.loads((args.packet / 'private_mapping.json').read_text())
failures = json.loads((args.packet / 'failed_attempts.json').read_text())
assert packet.keys() <= A.keys() and packet.keys() <= B.keys()
caseinfo = {x['id']: x for x in json.loads((base / 'runner/grading_local.json').read_text())['cases']}
runtime = {x['id']: x for x in json.loads((base / 'runner/runtime_cases.json').read_text())['cases']}
clearance_receipt = json.loads(args.clearances.read_text()) if args.clearances else None
clearances = {x['blind_id']: x for x in clearance_receipt['clearances']} if clearance_receipt else {}
for c in clearances.values():
    assert c['status'] == 'verified' and c['reason']
    assert sha(base / c['evidence_path']) == c['evidence_sha256']

grades, agreement, needed = {}, Counter(), []
for bid, item in packet.items():
    a, b = A[bid], B[bid]
    for g in (a, b, J.get(bid, a)):
        assert all(type(g[k]) is bool for k in (*keys, 'source_check_needed'))
        assert all(c['met'] is None or type(c['met']) is bool for c in g['completion_criteria'])
        assert [c['criterion'] for c in g['completion_criteria']] == item['rubric']['task_completion']
        assert [c['index'] for c in g['completion_criteria']] == list(range(len(g['completion_criteria'])))
    differences = [k for k in keys if a[k] != b[k]]
    for k in keys:
        agreement[k] += a[k] == b[k]
    if differences or a['source_check_needed'] or b['source_check_needed']:
        needed.append(bid)
        assert bid in J, bid
    choice = dict(J.get(bid, a))
    # Original triage allowed null for unknown/not-applicable. A selected positive
    # score needs explicit resolved criteria; negatives need an actual failed one.
    if choice['task_completion']:
        assert all(c['met'] is True for c in choice['completion_criteria']), 'positive completion needs resolved criteria'
    else:
        assert any(c['met'] is False for c in choice['completion_criteria']) or choice['source_check_needed'], 'negative completion needs a failed criterion or explicit source uncertainty'
    if bid in clearances:
        assert choice['source_check_needed'], 'clearance must resolve an actual open source check'
        choice.update(source_check_needed=False, original_source_check_needed=True,
                      source_check_clearance=clearances[bid])
    grades[bid] = {**choice, 'decision_basis': 'source_adjudication' if bid in J else 'two_grader_metric_agreement'}

# Bind every completed stage mapping to its original ledger and answer bytes.
expected_mapping, expected_failed = {}, []
plans, statuses, run_inputs = {}, {}, []
attempt_counts = defaultdict(Counter)
for run in args.run:
    name = run.name
    assert name not in plans, 'ambiguous run directory basename'
    plan = json.loads((run / 'cell_plan.json').read_text())
    rows = [json.loads(x) for x in (run / 'ledger.jsonl').read_text().splitlines() if x.strip()]
    manifest = json.loads((run / 'run_manifest.json').read_text())
    assert canonical_sha(plan) == manifest['cells_sha256'] and len(plan) == manifest['cell_count']
    run_basis = {k: v for k, v in manifest.items() if k not in {'run_sha256', 'runtime_path', 'runtime_digest_path', 'model_config_path', 'rag_source_path', 'rag_profile_path', 'table_setup_module_path'}}
    assert canonical_sha(run_basis) == manifest['run_sha256'], 'manifest identity drift'
    assert manifest['runtime_sha256'] == sha(base / 'runner/runtime_cases.json')
    assert len({x['cell_id'] for x in plan}) == len(plan)
    assert len(rows) <= len(plan)
    plans[name] = plan
    statuses[name] = {x['cell_id']: x['status'] for x in rows}
    assert len(statuses[name]) == len(rows)
    for i, row in enumerate(rows):
        assert row['cell_index'] == i
        assert all(row[k] == plan[i][k] for k in ('cell_id', 'case_id', 'arm', 'trial'))
        assert row['run_sha256'] == manifest['run_sha256']
        if row['status'] != 'completed_execution':
            expected_failed.append({'run': name, **row})
            continue
        execution_path = run / row['cell_result']
        execution = json.loads(execution_path.read_text())['execution']
        stages = execution['turn']['trace']['metadata']['answer_stages']
        for stage in stage_names:
            text = stages[stage]['text']
            digest = hashlib.sha256(text.encode()).hexdigest()
            assert digest == stages[stage]['sha256']
            bid = hashlib.sha256(('blind-v1\0' + row['case_id'] + '\0' + digest).encode()).hexdigest()[:16]
            assert packet[bid]['answer'] == text
            case = runtime[row['case_id']]
            assert packet[bid]['question'] == case['question']
            assert packet[bid]['supplied_field_context'] == case['field_context']
            assert packet[bid]['prior_history'] == case['history']
            gold = caseinfo[row['case_id']]
            assert packet[bid]['rubric'] == gold['rubric']
            assert packet[bid]['reference_numeric'] == gold['reference_numeric']
            assert packet[bid]['source_availability'] == gold['decisive_evidence']
            expected_mapping[(name, row['cell_id'], stage)] = {
                'blind_id': bid, 'run': name, 'case_id': row['case_id'], 'cell_id': row['cell_id'],
                'trial': row['trial'], 'arm': row['arm'], 'stage': stage, 'answer_sha256': digest}
    for cell in plan:
        status = statuses[name].get(cell['cell_id'])
        for label in [('arm', name, cell['arm']), ('stratum', name, cell['arm'], caseinfo[cell['case_id']]['stratum'])]:
            c = attempt_counts[label]
            c['planned'] += 1
            c['attempted'] += status is not None
            c['completed'] += status == 'completed_execution'
            c['failed_attempts'] += status is not None and status != 'completed_execution'
            c['not_attempted'] += status is None
    run_inputs.append({'run': name, 'run_sha256': manifest['run_sha256'],
                       'manifest_sha256': sha(run / 'run_manifest.json'),
                       'ledger_sha256': sha(run / 'ledger.jsonl'), 'plan_sha256': sha(run / 'cell_plan.json')})
assert expected_failed == failures, 'failure denominator drift'
assert len(mapping) == len(expected_mapping), 'missing or duplicate stage mappings'
seen = set()
for m in mapping:
    key = (m['run'], m['cell_id'], m['stage'])
    assert key not in seen and m == expected_mapping[key], key
    seen.add(key)
assert {m['blind_id'] for m in mapping} == set(packet), 'unused or missing packet item'

by, cells = defaultdict(Counter), defaultdict(dict)
for m in mapping:
    g = grades[m['blind_id']]
    row = {**m, **{k: g[k] for k in keys}, 'source_check_unresolved': g['source_check_needed']}
    cells[(m['run'], m['cell_id'])][m['stage']] = row
    for label in [('arm', m['run'], m['arm'], m['stage']), ('stratum', m['run'], m['arm'], caseinfo[m['case_id']]['stratum'], m['stage'])]:
        by[label]['completed_observations'] += 1
        for k in keys:
            by[label][k] += g[k]
        by[label]['source_check_unresolved'] += g['source_check_needed']
        by[label]['task_completion_without_open_source_check'] += g['task_completion'] and not g['source_check_needed']
transitions, case_rows = defaultdict(Counter), []
for (run, cell), stages in cells.items():
    assert set(stages) == set(stage_names)
    for left, right in [('draft', 'post_verification'), ('post_verification', 'final'), ('draft', 'final')]:
        a, b = stages[left], stages[right]
        c = transitions[(run, a['arm'], left, right)]
        c['completed_cells'] += 1
        for k in keys:
            if a[k] != b[k]:
                c[k + ('_gained' if b[k] else '_lost')] += 1
    case_rows.append({'run': run, 'cell_id': cell, 'case_id': stages['final']['case_id'],
                      'trial': stages['final']['trial'], 'arm': stages['final']['arm'],
                      'stratum': caseinfo[stages['final']['case_id']]['stratum'], 'stages': stages})
matched = defaultdict(dict)
for row in case_rows:
    matched[(row['run'], row['case_id'], row['trial'])][row['arm']] = row
planned_pairs = defaultdict(dict)
for run, plan in plans.items():
    for cell in plan:
        planned_pairs[(run, cell['case_id'], cell['trial'])][cell['arm']] = cell['cell_id']
contrasts = defaultdict(Counter)
for (run, cid, trial), planned in planned_pairs.items():
    arms = matched[(run, cid, trial)]
    for left, right in [('retrieval_neither', 'retrieval_both'), ('retrieval_neither', 'retrieval_document_only'), ('retrieval_neither', 'retrieval_graph_only'), ('retrieval_document_only', 'retrieval_both'), ('retrieval_graph_only', 'retrieval_both')]:
        if left not in planned or right not in planned:
            continue
        for stage in stage_names:
            c = contrasts[(run, left, right, stage)]
            c['planned_pairs'] += 1
            c['both_attempted_pairs'] += all(planned[k] in statuses[run] for k in (left, right))
            if left not in arms or right not in arms:
                c['incomplete_pairs'] += 1
                continue
            c['completed_pairs'] += 1
            a, b = arms[left]['stages'][stage], arms[right]['stages'][stage]
            for k in keys:
                if a[k] != b[k]:
                    c[k + ('_gained' if b[k] else '_lost')] += 1

def records(table, fields, kind=None):
    return [dict(zip(fields, k), **v) for k, v in table.items() if kind is None or k[0] == kind]

result = {
    'schema_version': 'system_validation_quality_v2',
    'eligibility': 'automated_internal_development_triage_not_agronomic_validation',
    'score_status': 'provisional_where_source_check_unresolved',
    'missingness_policy': 'No failure or unattempted cell is treated as correct; quality is unknown there. Report all-attempt and planned denominators beside completed-case counts. Repeated trials are not independent cases.',
    'unique_graded_answers': len(packet), 'metric_agreement': dict(agreement),
    'adjudication_required': len(needed), 'unresolved_source_checks': sum(g['source_check_needed'] for g in grades.values()),
    'source_clearances': len(clearances), 'completed_cells': len(cells), 'failed_attempts': failures,
    'arm_attempt_counts': records(attempt_counts, ('group', 'run', 'arm'), 'arm'),
    'stratum_attempt_counts': records(attempt_counts, ('group', 'run', 'arm', 'stratum'), 'stratum'),
    'arm_stages': records(by, ('group', 'run', 'arm', 'stage'), 'arm'),
    'stratum_stages': records(by, ('group', 'run', 'arm', 'stratum', 'stage'), 'stratum'),
    'stage_transitions': records(transitions, ('run', 'arm', 'from', 'to')),
    'matched_contrasts': records(contrasts, ('run', 'from', 'to', 'stage')),
    'case_rows': case_rows, 'run_inputs': run_inputs,
    'grade_inputs': [{'path': str(f.resolve().relative_to(base)), 'sha256': sha(f)} for f in args.a + args.b + args.adjudicated],
    'clearance_input': {'path': str(args.clearances.resolve().relative_to(base)), 'sha256': sha(args.clearances)} if args.clearances else None,
}
args.out.mkdir(exist_ok=False)
(args.out / 'quality-summary.json').write_text(json.dumps(result, indent=2) + '\n')
(args.out / 'reconciled-grades.json').write_text(json.dumps(list(grades.values()), indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('completed_cells', 'failed_attempts', 'unique_graded_answers', 'metric_agreement', 'adjudication_required', 'unresolved_source_checks', 'arm_attempt_counts', 'arm_stages')}))
