from pathlib import Path
import importlib.util, json, hashlib, tarfile, subprocess
root=Path.cwd()
out=root/'outputs/system-validation-20260928/colab'
spec=importlib.util.spec_from_file_location('pub',root/'scripts/build_public_repository.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
manifest=json.loads((root/'configs/public_repository_manifest.json').read_text())
allowed=mod._collect(manifest)
prefixes=('src/','configs/','data/seed/','data/derived/rag/offline_agronomy/active/')
exact={'scripts/run_portable_harness_diagnostic.py','data/manifests/runtime_corpus_policy.json','data/manifests/canada_agronomy_sources.json','data/derived/rag/offline_agronomy/us_nrcs/store_manifest.json','data/derived/rag/offline_agronomy/us_nrcs/bm25_statistics_index.json','data/derived/rag/soilwise_knowledge_graph.json','data/derived/rag/soilwise_knowledge_graph.manifest.json','data/eval/field_data_pilot_v1/manifest.json','data/eval/field_data_pilot_v1/fixtures/akron-01.csv','pyproject.toml','LICENSE','requirements-container.txt'}
paths=[p for p in allowed if p.relative_to(root).as_posix().startswith(prefixes) or p.relative_to(root).as_posix() in exact]
missing=exact-{p.relative_to(root).as_posix() for p in paths}; assert not missing,missing
mod._validate_scope(paths,manifest)
added=('runner/run_retrieval_2x2.py','runner/runtime_cases.json','runner/runtime_cases.json.sha256','runner/profiles/model-1024.yaml','cohort/table_setup.py')
paths += [root/'outputs/system-validation-20260928'/p for p in added]
assert all(p.is_file() for p in paths)
files={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
diff=subprocess.check_output(['git','diff','--binary'])
(out/'candidate-v2.patch').write_bytes(diff)
receipt={'schema_version':'system_validation_capsule.v1','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tracked_diff_sha256':hashlib.sha256(diff).hexdigest(),'new_public_source_paths':subprocess.check_output(['git','ls-files','--others','--exclude-standard','src'],text=True).splitlines(),'dirty_paths':subprocess.check_output(['git','diff','--name-only'],text=True).splitlines(),'files':files,'added_diagnostic_files':list(added),'excluded':'Private knowledge, unrelated output history, gold/rubrics, SPCC, credentials, model weights, and inactive US NRCS shards excluded. Only the frozen no-MLRA cohort and two calibration prompts are supported.'}
(out/'capsule-files-v2.json').write_text(json.dumps(receipt,indent=2)+'\n')
archive=out/'capsule-v2.tar.gz'
assert not archive.exists(), 'immutable capsule already exists'
with tarfile.open(archive,'w:gz') as tar:
 for p in paths: tar.add(p,arcname=p.relative_to(root),recursive=False)
 tar.add(out/'capsule-files-v2.json',arcname='capsule-files.json')
result={'files':len(paths),'uncompressed_bytes':sum(x['bytes'] for x in files.values()),'archive_bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(out/'capsule-summary-v2.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result))
