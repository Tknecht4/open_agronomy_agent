"""Publish a path-normalized JSON derivative with an explicit byte receipt."""
import argparse, hashlib, json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('source', type=Path)
p.add_argument('destination', type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parents[3]
original = a.source.read_bytes()
count = 0

def normalize(value):
    global count
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items()}
    if isinstance(value, list):
        return [normalize(v) for v in value]
    if isinstance(value, str) and str(root) + '/' in value:
        count += value.count(str(root) + '/')
        return value.replace(str(root) + '/', '')
    return value

output = (json.dumps(normalize(json.loads(original)), indent=2, sort_keys=True) + '\n').encode()
assert b'/Users/' not in output and b'/private/var/' not in output and b'BEGIN PRIVATE KEY' not in output
a.destination.write_bytes(output)
receipt = {'source_file': a.source.relative_to(root).as_posix() if a.source.is_absolute() else a.source.as_posix(),
           'source_sha256': hashlib.sha256(original).hexdigest(), 'public_file': a.destination.name,
           'public_sha256': hashlib.sha256(output).hexdigest(),
           'derivation': 'JSON sorted/indented; local repository prefix removed from path strings only',
           'path_prefix_replacements': count}
a.destination.with_suffix('.publication.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
