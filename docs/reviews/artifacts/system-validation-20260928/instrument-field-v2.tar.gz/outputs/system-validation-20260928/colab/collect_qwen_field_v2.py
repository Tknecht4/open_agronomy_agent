import hashlib, json, tarfile
from pathlib import Path
root = Path('/content/oa-validation-v2')
name = 'qwen-field-v2'
status = json.loads((root / (name + '-status.json')).read_text())
assert status['status'] != 'running'
archive = Path('/content/system-validation-' + name + '.tar.gz')
assert not archive.exists(), 'archive is immutable; download the existing one'
paths = [root / 'outputs/qwen-field-v2-96', root / 'outputs/qwen-calibration640']
paths += [root / file for file in ('qwen-field-v2-status.json', 'field-v2-pid.json', 'field-v2-runner-delta.json',
                                  'field-v2-mock-proof.json', 'capsule-files.json', 'pip-freeze.txt', 'field-v2-driver.log')]
paths += [Path('/content/system-validation-qwen-provision.json')]
with tarfile.open(archive, 'w:gz') as tar:
    for path in paths:
        tar.add(path, arcname=path.relative_to(root).as_posix() if path.is_relative_to(root) else path.name)
receipt = {'archive': str(archive), 'bytes': archive.stat().st_size,
           'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'status': status}
Path('/content/system-validation-' + name + '.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
