import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/content/oa-validation-v2'); receipt=json.loads((root/'capsule-files.json').read_text())
assert json.loads((root/'primary-status.json').read_text())['status']=='completed'
assert Path('/content/system-validation-qwen-provision.json').exists()
for relative,item in receipt['files'].items():
 assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==item['sha256'],relative
assert not (root/'qwen-calibration-pid.json').exists()
env=os.environ.copy();env.update(HF_HOME='/content/oa-validation-hf',HF_HUB_CACHE='/content/oa-validation-hf/hub',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',AGRONOMY_AGENT_PRIVATE_KNOWLEDGE='disabled',AGRONOMY_AGENT_MODEL_BACKEND='mlx',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'src'))
command=[sys.executable,str(root/'outputs/system-validation-20260928/runner/run_retrieval_2x2.py'),'--calibration','--max-tokens','640','--model-config',str(root/'configs/model_qwen35_27b_diagnostic.yaml'),'--output-dir',str(root/'outputs/qwen-calibration640'),'--timeout-seconds','900','--cell-timeout-seconds','400']
driver=root/'qwen_calibration_driver.py'
driver.write_text('import subprocess,json,time\nfrom pathlib import Path\ncommand='+repr(command)+'\nstarted=time.time()\nstatus={"status":"running","started_epoch":started,"command":command}\nPath("qwen-calibration-status.json").write_text(json.dumps(status))\ntry:\n result=subprocess.run(command,timeout=960)\n status.update(status="completed" if result.returncode==0 else "failed",exit_code=result.returncode)\nexcept subprocess.TimeoutExpired:\n status.update(status="driver_timeout")\nfinally:\n status["seconds"]=time.time()-started\n Path("qwen-calibration-status.json").write_text(json.dumps(status))\n print(json.dumps(status),flush=True)\n')
log=(root/'qwen-calibration-driver.log').open('w');p=subprocess.Popen([sys.executable,str(driver)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'qwen-calibration-pid.json').write_text(json.dumps({'pid':p.pid,'command':command}));print(json.dumps({'pid':p.pid,'phase':'qwen_calibration'}),flush=True)
