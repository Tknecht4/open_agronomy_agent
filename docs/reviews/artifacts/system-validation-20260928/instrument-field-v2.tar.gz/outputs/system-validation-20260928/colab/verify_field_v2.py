"""Remote preflight; transfers no gold and starts no model generation."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/content/oa-validation-v2')
relative = 'outputs/system-validation-20260928/runner/run_retrieval_2x2_field_v2.py'
delta = json.loads((root / 'field-v2-runner-delta.json').read_text())
assert delta['runner_relative_path'] == relative
actual = hashlib.sha256((root / relative).read_bytes()).hexdigest()
assert actual == delta['runner_sha256']
assert delta['base_capsule_sha256'] == '1cabf50610fba86017b0126fa0e24545df2cc239b45cc851640137dd3c8b6c90'
inventory = json.loads((root / 'capsule-files.json').read_text())
for path, item in inventory['files'].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == item['sha256'], path
delta['remote_verified_sha256'] = actual
(root / 'field-v2-runner-delta.json').write_text(json.dumps(delta, indent=2) + '\n')
env = os.environ.copy()
env.update(AGRONOMY_AGENT_PRIVATE_KNOWLEDGE='disabled', PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(root / 'src'))
out = root / 'outputs/mock-field-v2-192'
assert not out.exists(), 'mock already started; inspect before any retry'
command = [sys.executable, str(root / relative), '--mock', '--max-tokens', '640',
           '--table-setup-module', str(root / 'outputs/system-validation-20260928/cohort/table_setup.py'),
           '--output-dir', str(out), '--timeout-seconds', '900', '--cell-timeout-seconds', '120']
result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=960)
(root / 'field-v2-mock.log').write_text(result.stdout + result.stderr)
assert result.returncode == 0, result.stderr[-2000:]
rows = [json.loads(line) for line in (out / 'ledger.jsonl').read_text().splitlines()]
assert len(rows) == 192 and all(row['status'] == 'completed_execution' for row in rows)
manifest = json.loads((out / 'run_manifest.json').read_text())
assert manifest['runner_sha256'] == actual
assert len(manifest['source_sha256']) == 147
for path, expected in manifest['source_sha256'].items():
    assert inventory['files'][path]['sha256'] == expected, path
proof = {'status': 'passed', 'completed': len(rows), 'run_sha256': manifest['run_sha256'],
         'runner_sha256': actual, 'source_count': 147,
         'source_binding': 'unchanged capsule inventory and frozen source 2b4028560c18def902463b4da44ef2c5c69467b1',
         'ledger_sha256': hashlib.sha256((out / 'ledger.jsonl').read_bytes()).hexdigest()}
(root / 'field-v2-mock-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof), flush=True)
