"""Bounded quantity identity and container-total checks for draft review.

This is a screening contract, not a general mathematical or semantic verifier.
A mentioned quantity is not proof of its relation to an entity or of authority
for an action. Only an unambiguous, explicitly requested container mass total is
derived here. Other calculations need a typed calculation result in evidence.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
import re

_NUM = r"[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?"
_UNIT = (
    r"kg\s*/\s*ha|lb(?:s)?\s*/\s*(?:acre|ac)|bu\s*/\s*acre|mg\s*/?\s*L|km\s*/?\s*h|"
    r"kilograms?|kg|grams?|g|pounds?|lbs?|ounces?|oz|tonnes?|litres?|liters?|mL|L|"
    r"ppm|ppb|mph|mm|cm|inches?|feet|ft|days?|hours?|acres?|%|°?[CF]"
)
NUMBER_RE = re.compile(
    rf"(?<![\w.,])(?P<number>{_NUM})(?:\s*(?:-|–|to)\s*(?P<upper>{_NUM}))?"
    rf"(?:\s*(?P<unit>{_UNIT})(?![\w/]))?(?!\w|[.,]\d)", re.IGNORECASE,
)
_ALIASES = {
    "kilogram": "kg", "kilograms": "kg", "gram": "g", "grams": "g",
    "pound": "lb", "pounds": "lb", "lbs": "lb", "ounce": "oz", "ounces": "oz",
    "litre": "l", "litres": "l", "liter": "l", "liters": "l",
    "inch": "inches", "foot": "ft", "feet": "ft", "day": "days", "hour": "hours",
    "acre": "acres", "tonne": "tonnes", "lbs/acre": "lb/ac", "lb/acre": "lb/ac",
}
_MASS_UNITS = {"kg", "g", "lb", "oz", "tonnes"}
_CONTAINERS = r"bags?|boxes|box|sacks?|packs?|packages?|bales?|containers?"


@dataclass(frozen=True)
class Quantity:
    value: Decimal
    upper: Decimal | None
    unit: str


def _quantity(match: re.Match[str]) -> Quantity:
    unit = re.sub(r"\s+", "", match.group("unit") or "").lower()
    return Quantity(
        Decimal(match.group("number").replace(",", "")),
        Decimal(match.group("upper").replace(",", "")) if match.group("upper") else None,
        _ALIASES.get(unit, unit),
    )


def _container_total(question: str, evidence: str) -> tuple[Decimal, Decimal, Quantity] | None:
    """Admit one count and one per-container mass, without unit conversion.

    Derivation is restricted to a total-mass question with explicit premises.
    Conflicting or multiple counts/masses remain unresolved, never guessed.
    """
    if not re.search(r"\btotal (?:mass|weight)\b", question, re.IGNORECASE):
        return None
    counts: set[Decimal] = set()
    masses: set[Quantity] = set()
    containers: set[str] = set()
    for text in (question, evidence):
        containers.update(
            "box" if word.lower() in {"box", "boxes"} else word.lower().rstrip("s")
            for word in re.findall(rf"\b(?:{_CONTAINERS})\b", text, re.IGNORECASE)
        )
        counts.update(Decimal(m.group(1).replace(",", "")) for m in re.finditer(
            rf"(?<![\w.,])({_NUM})\s+(?:{_CONTAINERS})\b", text, re.IGNORECASE,
        ))
        for match in NUMBER_RE.finditer(text):
            q = _quantity(match)
            if q.unit not in _MASS_UNITS or q.upper is not None:
                continue
            before = text[max(0, match.start() - 45):match.start()]
            after = text[match.end():match.end() + 25]
            if re.match(rf"\s+(?:each\b|per (?:{_CONTAINERS})\b)", after, re.IGNORECASE) or re.search(
                rf"\beach (?:{_CONTAINERS})\s+(?:weighs?|has a mass of)\s*$", before, re.IGNORECASE,
            ):
                masses.add(q)
    if len(counts) != 1 or len(masses) != 1 or len(containers) != 1:
        return None
    count, mass = next(iter(counts)), next(iter(masses))
    if count <= 0 or count != count.to_integral_value() or mass.value <= 0:
        return None
    return count, mass.value, Quantity(count * mass.value, None, mass.unit)


def unsupported_quantities(answer: str, *, question: str, evidence: str) -> tuple[str, ...]:
    allowed = {_quantity(m) for m in NUMBER_RE.finditer(f"{question}\n{evidence}")}
    derived = _container_total(question, evidence)
    values: list[str] = []
    for match in NUMBER_RE.finditer(answer):
        q = _quantity(match)
        prefix = answer[max(0, match.start() - 80):match.start()]
        suffix = answer[match.end():match.end() + 40]
        # Reporting a number explicitly as erroneous is not endorsing it.
        # No broad 'not' exemption: 'not less than 20' is still a numeric claim.
        reported_error = bool(re.match(r"\s+is\s+(?:an?\s+)?(?:error|incorrect|wrong)\b", suffix, re.IGNORECASE))
        if reported_error:
            continue
        total_assertion = bool(re.search(r"\btotal(?:\s+(?:mass|weight))?\s*(?:is|=|:)\s*$", prefix, re.IGNORECASE))
        equation = re.search(rf"(?<![\w.,])({_NUM})\s*[×*]\s*({_NUM})\s*=\s*$", prefix)
        if derived and (total_assertion or equation):
            count, mass, result = derived
            valid = q.upper is None and q.value == result.value and q.unit in {"", result.unit}
            if equation:
                operands = [Decimal(v.replace(",", "")) for v in equation.groups()]
                valid = valid and sorted(operands) == sorted([count, mass])
            if not valid:
                values.append(match.group().strip())
            continue
        # Bare references to a measured value (e.g. an equation operand) may
        # reuse its numeric magnitude; an explicit different unit may not.
        supported = q in allowed or (not q.unit and any(
            q.value == item.value and q.upper == item.upper for item in allowed
        ))
        if not supported:
            values.append(match.group().strip())
    return tuple(dict.fromkeys(values))
