# Field-delivery v2 retrieval instrument

Status: non-claim repair of the frozen 2×2 instrument. The original `run_retrieval_2x2.py`, frozen `runtime_cases.json`, cohort, rubrics, old mock results, and interrupted real results remain unchanged. Old real results do not establish product field-context fidelity: their runner passed legacy stored-record keys directly to the product core, so 176 of 184 non-table old mock cells had an empty compiled field. The other eight non-table cells were `sv24-07`, where only canonical `crop` reached the compiler and `province` did not become `jurisdiction`.

`run_retrieval_2x2_field_v2.py` uses an inline, manifest-bound projection before `AgentExecutionRequest`. Existing canonical `crop`, `region`, and `jurisdiction` values take precedence; otherwise `crop_current` supplies crop, `region_text` supplies region, and the first declared `province_state`, `province`, or `country` supplies jurisdiction. The `province` alias is the explicit Manitoba value in `sv24-07`, not inferred geography. The existing `enable_public_adapters` flag is retained. Source-only `field_area_ha`, `year`, and table fixture markers are retained in the raw receipt but do not become geometry, a sampling date, or other unsupported authority. The reviewed table helper still replaces session context for `sv24-08` and commits its isolated private fixture.

Each cell saves `field_delivery.json` with the raw source field record, raw and delivered SHA-256 identities, delivered canonical context, table-override status, compiled field observation, and prompt proof status. The same receipt is embedded in `execution.json` and its canonical hash appears in the ledger. Non-table cells must show exact canonical crop/region/jurisdiction equality in `field_context_compiler.field`. For a completed generation path, the actual stored prompt must contain the compiler-rendered field block and each nonempty canonical field value. Deterministic bypass, fallback, or unavailable paths record `not_applicable_no_generation`; they do not claim a model prompt was delivered. The runner and adapter version are bound by its distinct `system_validation_retrieval_2x2_field_delivery_run.v2` manifest identity, so `--resume` cannot continue a v1 run. The worker checks runner, input, source, corpus, config, table helper, and exposed fixture hashes at start and end as before.

Local proof used the current checkout's runtime Python and the unchanged reviewed cohort/table helper:

```bash
AGRONOMY_AGENT_PRIVATE_KNOWLEDGE=disabled PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src \
  .venv/bin/python outputs/system-validation-20260928/runner/run_retrieval_2x2_field_v2.py \
  --mock --max-tokens 640 \
  --table-setup-module outputs/system-validation-20260928/cohort/table_setup.py \
  --output-dir outputs/system-validation-20260928/runner/mock-field-v2-final-192 \
  --timeout-seconds 900 --cell-timeout-seconds 120
```

The final mock completed 192/192 with no end-of-run drift (`run_sha256` `d779b44e8821f91fd1cedbee169bc1ffcaa13d7949d52dad37248936aec73e5d`; runner SHA-256 `84e64d8d045d156cc17ceb7bad1d1b90e607974bc316d623dbbfa1c2c6c069ec`; ledger SHA-256 `d27b734cb579029d72190baaba008c7004a6e54f962dcd016939eb4e6c63edcf`). All 184 non-table compiler receipts contain canonical crop and jurisdiction; the 8 table cells used the table helper. All 8 `sv24-07` receipts carry `jurisdiction=Manitoba`. The 112 generation-path cells passed actual prompt block assertions; 80 bypass cells recorded no generation-prompt proof. All 192 delivery receipt hashes matched their ledger values. A separate two-cell mock calibration checked the empty field-record path: both cells delivered `{}`, passed prompt assertions, and completed without drift (`run_sha256` `a6f9b34b5f4b875c2061b31ee2496c8c2366c6335a353b3a7b972d3a0fae4bab`). These are delivery mechanics only; mock answers are not agronomic or model-quality evidence.

For the remote frozen source, transfer only this new runner file as an explicit delta to the immutable capsule v2. Its on-host SHA-256 and the unchanged 147-source-file manifest must be verified before a fresh remote 192-cell mock run. Use a new output directory for every real model run; old Qwen results are retained as interrupted, field-unfaithful evidence and cannot be resumed with this schema.

Memory delta: none.
