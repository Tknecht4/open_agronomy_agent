"""Reconstruct published run traces from a hash-bound raw export.

The export contains JSON objects rather than the original file formatting.
Runner serialization restores the original bytes: execution/setup/field JSON
uses UTF-8, ensure_ascii=False, indent=2, sort_keys=True and a newline; ledger
JSONL uses UTF-8, ensure_ascii=False, sort_keys=True and one newline per row.
SQLite stores are deliberately absent, so private table import/query joins
cannot be rerun from this reconstruction alone.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def canonical_sha256(value: object) -> str:
    return sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                             separators=(",", ":")).encode("utf-8"))


def safe_relative(value: str) -> Path:
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or any(part in {".", ".."} for part in path.parts):
        raise ValueError(f"unsafe export path: {value}")
    return Path(*path.parts)


def write_member(output: Path, relative: str, data: bytes, *, native: Path | None) -> None:
    path = output / safe_relative(relative)
    if path.exists():
        raise FileExistsError(f"output member already exists: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    if native is not None:
        original = native / safe_relative(relative)
        if not original.is_file() or sha256(original.read_bytes()) != sha256(data):
            raise ValueError(f"native byte identity mismatch: {relative}")


def restore(raw: Path, receipt_path: Path, output: Path, *, native: Path | None) -> dict[str, object]:
    if output.exists():
        raise FileExistsError("restore target must be a new directory")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    raw_bytes = raw.read_bytes()
    if raw.name != receipt["raw_file"] or sha256(raw_bytes) != receipt["raw_sha256"] or len(raw_bytes) != receipt["bytes"]:
        raise ValueError("raw export identity differs from export receipt")
    lines = gzip.decompress(raw_bytes).decode("utf-8").splitlines()
    if len(lines) != receipt["attempts"]:
        raise ValueError("attempt count differs from export receipt")
    records = [json.loads(line) for line in lines]
    ledgers: list[dict] = []
    files = {"execution": 0, "setup_receipt": 0, "field_delivery": 0}
    output.mkdir(parents=True)
    for record in records:
        row = record["ledger"]
        cell_id = row["cell_id"]
        if not re.fullmatch(r"[A-Za-z0-9_-]+", cell_id):
            raise ValueError(f"unsafe cell ID: {cell_id}")
        ledgers.append(row)
        if "execution" in record:
            relative = row.get("cell_result")
            expected = f"cells/{cell_id}/execution.json"
            if relative != expected:
                raise ValueError(f"execution path differs from cell identity: {cell_id}")
            data = json_bytes(record["execution"])
            if sha256(data) != record["execution_file_sha256"]:
                raise ValueError(f"execution byte hash differs from raw export: {cell_id}")
            write_member(output, expected, data, native=native)
            files["execution"] += 1
            delivery = record["execution"].get("field_delivery_receipt")
            if delivery is not None:
                if canonical_sha256(delivery) != row.get("field_delivery_receipt_sha256"):
                    raise ValueError(f"field delivery receipt hash differs from ledger: {cell_id}")
                write_member(output, f"cells/{cell_id}/field_delivery.json", json_bytes(delivery), native=native)
                files["field_delivery"] += 1
        elif row.get("cell_result"):
            raise ValueError(f"ledger names an execution absent from export: {cell_id}")
        if "setup_receipt" in record:
            data = json_bytes(record["setup_receipt"])
            if sha256(data) != record["setup_file_sha256"]:
                raise ValueError(f"setup byte hash differs from raw export: {cell_id}")
            if row.get("setup_receipt_sha256") and canonical_sha256(record["setup_receipt"]) != row["setup_receipt_sha256"]:
                raise ValueError(f"setup receipt hash differs from ledger: {cell_id}")
            write_member(output, f"cells/{cell_id}/setup_receipt.json", data, native=native)
            files["setup_receipt"] += 1
    ledger_data = "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in ledgers).encode("utf-8")
    if sha256(ledger_data) != receipt["ledger_sha256"]:
        raise ValueError("reconstructed ledger hash differs from export receipt")
    write_member(output, "ledger.jsonl", ledger_data, native=native)
    result = {"name": receipt["name"], "attempts": len(ledgers), "ledger_sha256": sha256(ledger_data),
              "files": files, "native_byte_check": native is not None,
              "boundary": "SQLite stores absent; table import and query joins require separate retained audit receipts."}
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", type=Path, required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--native-run-dir", type=Path, help="Optionally compare each restored file to retained native bytes")
    args = parser.parse_args()
    print(json.dumps(restore(args.raw, args.receipt, args.output_dir, native=args.native_run_dir), sort_keys=True))
