"""Publish complete answer/trace observations, excluding disposable SQLite stores."""
import argparse,gzip,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--name',required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[3];out=root/'docs/reviews/artifacts/system-validation-20260928';out.mkdir(exist_ok=True)
rows=[json.loads(s) for s in (a.run/'ledger.jsonl').read_text().splitlines() if s.strip()]
target=out/(a.name+'-raw.jsonl.gz');records=[]
for row in rows:
 r={'ledger':row}
 if row.get('cell_result'):
  f=a.run/row['cell_result'];r.update(execution_file_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),execution=json.loads(f.read_text()))
 setup=a.run/'cells'/row['cell_id']/'setup_receipt.json'
 if setup.exists():r.update(setup_file_sha256=hashlib.sha256(setup.read_bytes()).hexdigest(),setup_receipt=json.loads(setup.read_text()))
 records.append(r)
payload=''.join(json.dumps(r,sort_keys=True,ensure_ascii=False,separators=(',',':'))+'\n' for r in records).encode()
assert b'/Users/' not in payload and b'BEGIN PRIVATE KEY' not in payload
with target.open('wb') as handle:
 with gzip.GzipFile(filename='',mode='wb',fileobj=handle,mtime=0) as zipped:zipped.write(payload)
manifest=json.loads((a.run/'run_manifest.json').read_text());(out/(a.name+'-run-manifest.json')).write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
receipt={'name':a.name,'attempts':len(rows),'planned_cells':manifest['cell_count'],'run_sha256':manifest['run_sha256'],'raw_file':target.name,'raw_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'ledger_sha256':hashlib.sha256((a.run/'ledger.jsonl').read_bytes()).hexdigest(),'scope':'Original full execution JSON content, every ledger attempt, and table setup receipts. Raw generation statistics are preserved, including known stale bypass statistics. Original SQLite stores are retained locally rather than published; the separate linkage audit records whether their table receipt joins passed.'}
(out/(a.name+'-raw-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
