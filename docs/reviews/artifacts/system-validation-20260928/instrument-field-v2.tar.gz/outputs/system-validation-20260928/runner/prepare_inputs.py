"""Freeze gold-free runtime inputs and a separate local grading file."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
COHORT = ROOT / "outputs/system-validation-20260928/cohort/cohort.json"
EXPECTED_COHORT_SHA256 = "1d7165c4252f8a38f22d60bf56c44a1b96de67342a608d653d3963309b98c4dc"


def write_json(path: Path, value: object) -> str:
    raw = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    path.write_bytes(raw)
    digest = hashlib.sha256(raw).hexdigest()
    path.with_suffix(path.suffix + ".sha256").write_text(digest + "\n", encoding="ascii")
    return digest


def main() -> None:
    actual = hashlib.sha256(COHORT.read_bytes()).hexdigest()
    if actual != EXPECTED_COHORT_SHA256:
        raise ValueError(f"frozen cohort digest mismatch: {actual}")
    source = json.loads(COHORT.read_text(encoding="utf-8"))
    cases = source["cases"]
    if len(cases) != 24 or len({row["id"] for row in cases}) != 24:
        raise ValueError("frozen cohort must contain 24 distinct cases")
    runtime = {
        "schema_version": "system_validation_runtime_inputs.v1",
        "source_cohort_sha256": actual,
        "claim_eligible": False,
        "cases": [
            {
                "id": row["id"],
                "stratum": row["stratum"],
                "question": row["question"],
                "field_context": row.get("field_context") or {},
                "history": row.get("history") or [],
                "setup_dependency": (
                    "reviewed_private_table_import"
                    if (row.get("field_context") or {}).get("import_status") == "requires_separate_reviewed_private_import"
                    else None
                ),
            }
            for row in cases
        ],
        "output_budget_setup_prompts": [
            {"id": row["id"], "prompt": row["prompt"]}
            for row in source["output_budget_setup_prompts"]
        ],
    }
    grading = {
        "schema_version": "system_validation_local_grading.v1",
        "source_cohort_sha256": actual,
        "status": "local_offline_only_do_not_transfer_to_runtime",
        "scoring": source["scoring"],
        "cases": [
            {
                "id": row["id"],
                "stratum": row["stratum"],
                "expected_source_id": row.get("expected_source_id"),
                "reference_numeric": row.get("reference_numeric"),
                "rubric": row["rubric"],
                "decisive_evidence": row["decisive_evidence"],
            }
            for row in cases
        ],
    }
    runtime_digest = write_json(HERE / "runtime_cases.json", runtime)
    grade_digest = write_json(HERE / "grading_local.json", grading)
    print(json.dumps({"cohort_sha256": actual, "runtime_sha256": runtime_digest,
                      "grading_sha256": grade_digest, "runtime_cases": len(runtime["cases"])}))


if __name__ == "__main__":
    main()
