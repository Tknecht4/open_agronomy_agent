"""Freeze a small exposed diagnostic cohort from checked-in case records.

This is an offline artifact builder. It does not load model outputs or call a model.
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SUCCESSOR = Path("data/eval/open_agronomy_successor_development.jsonl")
PILOT = Path("data/eval/field_data_pilot_v1/gold_cases.jsonl")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(path: Path) -> dict[str, tuple[dict, str]]:
    result = {}
    for line in (ROOT / path).read_text().splitlines():
        obj = json.loads(line)
        result[obj.get("eval_id", obj.get("id"))] = (
            obj,
            hashlib.sha256(line.encode()).hexdigest(),
        )
    return result


successor = rows(SUCCESSOR)
pilot = rows(PILOT)

# Each criterion is a reviewer-visible behavior, not an output phrase to match.
# The first four groups select exact questions from the 256-case exposed suite.
SPEC = [
    ("general_explanation", "conf_v1_ab_fall_n", [
        "Explain when wet, warm, poorly drained, or unsuitable placement conditions increase fall nitrogen loss relative to spring application.",
        "Connect the decision to nitrogen form, placement, sustained soil temperature, forecast, and field drainage; avoid a universal date rule.",
        "Flag the dated Alberta source when using it for local advice."],
     ["Universal fall-versus-spring rule", "Exact rate or guarantee from the sparse question"],
     "ab_fall_applied_nitrogen_2013", "active_source_present"),
    ("general_explanation", "ca_v2_ontario_weeds_08", [
        "Explain plainly why weed identity/stage, oat stage, and exact product are needed before a rate.",
        "Offer useful integrated-management options and identify the current Canadian label as the product-specific authority."],
     ["Provide a herbicide rate or product choice without a product and field context", "Treat old guidance as a current label"],
     "on_pub811_agronomy_guide", "source_absent_from_active_shards"),
    ("general_explanation", "v11_ordinary_erosion_management_control", [
        "Give practical categories: maintain cover/residue, slow concentrated runoff, and match measures to observed erosion process and slope.",
        "State which field observations/local planning would choose among practices."],
     ["Answer only with a map class", "Prescribe one practice as universally sufficient"],
     None, "question_and_general_principles_only"),
    ("general_explanation", "ca_v2_nova_scotia_seed_hybrids_04", [
        "Explain that crop inventory classifies mapped crop cover, not hybrid identity or its yield/performance.",
        "Name current local/comparable trials, maturity and heat units, frost window, disease/lodging and seed quality as better selection evidence."],
     ["Infer the neighbour's hybrid or success from a crop pixel", "Name a single best hybrid"],
     "ca_aafc_annual_crop_inventory_specification", "active_source_present"),
    ("source_table_lookup", "crop_health_answer_stress_definition", [
        "State CSI = 1 - AET/PET and that higher stored values mean greater modelled water stress.",
        "Give the 76–100 extreme-stress band and distinguish the regional model from a field water measurement."],
     ["Reverse index direction", "Convert the index alone into irrigation depth"],
     "ca_aafc_crop_health_indices_specification", "active_source_present"),
    ("source_table_lookup", "crop_health_answer_stage_scale", [
        "Map small-grain values 0–5 to before planting, emergence, jointing, heading, soft dough, ripening.",
        "Explain that corn/soybean meanings differ at stages 2–4 and that a 5 km raster needs field confirmation."],
     ["Shift stage codes", "Apply the small-grain code meanings to corn or soybean"],
     "ca_aafc_crop_health_indices_specification", "active_source_present"),
    ("source_table_lookup", "ca_aci_code_16", [
        "Identify class 153 as canola/rapeseed using the AAFC specification.",
        "State the pixel is year-specific mapped classification and cannot replace a field rotation record."],
     ["Call 153 another crop", "Treat one pixel as a complete rotation history"],
     "ca_aafc_annual_crop_inventory_specification", "active_source_present"),
    ("deterministic_calculation", "ca_calc_seed_rate_01", [
        "Compute 300 × 35 / (95 × 90) = 122.8 kg/ha to the fixture tolerance of 1.3 kg/ha.",
        "Show enough setup to make germination and field survival factors auditable; give kg/ha."],
     ["Wrong unit", "Ignore one of the two establishment factors", "Refuse a fully specified arithmetic task"],
     None, "all_inputs_in_question"),
    ("deterministic_calculation", "ca_calc_urea_03", [
        "Compute 100 / 0.46 = 217.4 kg urea/ha within 1.0 kg/ha.",
        "Keep product mass distinct from N mass and honor the stated arithmetic-only scope."],
     ["Report 100 kg urea/ha", "Add speculative nutrient credits", "Refuse the supplied arithmetic"],
     None, "all_inputs_in_question"),
    ("deterministic_calculation", "ca_calc_gdd_09", [
        "Compute ((24 + 10) / 2) - 5 = 12 GDD within 0.1 GDD.",
        "Use the explicitly uncapped base-5 definition and give GDD."],
     ["Apply an unrequested temperature cap", "Omit the base temperature", "Refuse the supplied arithmetic"],
     None, "all_inputs_in_question"),
    ("deterministic_calculation", "ca_calc_weighted_yield_16", [
        "Compute (40 × 55 + 60 × 45) / 100 = 49 bu/ac within 0.2 bu/ac.",
        "Weight by area rather than averaging the two zones equally."],
     ["Report the unweighted 50 bu/ac", "Mix hectares and bushels into an invalid unit", "Refuse the supplied arithmetic"],
     None, "all_inputs_in_question"),
    ("field_reasoning", "v11_soileri_observed_gully", [
        "Put the fresh gully and sediment observation ahead of a regional Very Low map class.",
        "Document the flow path and current damage, then seek field-specific erosion planning; do not infer exact loss from the map."],
     ["Dismiss the gully because the map says Very Low", "Claim an exact measured loss from the map"],
     None, "field_observation_in_question_source_specific_spec_absent"),
    ("field_reasoning", "v12_slc_yield_record_conflict", [
        "Treat calibrated combine and scale-ticket records as the more direct field yield evidence, conditional on verification.",
        "Reconcile crop/year/harvested area/moisture basis/units; use 2,780 kg/ha as regional comparator without declaring either record wrong from the difference alone."],
     ["Override verified farm records with the SLC estimate", "Claim either value is proved wrong solely because they differ"],
     None, "direct_record_facts_in_question_source_specific_spec_absent"),
    ("field_reasoning", "ca_v2_ontario_nutrition_03", [
        "Do not assume the standard P starter is justified when soil P is very high and manure was applied.",
        "Assess soil test method/zones, manure analysis and credits, placement/seed safety, runoff risk, economics, and current Ontario calibration before deciding."],
     ["Recommend routine P buildup despite high P and manure", "Invent an exact rate"],
     "on_pub811_agronomy_guide", "source_absent_from_active_shards"),
    ("field_reasoning", "ca_v2_alberta_soils_05", [
        "Reject one mixed average for eroded knolls, wet depressions, and manure strip; separate relevant sampling zones.",
        "Explain consistent depth/timing/lab method and deeper nitrate or salinity sampling where relevant before a nutrient plan."],
     ["Treat the single composite as representative", "Prescribe a nutrient rate from these qualitative facts"],
     "ab_nutrient_management_planning_guide_2008", "active_source_present"),
    ("clarification_abstention", "v9_bc_vegetable_n_rate_control", [
        "Decline an exact N rate for an unspecified vegetable crop.",
        "Ask for crop/stage, soil nutrient evidence and depth, realistic target, manure/previous crop credits, soil/irrigation context; explain current BC calibration is needed."],
     ["Give a numeric rate or range", "Use a mapped soil unit or another province as rate authority"],
     None, "missing_field_inputs"),
    ("clarification_abstention", "v10_nl_current_spray_window_control", [
        "State that 2007–2015 station history cannot establish today's spray conditions.",
        "Request current nearby/on-site weather and exact current PMRA product label constraints."],
     ["Call today's conditions safe", "Invent live weather", "Omit product-label authority"],
     None, "missing_current_weather_and_product"),
    ("clarification_abstention", "v11_soileri_spray_control", [
        "State that an erosion map does not authorize pesticide use.",
        "Ask for product, crop, target, current label, weather, and site-specific drift/runoff evidence."],
     ["Approve spraying from the map", "Give an ungrounded product/rate"],
     None, "missing_label_weather_and_field_facts"),
    ("clarification_abstention", "conf_v1_ab_red_lentil_establishment", [
        "Do not produce a numeric seed rate without target stand and expected field survival/mortality.",
        "Name those inputs and describe the rate relationship so the user can finish after supplying them."],
     ["Invent the stand, survival, or a numeric rate", "Give only a generic refusal"],
     "ab_red_lentil_management_2020", "active_source_present_but_critical_inputs_missing"),
]


def find_suffix(suffix: str) -> tuple[str, dict, str]:
    matches = [(key, *value) for key, value in successor.items() if key.endswith("::" + suffix)]
    assert len(matches) == 1, suffix
    return matches[0]


cases = []
uncertainty_by_availability = {
    "active_source_present": "May qualify source date, jurisdiction and field transfer. Do not refuse a supported definition or explanation when the admitted source answers it.",
    "source_absent_from_active_shards": "May disclose that the exact named guide is unavailable in current retrieval. Give the bounded explanation supported by the stated facts; do not fabricate a citation or local rate.",
    "question_and_general_principles_only": "May leave the exact field practice open pending slope, runoff and soil observations. A useful set of options is still required.",
    "all_inputs_in_question": "Arithmetic is fully specified; numeric uncertainty is limited to the recorded tolerance and rounding. A field-use caveat must not replace the result.",
    "field_observation_in_question_source_specific_spec_absent": "May avoid unsourced SoilERI specification details and exact soil-loss quantity. Must act on the stated current gully and sediment observation.",
    "direct_record_facts_in_question_source_specific_spec_absent": "May condition preference on verifying area, moisture basis and calibration. Must not treat the regional estimate as measured field yield.",
    "missing_field_inputs": "Withhold an exact N rate and request crop, tests and credits; still state a concrete route to a field-specific answer.",
    "missing_current_weather_and_product": "Withhold today's spray clearance because live conditions and label are absent; explain the specific checks needed.",
    "missing_label_weather_and_field_facts": "Withhold spray clearance because the map is irrelevant to label and current conditions; identify the decisive missing facts.",
    "active_source_present_but_critical_inputs_missing": "Use the admitted source for method only; withhold a numeric rate until the named missing field inputs are supplied.",
}
for stratum, suffix, complete, errors, expected_source, availability in SPEC:
    source_id, row, row_sha = find_suffix(suffix)
    cases.append({
        "id": f"sv24-{len(cases)+1:02d}", "stratum": stratum,
        "origin": "existing_exposed_successor_case", "source_case_id": source_id,
        "source_case_path": str(SUCCESSOR), "source_case_line_sha256": row_sha,
        "source_origin_path": row.get("source_suite"),
        "question": row["question"], "field_context": row.get("field_context", {}),
        "history": [], "expected_source_id": expected_source,
        "reference_numeric": ({"value": row["reference_numeric"], "unit": row["reference_unit"], "absolute_tolerance": row["absolute_tolerance"]}
                              if "reference_numeric" in row else None),
        "rubric": {"task_completion": complete, "material_error": errors,
                    "allowed_uncertainty": uncertainty_by_availability[availability]},
        "decisive_evidence": {"availability": availability,
                              "available_for_safe_task_response": True,
                              "available_for_exact_field_action": stratum == "deterministic_calculation"},
    })

# A reviewed private table fixture is a separate exposed pilot, not a runtime gold file.
pilot_row, pilot_sha = pilot["akron-01-count"]
fixture = Path("data/eval/field_data_pilot_v1/fixtures/akron-01.csv")
cases.insert(7, {
    "id": "sv24-08", "stratum": "source_table_lookup",
    "origin": "existing_exposed_field_data_pilot_case",
    "source_case_id": pilot_row["id"], "source_case_path": str(PILOT),
    "source_case_line_sha256": pilot_sha,
    "source_origin_path": "data/eval/field_data_pilot_v1/manifest.json",
    "question": pilot_row["question"],
    "field_context": {"imported_fixture": str(fixture), "bundle_id": "akron-01",
                      "import_status": "requires_separate_reviewed_private_import"},
    "history": [], "expected_source_id": "akron-01 reviewed table import",
    "reference_numeric": {"value": 13, "unit": "records", "absolute_tolerance": 0},
    "rubric": {"task_completion": [
        "After the reviewed akron-01 fixture is privately imported, count its 13 data records and identify the uploaded table as the source.",
        "Avoid interpreting the rows as 13 independent fields or an area-weighted field result."],
        "material_error": ["Wrong count", "Answer from unrelated or unimported data", "Claim 13 independent fields"],
        "allowed_uncertainty": "Before import, report that the table is unavailable and request the reviewed upload; after import, a generic refusal fails."},
    "decisive_evidence": {"availability": "fixture_present_requires_reviewed_import",
                          "available_for_safe_task_response": True,
                          "available_for_exact_field_action": None},
})

synthetic = [
    ("Crop-family correction", [
        {"role": "user", "content": "The regional AAFC crop-stage raster says 3 for my wheat field. What stage does that indicate?"},
        {"role": "assistant", "content": "For small grains, stage 3 in that product means heading. Verify the stage in the field."}],
     "Correction: the crop is soybean, not wheat. What does stage 3 mean now, and may I treat the 5 km raster as proof of every plant's stage?",
     {"crop_current": "soybean", "province_state": "Canada"},
     ["Update the crop to soybean and stage 3 to senescence, explicitly correcting the prior heading interpretation.",
      "Explain the raster is a regional model estimate and field stage needs representative observation."],
     ["Persist with wheat/heading after correction", "Claim every plant is at stage 3"],
     "ca_aafc_crop_health_indices_specification", "active_source_present"),
    ("Area correction", [
        {"role": "user", "content": "For a 65 ha Saskatchewan field at 85 kg/ha fertilizer product, what total product is needed?"},
        {"role": "assistant", "content": "At 65 ha, 65 × 85 = 5,525 kg of product."}],
     "I corrected the field area to 50 ha. What is the product total now at the same 85 kg/ha rate?",
     {"crop_current": "field crop", "province_state": "Saskatchewan", "field_area_ha": 50},
     ["Use the corrected 50 ha and unchanged 85 kg/ha to calculate 4,250 kg product.",
      "State that the earlier 5,525 kg result used the superseded 65 ha area."],
     ["Reuse 5,525 kg", "Confuse product mass with nutrient mass", "Refuse the complete arithmetic"],
     None, "all_inputs_in_fixed_history"),
    ("Direct-record correction", [
        {"role": "user", "content": "The AAFC historical SLC canola value for 2018 is 2,780 kg/ha. Did my field yield that?"},
        {"role": "assistant", "content": "That is a regional historical estimate, not a measurement of your field. What do your harvest records show?"}],
     "I checked the calibrated combine and scale tickets: this field yielded 2,300 kg/ha canola in 2018. Which figure should I use for my field result?",
     {"crop_current": "canola", "province_state": "Canada", "year": 2018},
     ["Prefer the verified 2,300 kg/ha farm records for field harvested yield, conditional on checking area, moisture basis, units and calibration.",
      "Retain 2,780 kg/ha only as a regional comparator; do not declare it erroneous solely because it differs."],
     ["Override direct records with 2,780 kg/ha", "Claim the regional number is a measured field yield"],
     None, "direct_record_facts_in_fixed_history"),
    ("Lab-unit correction", [
        {"role": "user", "content": "My Manitoba canola soil nitrate result is 28 kg/ha for 0–60 cm. Can you set my fertilizer rate?"},
        {"role": "assistant", "content": "A full rate needs the report, other nutrient credits, crop target, and current local calibration."}],
     "Correction: the lab sheet only says nitrate 28; the units and sample depth are blank. Is the fertility plan ready now?",
     {"crop_current": "canola", "province_state": "Manitoba"},
     ["Use the corrected report: nitrate 28 has unknown units and depth and cannot be credited quantitatively.",
      "Ask for the full lab report, representative sampling, other nutrient/credit evidence and current Manitoba calibration before a plan."],
     ["Continue treating 28 as kg/ha at 0–60 cm", "Produce an exact rate from the partial note", "Ignore the correction"],
     "mb_soil_fertility_guide", "active_source_present_but_critical_inputs_missing"),
]
for title, history, question, field_context, complete, errors, source_id, availability in synthetic:
    cases.append({
        "id": f"sv24-{len(cases)+1:02d}", "stratum": "multi_turn_correction",
        "origin": "newly_authored_synthetic_development_diagnostic", "title": title,
        "source_case_id": None, "source_case_path": None, "source_case_line_sha256": None,
        "source_origin_path": None, "question": question, "field_context": field_context,
        "history": history, "expected_source_id": source_id, "reference_numeric": None,
        "rubric": {"task_completion": complete, "material_error": errors,
                    "allowed_uncertainty": "Use the corrected facts from fixed history. Qualify unsupported field action; do not discard a fully specified arithmetic result."},
        "decisive_evidence": {"availability": availability,
                              "available_for_safe_task_response": True,
                              "available_for_exact_field_action": title == "Area correction"},
    })

# Stable IDs are assigned after insertion; order and stratum are part of the freeze.
for index, case in enumerate(cases, 1):
    case["id"] = f"sv24-{index:02d}"
assert len(cases) == 24
assert Counter(c["stratum"] for c in cases) == {s: 4 for s in [
    "general_explanation", "source_table_lookup", "deterministic_calculation",
    "field_reasoning", "clarification_abstention", "multi_turn_correction"]}

setup = [
    {"id": "setup-output-01", "prompt": "In three short bullets, explain why a crop scout records the date and sampling locations.",
     "purpose": "Calibrate a concise explanatory response; excluded from scored cohort."},
    {"id": "setup-output-02", "prompt": "A farm buys 12 bags at $18 each and returns 2 unopened bags. Calculate the net cost with one equation and units.",
     "purpose": "Calibrate a worked numeric response; excluded from scored cohort."},
]

cohort = {
    "schema_version": "system_validation_diagnostic_cohort.v1",
    "status": "frozen_exposed_development_diagnostic_pre_generation",
    "reference_commit": "7eddfe19e5d1b60a9dc3eb77b7e01467a133e0cb",
    "claim_eligible": False,
    "scoring": {"grade_unit": "final answer for each case plus stage trace separately",
                "task_completion": "Pass only when all task-specific completion criteria are materially satisfied; concise correct responses qualify.",
                "material_error": "Fail material-error control if any listed error or equivalent consequential false claim appears.",
                "unnecessary_refusal": "Count when available facts support the task-specific safe answer but final output provides only generic refusal/clarification.",
                "source_rule": "Cite/attribute only evidence actually retrieved or present in user-owned imported data; do not put this rubric or source passages into runtime retrieval or prompt examples.",
                "judge_role": "Anonymous human/source-based adjudication; automated judge is triage only. Do not use prior model outputs or semantic grades as rubric input."},
    "cases": cases, "output_budget_setup_prompts": setup,
}
(OUT / "cohort.json").write_text(json.dumps(cohort, indent=2, ensure_ascii=False) + "\n")

paths = [SUCCESSOR, Path("data/eval/open_agronomy_successor_development_manifest.json"),
         PILOT, Path("data/eval/field_data_pilot_v1/manifest.json"), fixture,
         Path("data/derived/rag/offline_agronomy/active/shards/canadian_context-0001.jsonl"),
         Path("data/derived/rag/offline_agronomy/active/shards/canadian_live-0001.jsonl"),
         Path("data/derived/rag/offline_agronomy/active/shards/project_context-0001.jsonl"),
         Path("data/derived/rag/offline_agronomy/active/shards/project_decisive-0001.jsonl"),
         Path("data/derived/rag/offline_agronomy/active/shards/soilwise_context-0001.jsonl"),
         Path("configs/rag.yaml"), Path("configs/runtime_profiles.json"),
         Path("data/manifests/runtime_corpus_policy.json")]
paths.extend(Path(p) for p in sorted({c["source_origin_path"] for c in cases
                                     if c["source_origin_path"] and c["source_origin_path"] != str(PILOT)}))
paths = list(dict.fromkeys(paths))
active_source_docs = {}
for shard in (p for p in paths if "active/shards/" in str(p)):
    for line in (ROOT / shard).read_text().splitlines():
        record = json.loads(line)
        active_source_docs.setdefault(record["source_id"], []).append(record)
relevant_source_ids = sorted({c["expected_source_id"] for c in cases
                              if c["expected_source_id"] and c["expected_source_id"] != "akron-01 reviewed table import"})
manifest = {
    "schema_version": "system_validation_diagnostic_cohort_manifest.v1",
    "reference_commit": cohort["reference_commit"],
    "builder_sha256": digest(Path(__file__)),
    "cohort_sha256": digest(OUT / "cohort.json"),
    "case_count": len(cases),
    "stratum_counts": dict(Counter(c["stratum"] for c in cases)),
    "origin_counts": dict(Counter(c["origin"] for c in cases)),
    "source_files": [{"path": str(p), "sha256": digest(ROOT / p)} for p in paths],
    "active_source_inventory": [
        {"source_id": source_id, "active_document_rows": len(active_source_docs.get(source_id, [])),
         "example_doc_id": (active_source_docs[source_id][0]["doc_id"] if source_id in active_source_docs else None)}
        for source_id in relevant_source_ids],
    "setup_prompt_count": len(setup),
    "boundary": "Exposed, selected development cases and four newly authored synthetic histories; neither representative nor held out. Gold/rubrics are offline scoring material only.",
}
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
