"""Archive local evaluation inputs and judgments; never use as a model capsule."""
import gzip, hashlib, io, json, re, tarfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'outputs/system-validation-20260928'
A = BASE / 'analysis'
PUB = ROOT / 'docs/reviews/artifacts/system-validation-20260928'
sha = lambda data: hashlib.sha256(data).hexdigest()
files = set()
for pattern in ['grades-*.json','adjudication*.json','adjudicated*.json','provenance-*.json','provenance-*.txt','blind-*.json']:
    files.update(A.glob(pattern))
for folder in ['packets','blind-gemma-full','blind-prefix-56','blind-qwen-prefix16','gemma-quality','gemma-quality-v2','gemma-quality-final','gemma-field-v2-quality','qwen-field-v2-quality']:
    path = A / folder
    assert path.is_dir(), folder
    files.update(path.rglob('*.json'))
for name in ['prepare_blind.py','prepare_reused_grades.py','summarize_quality.py','audit_table_linkage.py','gemma-mechanics.py','gemma-field-v2-mechanics.py','qwen-mechanics.py','probe_residual_mechanisms.py','export_public_json.py','export_public_run.py','package_grading.py','package_runtime_receipts.py','problem-setup-audit.md','source-adjudication.md','stronger-contrast-plan.md','map-provenance-adjudication.json','table-receipt-linkage.json','gemma-source-clearances.json','gemma-field-v2-table-linkage-bound.json','gemma-field-v2-source-clearances.json','qwen-field-v2-table-linkage-bound.json','qwen-field-v2-source-clearances.json','qwen-prefix-full-reconciliation.json','residual-mechanisms.json','crop-map-fallback-mechanism.json','benchmark-source-reconciliation.json']:
    files.add(A / name)
for name in ['adjudicated-batch08.json','qwen-field-v2-quality/quality-summary.json']:
    assert (A/name).is_file(), name
payloads = {}
for path in sorted(files):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    assert not re.search(rb'/(?:Users|home)/[A-Za-z0-9._-]+', data), path.name
    assert not re.search(rb'(?:hf_|ghp_|sk-)[A-Za-z0-9_-]{20,}', data), path.name
    payloads[path.relative_to(ROOT).as_posix()] = data
buffer = io.BytesIO()
with gzip.GzipFile(filename='',mode='wb',fileobj=buffer,mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
        for name,data in payloads.items():
            item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;item.uid=item.gid=0;item.uname=item.gname=''
            tar.addfile(item,io.BytesIO(data))
archive=buffer.getvalue();target=PUB/'grading-analysis.tar.gz';manifest_path=PUB/'grading-analysis-manifest.json'
assert not target.exists() and not manifest_path.exists(), 'archive is immutable'
P='outputs/system-validation-20260928/'
common=['python',P+'analysis/summarize_quality.py']
gemma=common+['--packet',P+'analysis/packets/batch04','--run',P+'colab/results-gemma-field-v2/outputs/gemma-field-v2-192']
qwen=common+['--packet',P+'analysis/packets/batch08','--run',P+'colab/results-qwen-field-v2/outputs/qwen-field-v2-96']
for command,batch in [(gemma,'04'),(qwen,'08')]:
    for letter in ['a','b']:
        command.extend(['--'+letter,P+f'analysis/packets/batch{batch}/prepared/reused-{letter}.json','--'+letter,P+f'analysis/grades-{letter}-batch{batch}.json'])
for n in ['batch04']:gemma.extend(['--adjudicated',P+f'analysis/adjudicated-{n}.json'])
for n in ['batch05','batch06-v2','batch07','batch07-reused','batch08']:qwen.extend(['--adjudicated',P+f'analysis/adjudicated-{n}.json'])
for command,model in [(gemma,'gemma'),(qwen,'qwen')]:command.extend(['--clearances',P+f'analysis/{model}-field-v2-source-clearances.json','--out',P+f'analysis/reproduced-{model}-field-v2-quality'])
manifest={'schema':'system_validation_grading_archive.v1','archive':target.name,'sha256':sha(archive),'bytes':len(archive),'files':{k:{'sha256':sha(v),'bytes':len(v)} for k,v in payloads.items()},'reproduction_commands':{'gemma_corrected':gemma,'qwen_corrected':qwen},'expected_quality_summary_sha256':{model:sha((A/f'{model}-field-v2-quality/quality-summary.json').read_bytes()) for model in ['gemma','qwen']},'boundary':'Evaluation-only questions, rubrics, reference answers, anonymous packets, mappings, A/B judgments, source adjudications and analysis code. Never upload to a model host or admit to runtime retrieval or training. Extract only into a trusted evaluation checkout. Native run data is reconstructed separately from the public raw exports and exact metadata archive. SQLite is absent; table linkage depends on separately retained original stores and published bound audits.','historical_status':'Pre-field-v2 grades and intermediate gemma-quality directories are preserved superseded diagnostics; only gemma-field-v2-quality and qwen-field-v2-quality are corrected full-run summaries. Prefix packets overlap and are never pooled. Source-clearance proofs are run-specific. Original path-bearing mechanics JSON is retained locally, with separately published normalized derivatives and publication receipts.'}
target.write_bytes(archive);manifest_path.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    assert [x.name for x in tar.getmembers()]==list(payloads)
    for item in tar.getmembers():assert item.isfile() and tar.extractfile(item).read()==payloads[item.name]
print(json.dumps({'archive':target.name,'sha256':sha(archive),'files':len(files),'bytes':len(archive)}))
