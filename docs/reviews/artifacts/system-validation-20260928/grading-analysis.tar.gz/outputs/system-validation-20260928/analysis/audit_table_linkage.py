#!/usr/bin/env python3
"""Recompute sv24-08 answer claims from each cell's committed SQLite import.

Read-only usage: python3 audit_table_linkage.py --run PATH/outputs/qwen-retrieval-96
    [--output PATH]. This does not open gold, grader, or quality artifacts.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sqlite3
import zlib
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
CLAIM_PATTERNS = {
    "record_count": r"\b(\d+) imported records\b",
    "import_id": r"\bimport ID: ([0-9a-f-]{36})\b",
    "source_sha256": r"\bsource SHA-256: ([0-9a-f]{64})\b",
    "snapshot_receipt_sha256": r"\bsnapshot receipt: ([0-9a-f]{64})\b",
    "source_query_receipt_sha256": r"\bsource query receipt: ([0-9a-f]{64})\b",
    "selection_locator_digest": r"\bSelection locator digest: ([0-9a-f]{64})\b",
}


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value: Any) -> str:
    return sha_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())


def read(path: Path) -> dict[str, Any] | None:
    try: return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError): return None


def actual_from_sqlite(db: Path, setup: dict[str, Any], fixture: bytes) -> tuple[dict[str, str], dict[str, Any]]:
    conn = sqlite3.connect(f"file:{db}?mode=ro&immutable=1", uri=True)
    conn.row_factory = sqlite3.Row
    try:
        imports = conn.execute("SELECT * FROM field_data_imports WHERE id=?", (setup["import_id"],)).fetchall()
        if len(imports)!=1: raise ValueError("exactly one committed import required")
        imported = imports[0]
        if imported["status"]!="committed" or imported["field_id"]!=setup["field_context_id"] or imported["workspace_id"]!=setup["workspace_id"]:
            raise ValueError("import/field/workspace receipt mismatch")
        manifest=json.loads(imported["manifest_json"])
        mapping=json.loads(imported["mapping_json"])
        if canonical(mapping)!=imported["mapping_sha256"] or canonical(mapping)!=setup["mapping_sha256"]:
            raise ValueError("mapping checksum mismatch")
        if manifest.get("import_id")!=imported["id"] or manifest.get("row_count")!=setup["committed_row_count"]:
            raise ValueError("committed manifest mismatch")
        if imported["source_storage"]=="workspace-blob-v1":
            blobs=conn.execute("SELECT * FROM field_data_source_blobs WHERE workspace_id=? AND source_sha256=?",
                (imported["workspace_id"], imported["source_sha256"])).fetchall()
            if len(blobs)!=1: raise ValueError("source blob missing or duplicated")
            blob=blobs[0]; encoded=bytes(blob["encoded_bytes"])
            if blob["codec"]!="zlib-v1" or sha_bytes(encoded)!=blob["encoded_sha256"] or len(encoded)!=blob["encoded_size"]:
                raise ValueError("encoded source integrity mismatch")
            raw=zlib.decompress(encoded)
            if len(raw)!=blob["raw_size"]: raise ValueError("raw source size mismatch")
        elif imported["source_storage"]=="inline-v1": raw=bytes(imported["source_bytes"])
        else: raise ValueError("unknown source storage")
        if raw!=fixture or sha_bytes(raw)!=imported["source_sha256"] or setup["fixture_sha256"]!=imported["source_sha256"]:
            raise ValueError("source bytes/fixture/receipt mismatch")
        db_rows=conn.execute("SELECT * FROM field_data_rows WHERE import_id=? AND field_id=? ORDER BY row_number",
            (imported["id"], imported["field_id"])).fetchall()
        if len(db_rows)!=manifest["row_count"] or [r["row_number"] for r in db_rows]!=list(range(1,len(db_rows)+1)):
            raise ValueError("stored row count or ordinal mismatch")
        rows=[]
        for r in db_rows:
            item={"locator":json.loads(r["locator_json"]),"values":json.loads(r["values_json"])}
            if canonical(item)!=r["row_sha256"]:raise ValueError("stored row checksum mismatch")
            rows.append({**item,"row_sha256":r["row_sha256"]})
        selected_rows_sha=canonical([r["row_sha256"] for r in rows])
        receipt={
            "schema_version":"field_data.query.v1","field_id":imported["field_id"],"import_id":imported["id"],
            "source_sha256":imported["source_sha256"],"mapping_sha256":imported["mapping_sha256"],
            "member_sha256":json.loads(imported["profile_json"])["member_sha256"],"source":mapping["source"],
            "operation":"count","column":None,"record_key":mapping["record_key"],
            "aggregation_basis":"selected_row_count","filters":{},"selected_row_count":len(rows),
            "missing_count":0,"invalid_count":0,"unit":None,"role":None,"evidence_role":None,"value_scope":None,
            "locators":[r["locator"] for r in rows[:2]],"locators_truncated":len(rows)>2,
            "selected_rows_sha256":selected_rows_sha,"value":len(rows),
        }
        query_sha=canonical(receipt)
        compact={key:receipt.get(key) for key in (
            "operation","column","value","selected_row_count","record_key","aggregation_basis",
            "missing_count","invalid_count","numeric_count","unit","role","evidence_role","value_scope",
            "selected_rows_sha256","source_sha256","member_sha256","mapping_sha256","distinct_count",
            "truncated","limitations") if key in receipt}
        compact.update({"locators":receipt["locators"][:2],
            "locators_truncated":receipt["locators_truncated"] or len(receipt["locators"])>2,
            "query_receipt_sha256":query_sha,"field_id":receipt["field_id"],"import_id":receipt["import_id"],
            "schema_version":"field_data.query_snapshot.v1","filters":receipt["filters"]})
        snapshot_sha=canonical(compact)
        return {
            "record_count":str(len(rows)),"import_id":imported["id"],"source_sha256":imported["source_sha256"],
            "snapshot_receipt_sha256":snapshot_sha,"source_query_receipt_sha256":query_sha,
            "selection_locator_digest":selected_rows_sha,
        }, {"source_blob_verified":True,"stored_rows_verified":len(rows),"mapping_sha256":imported["mapping_sha256"],
            "query_receipt_sha256":query_sha,"snapshot_receipt_sha256":snapshot_sha}
    finally:conn.close()


def audit_cell(run: Path, cell: dict[str, Any], row: dict[str, Any] | None, fixture: bytes) -> dict[str, Any]:
    cell_id=cell["cell_id"]
    directory=run/"cells"/cell_id
    setup=read(directory/"setup_receipt.json")
    wrapper=read(directory/"execution.json")
    execution=(wrapper or {}).get("execution") or {}
    answer=execution.get("answer")
    output={"cell_id":cell_id,"arm":cell["arm"],"trial":cell["trial"],
        "ledger_status":row.get("status") if row else None,
        "full_answer_sha256":sha_bytes(answer.encode()) if isinstance(answer,str) else None,
        "claims":{},"failures":[],"unknowns":[]}
    if not setup:output["unknowns"].append("setup_receipt_missing")
    if not execution:output["unknowns"].append("execution_missing")
    if not (directory/"state.sqlite3").is_file():output["unknowns"].append("cell_sqlite_missing")
    if row and output["full_answer_sha256"] and row.get("answer_sha256")!=output["full_answer_sha256"]:
        output["failures"].append("ledger_answer_sha256")
    if setup and row and canonical(setup)!=row.get("setup_receipt_sha256"):
        output["failures"].append("ledger_setup_receipt_sha256")
    if setup and (directory/"state.sqlite3").is_file():
        try:actual,details=actual_from_sqlite(directory/"state.sqlite3",setup,fixture)
        except (ValueError,sqlite3.Error,KeyError,json.JSONDecodeError,zlib.error) as exc:
            output["unknowns"].append(f"sqlite_join_unavailable:{type(exc).__name__}:{exc}");actual={};details={}
    else:actual={};details={}
    output["sqlite_checks"]=details
    if setup:
        for key, expected in (("import_id",actual.get("import_id")),("committed_source_sha256",actual.get("source_sha256")),
            ("stored_count_value",int(actual["record_count"]) if actual.get("record_count") else None)):
            if expected is not None and setup.get(key)!=expected:output["failures"].append(f"setup_{key}")
    tool_results=[x for x in (((execution.get("turn") or {}).get("trace") or {}).get("tool_invocations") or [])
                  if x.get("tool_id")=="field_table_query" and x.get("status")=="success"]
    if len(tool_results)==1:
        payload=tool_results[0].get("payload") or {}
        receipt=payload.get("query_receipt") or {}
        for key, expected in (("import_id",actual.get("import_id")),("source_sha256",actual.get("source_sha256")),
            ("query_receipt_sha256",actual.get("source_query_receipt_sha256")),
            ("receipt_sha256",actual.get("snapshot_receipt_sha256")),
            ("selected_rows_sha256",actual.get("selection_locator_digest")),
            ("value",int(actual["record_count"]) if actual.get("record_count") else None)):
            if expected is not None and receipt.get(key)!=expected:output["failures"].append(f"tool_receipt_{key}")
        if canonical(payload)!=tool_results[0].get("payload_sha256"):output["failures"].append("tool_payload_sha256")
        output["tool_payload_sha256"]=tool_results[0].get("payload_sha256")
    else:output["unknowns"].append(f"successful_table_tool_count:{len(tool_results)}")
    for key, pattern in CLAIM_PATTERNS.items():
        match=re.search(pattern,answer or "")
        claimed=match.group(1) if match else None
        value=actual.get(key)
        status="unknown" if claimed is None or value is None else "pass" if claimed==value else "fail"
        output["claims"][key]={"claimed":claimed,"actual":value,"status":status,
            "source":"committed cell SQLite import, source blob, stored rows and recomputed receipts"}
        if status=="fail":output["failures"].append(f"answer_claim:{key}")
        elif status=="unknown":output["unknowns"].append(f"answer_claim:{key}")
    output["status"]="fail" if output["failures"] else "unknown" if output["unknowns"] else "pass"
    return output


def main() -> None:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run",type=Path,required=True)
    p.add_argument("--output",type=Path,default=HERE/"qwen-table-receipt-linkage.json")
    args=p.parse_args();run=args.run.resolve()
    plan=read(run/"cell_plan.json")
    if not isinstance(plan,list):raise SystemExit("cell_plan.json required")
    fixture=(ROOT/"data/eval/field_data_pilot_v1/fixtures/akron-01.csv").read_bytes()
    ledger_path=run/"ledger.jsonl"
    rows={}
    if ledger_path.is_file():
        for line in ledger_path.read_text().splitlines():
            if line.strip():
                try:
                    row=json.loads(line);rows[row.get("cell_id")]=row
                except json.JSONDecodeError:pass
    cells=[audit_cell(run,cell,rows.get(cell["cell_id"]),fixture) for cell in plan if cell["case_id"]=="sv24-08"]
    output={"schema_version":"system_validation_table_receipt_linkage.v1","scope":"mechanical source linkage only; no gold or grading files read",
        "run":str(run),"cell_count":len(cells),"cells":cells,
        "counts":{state:sum(c["status"]==state for c in cells) for state in ("pass","fail","unknown")}}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"counts":output["counts"],"output":str(args.output)},sort_keys=True))
    if output["counts"]["fail"]:raise SystemExit(1)

if __name__=="__main__":main()
