"""Reuse semantic grades only for byte-identical case/answer/premise/rubric items.

Source-attribution clearances are deliberately not reused; adjudication and actual
run receipt joins remain separate. All inputs remain local evaluation evidence.
"""
import argparse, hashlib, json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--packet', type=Path, required=True)
parser.add_argument('--prior-packet', type=Path, action='append', required=True)
parser.add_argument('--a', type=Path, action='append', required=True)
parser.add_argument('--b', type=Path, action='append', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists(), 'immutable grading preparation already exists'
current = json.loads(args.packet.read_text())
prior = {}
for path in args.prior_packet:
    for item in json.loads(path.read_text()):
        if item['blind_id'] in prior:
            assert prior[item['blind_id']] == item, 'same ID with differing premise'
        prior[item['blind_id']] = item

def read_grades(paths):
    grades = {}
    for path in paths:
        for grade in json.loads(path.read_text()):
            assert grade['blind_id'] not in grades, 'duplicate prior grade'
            grades[grade['blind_id']] = grade
    return grades

a, b = read_grades(args.a), read_grades(args.b)
reused, new = [], []
for item in current:
    bid = item['blind_id']
    if bid not in prior or bid not in a or bid not in b:
        new.append(item)
    else:
        assert item == prior[bid], 'reuse requires exact complete item equality'
        reused.append(bid)
args.output.mkdir(parents=True)
for name, data in [('new-items.json', new), ('reused-a.json', [a[k] for k in reused]),
                   ('reused-b.json', [b[k] for k in reused])]:
    (args.output / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
inputs = [args.packet, *args.prior_packet, *args.a, *args.b]
receipt = {'schema': 'exact_semantic_grade_reuse.v1', 'reused_ids': reused,
           'new_items': len(new), 'total_items': len(current),
           'inputs': [{'name': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in inputs],
           'source_clearances_reused': False,
           'boundary': 'Case, answer bytes, raw field premises, question, history, rubric, numeric reference and declared source availability are identical. This reuses semantic judgments, not source-attribution verification or run quality totals.'}
(args.output / 'reuse-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'new_items': len(new), 'reused_items': len(reused), 'total_items': len(current)}))
