"""Local-only anonymous case/answer deduplication; never transfer to model host."""
import argparse,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[3]
base=root/'outputs/system-validation-20260928'
p=argparse.ArgumentParser();p.add_argument('--run',action='append',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert not a.output.exists(), 'immutable grading packet already exists'
a.output.mkdir(parents=True)
runtime=json.loads((base/'runner/runtime_cases.json').read_text());cases={x['id']:x for x in runtime['cases']}
grades={x['id']:x for x in json.loads((base/'runner/grading_local.json').read_text())['cases']}
items={};mapping=[];failures=[]
for run in a.run:
 for line in (run/'ledger.jsonl').read_text().splitlines():
  row=json.loads(line)
  if row['status']!='completed_execution': failures.append({'run':run.name,**row});continue
  e=json.loads((run/row['cell_result']).read_text())['execution'];stages=e['turn']['trace']['metadata']['answer_stages'];case=cases[row['case_id']]
  for stage in ('draft','post_verification','final'):
   answer=stages[stage]['text'];sha=hashlib.sha256(answer.encode()).hexdigest();assert sha==stages[stage]['sha256']
   bid=hashlib.sha256(('blind-v1\0'+case['id']+'\0'+sha).encode()).hexdigest()[:16]
   items[bid]={'blind_id':bid,'question':case['question'],'supplied_field_context':case['field_context'],'prior_history':case['history'],'answer':answer,'rubric':grades[case['id']]['rubric'],'reference_numeric':grades[case['id']]['reference_numeric'],'source_availability':grades[case['id']]['decisive_evidence']}
   mapping.append({'blind_id':bid,'run':run.name,'case_id':case['id'],'cell_id':row['cell_id'],'trial':row['trial'],'arm':row['arm'],'stage':stage,'answer_sha256':sha})
ordered=[items[k] for k in sorted(items)]
for name,value in [('blind_packet.json',ordered),('private_mapping.json',mapping),('failed_attempts.json',failures)]:
 (a.output/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'unique_case_answers':len(items),'stage_observations':len(mapping),'failed_attempts':len(failures)}))
