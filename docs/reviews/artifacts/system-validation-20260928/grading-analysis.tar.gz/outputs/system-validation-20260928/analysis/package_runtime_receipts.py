"""Freeze exact collection-root receipts needed by the retained mechanics audits.

This is a narrow public evidence package, not a model-host capsule. It never
walks a collection directory: every admitted basename is listed below.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile


ROOT = Path(__file__).resolve().parents[3]
BASE = "outputs/system-validation-20260928/colab"
ARTIFACT_DIR = ROOT / "docs/reviews/artifacts/system-validation-20260928"
ARCHIVE = ARTIFACT_DIR / "runtime-receipts.tar.gz"
MANIFEST = ARTIFACT_DIR / "runtime-receipts-manifest.json"

# Explicit source receipts. No run outputs, database, source bundle, weights,
# resource balance, PID file, or package installer log is admitted.
ALLOWLIST = {
    "results-v1": (
        "capsule-files.json", "pip-freeze.txt", "calibration-status.json",
        "calibration-driver.log", "primary-status.json", "primary-driver.log",
        "system-validation-provision.json", "system-validation-runtime-probe.json",
    ),
    "results-qwen-partial-v1": (
        "capsule-files.json", "pip-freeze.txt", "calibration-status.json",
        "calibration-driver.log", "primary-status.json", "primary-driver.log",
        "qwen-calibration-status.json", "qwen-calibration-driver.log",
        "qwen-primary-status.json", "qwen-primary-driver.log",
        "qwen-instrument-stop.json", "system-validation-qwen-provision.json",
    ),
    "results-gemma-field-v2": (
        "capsule-files.json", "pip-freeze.txt", "gemma-field-v2-status.json",
        "field-v2-runner-delta.json", "field-v2-mock-proof.json",
        "field-v2-mock.log", "system-validation-provision.json",
        "system-validation-runtime-probe.json",
    ),
    "results-qwen-field-v2": (
        "capsule-files.json", "pip-freeze.txt", "qwen-field-v2-status.json",
        "field-v2-runner-delta.json", "field-v2-mock-proof.json",
        "field-v2-driver.log", "system-validation-qwen-provision.json",
    ),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def names() -> list[str]:
    return sorted(f"{BASE}/{collection}/{name}"
                  for collection, basenames in ALLOWLIST.items() for name in basenames)


def check_public(relative: str, data: bytes) -> None:
    patterns = (
        rb"/(?:Users|home)/[A-Za-z0-9._-]+",
        rb"/Volumes/[A-Za-z0-9._-]+",
        rb"/private/tmp/[A-Za-z0-9._-]+",
        rb"[A-Za-z]:\\Users\\[A-Za-z0-9._-]+",
        rb"(?:hf_|ghp_|github_pat_|sk-)[A-Za-z0-9_-]{20,}",
        rb"-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----",
        rb"(?i:authorization:\s*(?:bearer|basic)\s+\S+)",
    )
    if any(re.search(pattern, data) for pattern in patterns):
        raise ValueError(f"private path or possible credential in {relative}")


def source_bytes() -> dict[str, bytes]:
    payloads = {}
    for relative in names():
        path = ROOT / relative
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f"missing, symlinked, or escaped receipt: {relative}")
        data = path.read_bytes()
        check_public(relative, data)
        payloads[relative] = data
    return payloads


def archive_bytes(payloads: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=buffer, compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode="w", format=tarfile.PAX_FORMAT) as tar:
            for relative, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(relative)
                entry.size = len(data)
                entry.mode = 0o644
                entry.mtime = entry.uid = entry.gid = 0
                entry.uname = entry.gname = ""
                tar.addfile(entry, io.BytesIO(data))
    return buffer.getvalue()


def build() -> None:
    if ARCHIVE.exists() or MANIFEST.exists():
        raise FileExistsError("runtime receipts already frozen; verify existing files")
    payloads = source_bytes()
    archive = archive_bytes(payloads)
    manifest = {
        "schema_version": "system_validation_runtime_receipts_manifest.v1",
        "archive": ARCHIVE.name,
        "sha256": sha256(archive),
        "bytes": len(archive),
        "files": {name: {"sha256": sha256(data), "bytes": len(data)}
                  for name, data in sorted(payloads.items())},
        "collections": {name: list(basenames) for name, basenames in sorted(ALLOWLIST.items())},
        "boundary": (
            "Collection-root mechanics evidence only. No isolated database, gold, "
            "model weights, source bundles, resource balances, or run-output records. "
            "Extract at repository root to preserve native relative paths."
        ),
        "absent_evidence": (
            "The retained Gemma field-v2 collection has no standalone driver log; "
            "its audit records this limitation rather than inventing a receipt."
        ),
        "verification": "python3 outputs/system-validation-20260928/analysis/package_runtime_receipts.py verify",
    }
    ARCHIVE.write_bytes(archive)
    MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    verify()


def verify() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    archive = ARCHIVE.read_bytes()
    if manifest["sha256"] != sha256(archive) or manifest["bytes"] != len(archive):
        raise ValueError("archive hash or size mismatch")
    if set(manifest["files"]) != set(names()):
        raise ValueError("manifest differs from explicit receipt allowlist")
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as tar:
        members = tar.getmembers()
        if [member.name for member in members] != names():
            raise ValueError("archive member set or order differs from allowlist")
        extracted = {}
        for member in members:
            if (not member.isfile() or member.mode != 0o644 or member.mtime != 0
                    or member.uid != 0 or member.gid != 0 or member.uname or member.gname):
                raise ValueError(f"unsafe or non-deterministic member: {member.name}")
            data = tar.extractfile(member).read()
            expected = manifest["files"][member.name]
            check_public(member.name, data)
            if sha256(data) != expected["sha256"] or len(data) != expected["bytes"]:
                raise ValueError(f"member hash or size mismatch: {member.name}")
            if data != (ROOT / member.name).read_bytes():
                raise ValueError(f"native receipt bytes differ: {member.name}")
            extracted[member.name] = data
    if archive_bytes(extracted) != archive:
        raise ValueError("deterministic archive rebuild differs")
    print(json.dumps({"archive_sha256": manifest["sha256"], "native_files_verified": len(members)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("build", "verify"))
    args = parser.parse_args()
    build() if args.action == "build" else verify()
