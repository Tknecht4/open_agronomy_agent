"""Post-hoc lexical/provenance probes; not part of frozen efficacy cohort."""
import hashlib,json
from pathlib import Path
from agronomy_agent.high_consequence import classify_high_consequence_domains
from agronomy_agent.quantity_claims import unsupported_quantities
from agronomy_agent.router import classify_query
root=Path(__file__).resolve().parents[3]
route_probes=[
 ('yield_record_should','My calibrated combine reports 2,400 kg/ha canola. Which record should control the field result?'),
 ('yield_record_does','My calibrated combine reports 2,400 kg/ha canola. Which record controls the field result?'),
 ('nutrient_prescription','How much nitrogen should I apply to this canola field?'),
 ('product_arithmetic','For an arithmetic check only, product rate is already fixed at 80 kg/ha and area is 40 ha. What is the total mass?'),
 ('mass_arithmetic','For an arithmetic check only, material mass per area is already fixed at 80 kg/ha and area is 40 ha. What is the total mass?'),
 ('full_product_reference','In the AAFC crop development stage raster, what does soybean stage 3 mean?'),
 ('followup_product_reference','Correction: the crop is soybean, not wheat. What does stage 3 mean now?'),
]
quantity_probes=[
 ('plain','The record says 2,400 kg/ha. Report that recorded value.','The recorded value is 2,400 kg/ha.'),
 ('latex','The record says 2,400 kg/ha. Report that recorded value.',r'The recorded value is $2,400 \text{ kg/ha}$.'),
 ('wrong_units','The record says 2,400 kg/ha. Report that recorded value.','The recorded value is 2,400 lb/ac.'),
 ('wrong_value','The record says 2,400 kg/ha. Report that recorded value.','The recorded value is 2,500 kg/ha.'),
]
result={'status':'post_hoc_diagnostic_not_frozen_score','source_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['src/agronomy_agent/high_consequence.py','src/agronomy_agent/quantity_claims.py','src/agronomy_agent/router.py']},'route_probes':[{'id':i,'question':q,'high_consequence_domains':classify_high_consequence_domains(q),'route':vars(classify_query(q))} for i,q in route_probes],'quantity_probes':[{'id':i,'question':q,'answer':a,'unsupported':unsupported_quantities(a,question=q,evidence='')} for i,q,a in quantity_probes]}
(root/'outputs/system-validation-20260928/analysis/residual-mechanisms.json').write_text(json.dumps(result,indent=2,default=lambda v:sorted(v) if isinstance(v,set) else str(v))+'\n')
print(json.dumps({'route_probes':[(x['id'],x['high_consequence_domains'],x['route']['question_type']) for x in result['route_probes']],'quantity_probes':result['quantity_probes']}))
