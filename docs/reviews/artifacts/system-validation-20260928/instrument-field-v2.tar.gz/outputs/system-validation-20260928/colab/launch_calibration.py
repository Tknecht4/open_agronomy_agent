import hashlib,json,os,subprocess,sys,tarfile
from pathlib import Path
archive=Path('/content/oa-validation-capsule-v2.tar.gz')
expected='1cabf50610fba86017b0126fa0e24545df2cc239b45cc851640137dd3c8b6c90'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
root=Path('/content/oa-validation-v2'); root.mkdir(exist_ok=False)
with tarfile.open(archive) as tar: tar.extractall(root,filter='data')
receipt=json.loads((root/'capsule-files.json').read_text())
for relative,item in receipt['files'].items():
 assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==item['sha256'],relative
install=subprocess.run([sys.executable,'-m','pip','install','--no-build-isolation','--no-deps','-e',str(root)],capture_output=True,text=True,timeout=120)
(root/'package-install.log').write_text(install.stdout+'\n'+install.stderr)
assert install.returncode==0,install.stderr[-1000:]
env=os.environ.copy(); env.update(HF_HOME='/content/oa-validation-hf',HF_HUB_CACHE='/content/oa-validation-hf/hub',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',AGRONOMY_AGENT_PRIVATE_KNOWLEDGE='disabled',AGRONOMY_AGENT_MODEL_BACKEND='mlx',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root/'src'))
runner=root/'outputs/system-validation-20260928/runner/run_retrieval_2x2.py'
command=[sys.executable,str(runner),'--calibration','--max-tokens','640','--model-config',str(root/'configs/model.yaml'),'--output-dir',str(root/'outputs/calibration640'),'--timeout-seconds','600','--cell-timeout-seconds','180']
driver=root/'calibration_driver.py'
driver.write_text('import subprocess,json,time\nfrom pathlib import Path\ncommand='+repr(command)+'\nstarted=time.time()\nstatus={"status":"running","started_epoch":started,"command":command}\nPath("calibration-status.json").write_text(json.dumps(status))\ntry:\n result=subprocess.run(command,timeout=660)\n status.update(status="completed" if result.returncode==0 else "failed",exit_code=result.returncode)\nexcept subprocess.TimeoutExpired:\n status.update(status="driver_timeout")\nfinally:\n status["seconds"]=time.time()-started\n Path("calibration-status.json").write_text(json.dumps(status))\n print(json.dumps(status),flush=True)\n')
log=(root/'calibration-driver.log').open('w')
p=subprocess.Popen([sys.executable,str(driver)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'calibration-pid.json').write_text(json.dumps({'pid':p.pid,'source_commit':receipt['source_commit'],'capsule_sha256':expected,'command':command}))
print(json.dumps({'pid':p.pid,'root':str(root),'files_verified':len(receipt['files']),'capsule_sha256':expected}),flush=True)
