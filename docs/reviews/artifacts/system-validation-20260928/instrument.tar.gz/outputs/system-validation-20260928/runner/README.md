# Frozen-cohort retrieval 2×2 runner

Status: local non-claim instrument. It executes the existing `ObservedSystemBenchmarkAdapter` and production `execute_agent_request`; it does not implement another agent, score answers, or authorize a model/provider run. The cohort is frozen at SHA-256 `1d7165c4252f8a38f22d60bf56c44a1b96de67342a608d653d3963309b98c4dc`.

## Files and separation

- `prepare_inputs.py` checks the frozen cohort hash and writes `runtime_cases.json` plus its `.sha256`. Runtime input contains only case ID, stratum, question, supplied field context, exact fixed history, and setup dependency. It has no rubric, reference number, expected source, or decisive-evidence grade.
- `grading_local.json` and its `.sha256` retain those grading fields separately for later local offline adjudication. Do not transfer them to a model host or put them in a prompt, retrieval corpus, or training data.
- `run_retrieval_2x2.py` freezes a run manifest, full source and corpus hashes, a counterbalanced plan, isolated cell state, full answer stages and prompt bytes, append-only ledger, and worker log. It starts one long-lived worker with one reused draft backend, resets query caches per cell, and creates a fresh database/session per cell. The parent enforces finite whole-run and per-cell timeouts; after a kill it records a terminal failure and retains the partial ledger and state. `--resume` requires exact manifest identity.
- `derive_model_profile.py` creates an explicit diagnostic profile for a larger output cap, changing only `max_tokens` and `serving_max_tokens`. The active config is untouched. The runner requires an 8192-token context, prompt cache off, a pinned serving model, and the same pinned verifier snapshot.
- `audit_preflight.py` verifies a full 192-cell mock run's receipts, disabled retrieval outputs, table setup, and current source hashes. It does not grade correctness.

The one table case, `sv24-08`, requires the reviewed private fixture setup in `../cohort/table_setup.py`. Without that helper the runner records `setup_blocked` for its eight cells; it never supplies a fake table answer. The helper commits the reviewed fixture into each isolated cell store and returns a source-bound setup receipt. The run identity binds the helper file and the exposed pilot manifest, fixture bytes, and reviewed mapping. Worker startup, resume, and run completion recheck those dependencies along with the runner, source, corpus, configs, inputs, and plan.

## Local setup and mock checks

From the repository root:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python outputs/system-validation-20260928/runner/prepare_inputs.py

AGRONOMY_AGENT_PRIVATE_KNOWLEDGE=disabled PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src \
  .venv/bin/python outputs/system-validation-20260928/runner/run_retrieval_2x2.py \
  --mock --max-tokens 640 \
  --table-setup-module outputs/system-validation-20260928/cohort/table_setup.py \
  --output-dir outputs/system-validation-20260928/runner/mock-reviewed-new \
  --timeout-seconds 900 --cell-timeout-seconds 120

PYTHONDONTWRITEBYTECODE=1 .venv/bin/python \
  outputs/system-validation-20260928/runner/audit_preflight.py \
  outputs/system-validation-20260928/runner/mock-reviewed-new
```

Default planning is 24 cases × four retrieval arms × trials 1 and 2 = 192 cells. Trial 2 reverses arm order within each case. Use `--case-filter sv24-01,sv24-08 --arms retrieval_neither,retrieval_both --trials 1` for a bounded pilot. `--calibration` runs only the two separate setup prompts, one `retrieval_both` cell each; its mock mode checks execution mechanics only and cannot calibrate real generation length. Run real calibration and freeze one sufficient common cap before the matched experiment.

The current active profile caps output at 640 tokens. To test a 1024-token allowance without changing it:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python \
  outputs/system-validation-20260928/runner/derive_model_profile.py \
  --max-tokens 1024 \
  --output outputs/system-validation-20260928/runner/profiles/model-1024-new.yaml
```

Pass the derived path with `--model-config ... --max-tokens 1024` to a new calibration/run directory. Each run directory is immutable by default. `--resume` continues only an interrupted exact plan; source, corpus, config, model, runner, table-helper, and input identities are checked before continuation and at run end.

## Real-run boundary and transfer

No real model/provider was run here. This run is restricted to `AGRONOMY_AGENT_MODEL_BACKEND=mlx` (or the unset default) on the authorized local MLX Colab runtime; other real backends fail before output creation. The owner must preflight the pinned model and runtime, choose an output cap from separate real setup cases, and set finite timeouts. The active Gemma model is first. A stronger pinned model uses a separate config and run directory, initially a frozen subset (`--case-filter`), without pooling models in one score. Retain the backend identity receipt and generation statistics; unknown token counts or first-token timing remain unknown.

The minimal added files to transfer with an otherwise complete, hash-matched repository checkout are `run_retrieval_2x2.py`, `runtime_cases.json`, `runtime_cases.json.sha256`, and `../cohort/table_setup.py`; the checkout must also contain the exact exposed `data/eval/field_data_pilot_v1/manifest.json` and `fixtures/akron-01.csv`. Transfer a derived model profile and receipt only if using the larger cap. The runner imports the repository's existing `scripts/run_portable_harness_diagnostic.py` for public RAG profile creation and corpus hashing. Keep `grading_local.json`, the original cohort with rubrics, and development answer artifacts off the model host. The output directory contains full prompts, answers, traces, per-cell SQLite state, and the append-only ledger; handle it as local evaluation evidence.

## Observed mock evidence and limits

The source-frozen `mock-source-freeze-192` run completed **192/192** cells under the accepted runner (SHA-256 `da9d533bca463ec17d3a0a2d99eeef82c3dc177d4445978a539175902926ae9b`) and reviewed table helper (SHA-256 `c0e0dc3927deb27664ce73559191cd42e72e10350742f63fd02cdfc1e42191b2`). Its run SHA-256 is `e76f4eeefb6d451c38d5bf40e16cac6c79d09fac8e4a1e989602b3c3a36b8e9e`. The run reported no source, corpus, config, input, helper, or table-dependency drift; `preflight_proof.json` has `status=pass`, zero failures, 192 complete execution receipts, and eight reviewed table imports. Exact resume returned `already_complete`. The revised runner also passed a one-cell table pilot, negative HTTP-backend and non-finite timeout checks, a negative pilot-mapping drift check, and a partial-ledger-tail preservation check. Earlier runs and their receipts remain preserved, including a no-helper run with eight `setup_blocked` cells, a helper run that detected source drift, and snapshots from earlier runner and source revisions. In the 32 fixed-history cells, 24 model prompts included the stored prior pair; the other eight used a deterministic bypass and recorded zero included history turns. Exact history pairs were still seeded in separate stores for all 32 cells. A separate 32-cell timeout test deliberately killed one cell, appended its `terminal_timeout` row, and resumed the exact ledger to 31 completed executions plus the retained failure. Mock outcomes do not establish answer usefulness, model quality, provider reliability, retrieval benefit, or agronomic validity.

Memory delta: none.
