#!/usr/bin/env python3
"""Bounded, resumable, non-claim retrieval 2x2 over the production core."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from agronomy_agent.agent import reset_phase5_query_caches  # noqa: E402
from agronomy_agent.benchmark_rehearsal import (  # noqa: E402
    ObservedSystemBenchmarkAdapter,
    RETRIEVAL_COMPONENT_CONFIGURATIONS,
)
from agronomy_agent.execution_core import AgentExecutionRequest  # noqa: E402
from agronomy_agent.server.services.chat_service import _build_mlx_generator  # noqa: E402
from agronomy_agent.server.settings import build_settings  # noqa: E402
from agronomy_agent.server.storage.db import TraceStore  # noqa: E402
from scripts.run_portable_harness_diagnostic import (  # noqa: E402
    public_rag_config,
    rag_artifact_receipt,
)


SCHEMA = "system_validation_retrieval_2x2_run.v1"
COHORT_SHA256 = "1d7165c4252f8a38f22d60bf56c44a1b96de67342a608d653d3963309b98c4dc"
ARM_ORDER = (
    "retrieval_neither",
    "retrieval_document_only",
    "retrieval_graph_only",
    "retrieval_both",
)
ARM_IDS = {
    "retrieval_neither": "retrieval_neither",
    "retrieval_document_only": "retrieval_document_only",
    "retrieval_graph_only": "retrieval_graph_only",
    "retrieval_both": "retrieval_document_and_graph",
}
def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_sha256(value: Any) -> str:
    return sha256_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                   separators=(",", ":")).encode("utf-8"))


def source_hashes() -> dict[str, str]:
    paths = tuple(path.relative_to(ROOT).as_posix()
                  for path in sorted((ROOT / "src").rglob("*.py")))
    return {path: sha256_file(ROOT / path)
            for path in (*paths, "scripts/run_portable_harness_diagnostic.py")}


def load_table_setup(path: str | None) -> tuple[Any | None, dict[str, str]]:
    if not path:
        return None, {}
    module_path = Path(path)
    spec = importlib.util.spec_from_file_location("system_validation_table_setup", module_path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load table setup module: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    setup = getattr(module, "setup_table_case", None)
    if not callable(setup):
        raise ValueError("table setup module needs setup_table_case(store, session_id, case, cell_dir)")
    dependencies = getattr(module, "reviewed_table_dependencies", None)
    if not callable(dependencies):
        raise ValueError("table setup module needs reviewed_table_dependencies()")
    receipt = dependencies()
    if not isinstance(receipt, dict) or set(receipt) != {
        "pilot_manifest_sha256", "pilot_fixture_sha256", "pilot_mapping_sha256"
    } or any(not isinstance(value, str) or len(value) != 64 for value in receipt.values()):
        raise ValueError("table setup returned invalid pilot dependency hashes")
    return setup, receipt


def require_local_mlx(*, mock: bool, declared_backend: str | None = None) -> str:
    if mock:
        return "mock"
    actual = os.getenv("AGRONOMY_AGENT_MODEL_BACKEND", "mlx").strip().lower()
    if actual != "mlx" or (declared_backend is not None and declared_backend != "mlx"):
        raise ValueError("this real run requires AGRONOMY_AGENT_MODEL_BACKEND=mlx")
    return "mlx"


def verify_run_dependencies(manifest: dict[str, Any], run_dir: Path) -> None:
    """Reject changed inputs before a worker executes or a run resumes/ends."""
    run_basis = {key: value for key, value in manifest.items() if key not in {
        "run_sha256", "runtime_path", "runtime_digest_path", "model_config_path",
        "rag_source_path", "rag_profile_path", "table_setup_module_path",
    }}
    if canonical_sha256(run_basis) != manifest["run_sha256"]:
        raise ValueError("run manifest identity mismatch")
    if sha256_file(Path(__file__)) != manifest["runner_sha256"]:
        raise ValueError("runner bytes drifted")
    if source_hashes() != manifest["source_sha256"]:
        raise ValueError("source bytes drifted")
    if sha256_file(Path(manifest["runtime_path"])) != manifest["runtime_sha256"]:
        raise ValueError("runtime input bytes drifted")
    if sha256_file(Path(manifest["runtime_digest_path"])) != manifest["runtime_digest_sha256"]:
        raise ValueError("runtime digest bytes drifted")
    if sha256_file(Path(manifest["model_config_path"])) != manifest["model_config_sha256"]:
        raise ValueError("model profile bytes drifted")
    if sha256_file(Path(manifest["rag_source_path"])) != manifest["rag_source_sha256"]:
        raise ValueError("RAG source bytes drifted")
    if sha256_file(Path(manifest["rag_profile_path"])) != manifest["rag_public_profile_sha256"]:
        raise ValueError("RAG run profile bytes drifted")
    if rag_artifact_receipt(public_rag_config(Path(manifest["rag_source_path"]))) != manifest["corpus_artifact_sha256"]:
        raise ValueError("corpus artifact bytes drifted")
    if canonical_sha256(json.loads((run_dir / "cell_plan.json").read_text(encoding="utf-8"))) != manifest["cells_sha256"]:
        raise ValueError("cell plan bytes drifted")
    helper_path = manifest.get("table_setup_module_path")
    if helper_path:
        if sha256_file(Path(helper_path)) != manifest["table_setup_module_sha256"]:
            raise ValueError("table setup helper bytes drifted")
        _, dependencies = load_table_setup(helper_path)
        if dependencies != manifest["table_dependencies_sha256"]:
            raise ValueError("reviewed pilot table inputs drifted")
    elif manifest["table_dependencies_sha256"] != {}:
        raise ValueError("table dependencies recorded without a setup helper")
    require_local_mlx(mock=manifest["mock"], declared_backend=manifest["model_backend"])


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8")


def append_jsonl(path: Path, value: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def ledger_rows(path: Path, *, tolerate_partial_tail: bool = False) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    payload = path.read_bytes()
    if tolerate_partial_tail and payload and not payload.endswith(b"\n"):
        payload = payload[:payload.rfind(b"\n") + 1]
    return [json.loads(line) for line in payload.decode("utf-8").splitlines() if line.strip()]


def preserve_partial_ledger_tail(path: Path) -> None:
    """Keep a killed writer's incomplete bytes outside the parseable ledger."""
    payload = path.read_bytes()
    if not payload or payload.endswith(b"\n"):
        return
    last_break = payload.rfind(b"\n")
    tail = payload[last_break + 1:]
    tail_path = path.with_name("ledger_partial_tail.bin")
    if tail_path.exists():
        raise FileExistsError(f"partial ledger evidence already exists: {tail_path}")
    tail_path.write_bytes(tail)
    with path.open("r+b") as handle:
        handle.truncate(last_break + 1)


def load_runtime(path: Path, digest_path: Path) -> dict[str, Any]:
    expected = digest_path.read_text(encoding="ascii").strip()
    observed = sha256_file(path)
    if expected != observed:
        raise ValueError(f"runtime input digest mismatch: expected={expected} observed={observed}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("source_cohort_sha256") != COHORT_SHA256:
        raise ValueError("runtime input does not bind the frozen cohort")
    if payload.get("schema_version") != "system_validation_runtime_inputs.v1":
        raise ValueError("unsupported runtime input schema")
    cases = payload.get("cases")
    if not isinstance(cases, list) or len(cases) != 24:
        raise ValueError("runtime input must contain 24 cases")
    if len({row.get("id") for row in cases}) != len(cases):
        raise ValueError("runtime case IDs are not unique")
    forbidden = {"rubric", "reference_numeric", "expected_source_id", "decisive_evidence", "scoring"}
    if forbidden.intersection(payload) or any(forbidden.intersection(row) for row in cases):
        raise ValueError("grading fields entered runtime inputs")
    return payload


def validate_model_profile(path: Path, *, max_tokens: int) -> dict[str, Any]:
    profile = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(profile, dict):
        raise ValueError("model config is not a mapping")
    model_id = str(profile.get("serving_model_id") or profile.get("model_id") or "")
    revision = str(profile.get("model_revision") or "")
    verifier = profile.get("answer_verification") or {}
    if not model_id or not revision:
        raise ValueError("model profile needs pinned serving ID and revision")
    if profile.get("prompt_cache_enabled") is not False:
        raise ValueError("prompt cache must be disabled")
    if (profile.get("context_management") or {}).get("context_limit_tokens") != 8192:
        raise ValueError("input context must be fixed at 8192 tokens")
    if not isinstance(verifier, dict) or verifier.get("enabled") is not True:
        raise ValueError("production verifier must remain enabled")
    if verifier.get("model_id") != model_id or str(verifier.get("model_revision") or "") != revision:
        raise ValueError("draft/editor must use the same pinned snapshot")
    if max_tokens <= 0 or max_tokens > int(profile.get("max_tokens") or 0):
        raise ValueError("--max-tokens must be positive and within the model profile cap")
    serving_cap = profile.get("serving_max_tokens")
    if serving_cap is not None and max_tokens > int(serving_cap):
        raise ValueError("--max-tokens exceeds the serving profile cap")
    return profile


def selected_cases(runtime: dict[str, Any], args: argparse.Namespace) -> list[dict[str, Any]]:
    if args.calibration:
        if args.case_filter or args.arms or args.trials:
            raise ValueError("calibration uses only the two frozen setup prompts")
        prompts = runtime["output_budget_setup_prompts"]
        if len(prompts) != 2:
            raise ValueError("calibration requires two setup prompts")
        return [{"id": item["id"], "stratum": "setup_calibration",
                 "question": item["prompt"], "field_context": {}, "history": [],
                 "setup_dependency": None} for item in prompts]
    cases = runtime["cases"]
    if args.case_filter:
        wanted = {item.strip() for item in args.case_filter.split(",") if item.strip()}
        known = {item["id"] for item in cases}
        if not wanted or not wanted <= known:
            raise ValueError(f"unknown or empty case filter: {sorted(wanted - known)}")
        cases = [item for item in cases if item["id"] in wanted]
    return cases


def build_cells(runtime: dict[str, Any], args: argparse.Namespace) -> list[dict[str, Any]]:
    cases = selected_cases(runtime, args)
    if args.calibration:
        arms = ["retrieval_both"]
        trials = [1]
    else:
        arms = ARM_ORDER if not args.arms else tuple(item.strip() for item in args.arms.split(","))
        trials = [1, 2] if not args.trials else [int(item.strip()) for item in args.trials.split(",")]
        if not arms or len(set(arms)) != len(arms) or any(item not in ARM_ORDER for item in arms):
            raise ValueError("arms must be distinct retrieval 2x2 IDs")
        if not trials or len(set(trials)) != len(trials) or any(item not in {1, 2} for item in trials):
            raise ValueError("trials must be distinct values from 1,2")
    cells = []
    for case in cases:
        for trial in trials:
            ordered_arms = [arm for arm in (ARM_ORDER if trial == 1 else tuple(reversed(ARM_ORDER)))
                            if arm in arms]
            for arm in ordered_arms:
                cells.append({"cell_id": f"{case['id']}__{arm}__t{trial}",
                              "case_id": case["id"], "trial": trial, "arm": arm})
    return cells


def checked_prefix(rows: list[dict[str, Any]], cells: list[dict[str, Any]]) -> int:
    if len(rows) > len(cells):
        raise ValueError("ledger is longer than the frozen cell plan")
    for index, row in enumerate(rows):
        if row.get("cell_id") != cells[index]["cell_id"] or row.get("cell_index") != index:
            raise ValueError(f"ledger diverges from frozen cell plan at index {index}")
    return len(rows)


def seed_history(store: TraceStore, session_id: str, history: list[dict[str, str]]) -> None:
    if len(history) % 2 or any(history[i].get("role") != "user" or history[i + 1].get("role") != "assistant"
                                for i in range(0, len(history), 2)):
        raise ValueError("history must contain exact user/assistant pairs")
    for index in range(0, len(history), 2):
        question = history[index]["content"]
        answer = history[index + 1]["content"]
        if not isinstance(question, str) or not isinstance(answer, str):
            raise ValueError("history content must be text")
        store.create_turn(session_id, question, answer, parent_turn_id=None,
                          answer_status="final", system_state={}, trace={}, objectives={},
                          event_stream=False)
    observed = store.get_recent_session_turns(session_id, limit=max(1, len(history) // 2),
                                              exclude_replays=True)
    pairs = [(item["user_message"], item["answer"]) for item in observed]
    expected = [(history[i]["content"], history[i + 1]["content"])
                for i in range(0, len(history), 2)]
    if pairs != expected:
        raise ValueError("stored history differs from frozen user/assistant pairs")


def run_cell(run_dir: Path, index: int, cell: dict[str, Any], case: dict[str, Any],
             manifest: dict[str, Any], generator: Any | None, table_setup: Any | None) -> dict[str, Any]:
    base = {"cell_index": index, **cell, "case_sha256": canonical_sha256(case),
            "run_sha256": manifest["run_sha256"], "claim_eligible": False}
    if case.get("setup_dependency") and table_setup is None:
        return {**base, "status": "setup_blocked", "reason": case["setup_dependency"],
                "quality_assessment": "not_run"}
    cell_dir = run_dir / "cells" / cell["cell_id"]
    if cell_dir.exists():
        raise FileExistsError(f"cell directory already exists: {cell_dir}")
    cell_dir.mkdir(parents=True)
    db_path = cell_dir / "state.sqlite3"
    store = TraceStore(db_path)
    session = store.create_session(f"System validation {cell['cell_id']}",
                                   {"trace_storage_enabled": True}, {},
                                   tags=["claim_ineligible", "retrieval_2x2"])
    seed_history(store, session["session_id"], case.get("history") or [])
    session_context = {"field_context": case["field_context"]} if case.get("field_context") else None
    setup_receipt = None
    if case.get("setup_dependency"):
        try:
            setup_result = table_setup(store, session["session_id"], case, cell_dir)
        except Exception as exc:
            failure = {**base, "status": "setup_error", "quality_assessment": "not_run",
                       "error_type": type(exc).__name__, "error": str(exc)[:1000],
                       "database": str(db_path.relative_to(run_dir))}
            write_json(cell_dir / "setup_failure.json", failure)
            return failure
        if not isinstance(setup_result, dict):
            raise ValueError("table setup returned no result mapping")
        if setup_result.get("status") == "setup_blocked":
            blocked = {**base, "status": "setup_blocked", "quality_assessment": "not_run",
                       "reason": str(setup_result.get("reason") or "reviewed_table_import_unavailable"),
                       "setup_receipt": setup_result.get("setup_receipt")}
            write_json(cell_dir / "setup_blocked.json", blocked)
            return blocked
        session_context = setup_result.get("session_context")
        setup_receipt = setup_result.get("setup_receipt")
        if not isinstance(session_context, dict) or not isinstance(setup_receipt, dict):
            raise ValueError("table setup needs session_context and setup_receipt mappings")
        write_json(cell_dir / "setup_receipt.json", setup_receipt)
    settings = build_settings(db_path=db_path, artifact_root=cell_dir / "artifacts",
                              model_config_path=manifest["model_config_path"],
                              default_rag_config=manifest["rag_profile_path"],
                              network_mode="offline")
    controls = RETRIEVAL_COMPONENT_CONFIGURATIONS[cell["arm"]]
    request = AgentExecutionRequest(
        store=store, settings=settings, session_id=session["session_id"],
        message=case["question"], mode="agronomic_rag",
        model_id="mock" if manifest["mock"] else manifest["model_id"],
        rag_config=manifest["rag_profile_path"], max_tokens=manifest["max_tokens"],
        trace_options={"store_prompt_messages": True, "store_retrieved_text": True},
        session_context=session_context,
        generation_backend=generator, execution_class="observed_system_execution_nonclaim",
        document_retrieval_enabled=controls["document_retrieval"],
        graph_retrieval_enabled=controls["graph_retrieval"],
        arm_id=ARM_IDS[cell["arm"]],
    )
    started = time.perf_counter()
    try:
        result = ObservedSystemBenchmarkAdapter().execute(
            request, component_configuration_id=cell["arm"])
        record = result.to_dict()
        write_json(cell_dir / "execution.json", record)
        execution = record["execution"]
        trace = execution["turn"]["trace"]
        metadata = trace["metadata"]
        stages = metadata.get("answer_stages") or {}
        stage_receipts = execution["stage_receipts"]
        row = {
            **base, "status": "completed_execution", "quality_assessment": "ungraded",
            "cell_result": str((cell_dir / "execution.json").relative_to(run_dir)),
            "database": str(db_path.relative_to(run_dir)),
            "elapsed_seconds": round(time.perf_counter() - started, 3),
            "stage_receipt_count": len(stage_receipts),
            "answer_sha256": (stages.get("final") or {}).get("sha256"),
            "draft_sha256": (stages.get("draft") or {}).get("sha256"),
            "post_verification_sha256": (stages.get("post_verification") or {}).get("sha256"),
            "prompt_sha256": canonical_sha256(trace.get("prompt_messages") or []),
            "prompt_message_count": len(trace.get("prompt_messages") or []),
            "document_ids": [item.get("doc_id") for item in trace.get("retrieved_docs") or []],
            "graph_node_ids": [item.get("node_id") for item in trace.get("graph_hits") or []],
            "generation_stats": metadata.get("generation_stats"),
            "verification_generation_stats": (metadata.get("answer_verification") or {}).get("generation_stats"),
            "context_budget": metadata.get("context_budget"),
            "model_identity": metadata.get("model_identity"),
            "generation_fallback": metadata.get("generation_fallback"),
            "generation_unavailable": metadata.get("generation_unavailable"),
            "generation_bypass": metadata.get("generation_bypass"),
            "execution_fingerprints": metadata.get("execution_fingerprints"),
            "source_corpus_sha256": manifest["source_corpus_sha256"],
            "setup_receipt_sha256": canonical_sha256(setup_receipt) if setup_receipt else None,
        }
        return row
    except Exception as exc:
        failure = {**base, "status": "execution_error", "quality_assessment": "not_run",
                   "error_type": type(exc).__name__, "error": str(exc)[:1000],
                   "elapsed_seconds": round(time.perf_counter() - started, 3),
                   "database": str(db_path.relative_to(run_dir)),
                   "source_corpus_sha256": manifest["source_corpus_sha256"]}
        write_json(cell_dir / "failure.json", failure)
        return failure


def worker_main(run_dir: Path) -> int:
    manifest = json.loads((run_dir / "run_manifest.json").read_text(encoding="utf-8"))
    verify_run_dependencies(manifest, run_dir)
    runtime = load_runtime(Path(manifest["runtime_path"]), Path(manifest["runtime_digest_path"]))
    cells = json.loads((run_dir / "cell_plan.json").read_text(encoding="utf-8"))
    by_id = {case["id"]: case for case in (
        [{"id": item["id"], "stratum": "setup_calibration", "question": item["prompt"],
          "field_context": {}, "history": [], "setup_dependency": None}
         for item in runtime["output_budget_setup_prompts"]]
        if manifest["calibration"] else runtime["cases"]
    )}
    ledger = run_dir / "ledger.jsonl"
    start = checked_prefix(ledger_rows(ledger), cells)
    table_setup, _ = load_table_setup(manifest.get("table_setup_module_path"))
    generator = None
    if not manifest["mock"]:
        model_profile = yaml.safe_load(Path(manifest["model_config_path"]).read_text(encoding="utf-8"))
        generator = _build_mlx_generator(manifest["model_id"], model_profile,
                                         manifest["model_config_path"])
        if hasattr(generator, "max_tokens"):
            generator.max_tokens = manifest["max_tokens"]
    for index in range(start, len(cells)):
        cell = cells[index]
        write_json(run_dir / "current_cell.json",
                   {"cell_index": index, "cell_id": cell["cell_id"], "started_epoch": time.time()})
        reset_phase5_query_caches()
        try:
            row = run_cell(run_dir, index, cell, by_id[cell["case_id"]], manifest,
                           generator, table_setup)
        except Exception as exc:
            row = {"cell_index": index, **cell, "run_sha256": manifest["run_sha256"],
                   "status": "setup_error", "quality_assessment": "not_run",
                   "error_type": type(exc).__name__, "error": str(exc)[:1000]}
        append_jsonl(ledger, row)
        (run_dir / "current_cell.json").unlink(missing_ok=True)
        print(json.dumps({"completed_cells": index + 1, "total_cells": len(cells),
                          "cell_id": cell["cell_id"], "status": row["status"]}), flush=True)
    return 0


def parent_main(args: argparse.Namespace) -> int:
    runtime_path = args.runtime.resolve()
    digest_path = args.runtime_digest.resolve()
    runtime = load_runtime(runtime_path, digest_path)
    model_path = args.model_config.resolve()
    model_profile = validate_model_profile(model_path, max_tokens=args.max_tokens)
    model_id = str(model_profile.get("serving_model_id") or model_profile["model_id"])
    if args.model_id and args.model_id != model_id:
        raise ValueError("--model-id must match the pinned serving model profile")
    if (not math.isfinite(args.timeout_seconds) or args.timeout_seconds <= 0
            or not math.isfinite(args.cell_timeout_seconds) or args.cell_timeout_seconds <= 0):
        raise ValueError("timeouts must be finite positive seconds")
    backend = require_local_mlx(mock=args.mock)
    cells = build_cells(runtime, args)
    if not cells:
        raise ValueError("empty cell plan")
    output = args.output_dir.resolve()
    if output.exists() and any(output.iterdir()) and not args.resume:
        raise FileExistsError(f"nonempty output requires --resume: {output}")
    output.mkdir(parents=True, exist_ok=True)
    rag_source = args.rag_config.resolve()
    rag_payload = public_rag_config(rag_source)
    if rag_payload["private_knowledge"] != {"enabled": False, "required": False}:
        raise ValueError("private knowledge is not disabled")
    corpus_hashes = rag_artifact_receipt(rag_payload)
    profile_path = output / "rag_public_offline.yaml"
    serialized_rag = yaml.safe_dump(rag_payload, sort_keys=False)
    if profile_path.exists() and profile_path.read_text(encoding="utf-8") != serialized_rag:
        raise ValueError("resumed RAG profile bytes changed")
    profile_path.write_text(serialized_rag, encoding="utf-8")
    current_source_hashes = source_hashes()
    table_setup_path = args.table_setup_module.resolve() if args.table_setup_module else None
    if table_setup_path and not table_setup_path.is_file():
        raise FileNotFoundError(f"table setup module missing: {table_setup_path}")
    _, table_dependencies = load_table_setup(str(table_setup_path) if table_setup_path else None)
    run_basis = {
        "schema_version": SCHEMA,
        "runtime_sha256": sha256_file(runtime_path),
        "runtime_digest_sha256": sha256_file(digest_path),
        "source_cohort_sha256": COHORT_SHA256,
        "runner_sha256": sha256_file(Path(__file__)),
        "source_sha256": current_source_hashes,
        "table_setup_module_sha256": sha256_file(table_setup_path) if table_setup_path else None,
        "table_dependencies_sha256": table_dependencies,
        "source_corpus_sha256": canonical_sha256(corpus_hashes),
        "corpus_artifact_sha256": corpus_hashes,
        "model_config_sha256": sha256_file(model_path),
        "rag_source_sha256": sha256_file(rag_source),
        "rag_public_profile_sha256": sha256_file(profile_path),
        "model_id": model_id,
        "model_revision": str(model_profile["model_revision"]),
        "model_backend": backend,
        "mock": bool(args.mock),
        "calibration": bool(args.calibration),
        "max_tokens": args.max_tokens,
        "generation_settings": {key: model_profile.get(key) for key in
                                ("temperature", "top_p", "top_k", "seed", "use_stream_generate")},
        "verifier_settings": model_profile["answer_verification"],
        "context_limit_tokens": 8192,
        "prompt_cache_enabled": False,
        "network_mode": "offline",
        "cells_sha256": canonical_sha256(cells),
        "cell_count": len(cells),
    }
    manifest = {**run_basis, "run_sha256": canonical_sha256(run_basis),
                "runtime_path": str(runtime_path), "runtime_digest_path": str(digest_path),
                "model_config_path": str(model_path), "rag_source_path": str(rag_source),
                "rag_profile_path": str(profile_path),
                "table_setup_module_path": str(table_setup_path) if table_setup_path else None}
    manifest_path = output / "run_manifest.json"
    if manifest_path.exists():
        old = json.loads(manifest_path.read_text(encoding="utf-8"))
        if old != manifest:
            raise ValueError("resume manifest mismatch")
    else:
        write_json(manifest_path, manifest)
        write_json(output / "cell_plan.json", cells)
    verify_run_dependencies(manifest, output)
    ledger = output / "ledger.jsonl"
    ledger.touch(exist_ok=True)
    start = checked_prefix(ledger_rows(ledger), cells)
    if start == len(cells):
        print(json.dumps({"status": "already_complete", "cells": len(cells),
                          "ledger": str(ledger), "run_sha256": manifest["run_sha256"]}))
        return 0
    environment = dict(os.environ)
    environment["AGRONOMY_AGENT_PRIVATE_KNOWLEDGE"] = "disabled"
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONPATH"] = str(ROOT / "src")
    child = subprocess.Popen([sys.executable, str(Path(__file__).resolve()),
                              "--worker", str(output)], cwd=ROOT, env=environment,
                             stdout=(output / "worker.log").open("a", encoding="utf-8"),
                             stderr=subprocess.STDOUT)
    started = time.monotonic()
    last_count = start
    timeout_reason = None
    try:
        while child.poll() is None:
            time.sleep(1)
            count = checked_prefix(ledger_rows(ledger, tolerate_partial_tail=True), cells)
            if count != last_count:
                last_count = count
                print(json.dumps({"checkpoint": count, "total": len(cells),
                                  "ledger": str(ledger)}), flush=True)
            if time.monotonic() - started > args.timeout_seconds:
                timeout_reason = "outer_timeout"
                break
            current = output / "current_cell.json"
            try:
                state = json.loads(current.read_text(encoding="utf-8"))
                if time.time() - float(state["started_epoch"]) > args.cell_timeout_seconds:
                    timeout_reason = "cell_timeout"
                    break
            except (FileNotFoundError, json.JSONDecodeError, KeyError, ValueError):
                pass  # The worker may remove this file between cells.
    finally:
        if timeout_reason is None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
    if timeout_reason:
        child.terminate()
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=5)
        preserve_partial_ledger_tail(ledger)
        rows = ledger_rows(ledger)
        index = checked_prefix(rows, cells)
        if index < len(cells):
            append_jsonl(ledger, {"cell_index": index, **cells[index],
                                  "run_sha256": manifest["run_sha256"],
                                  "status": "terminal_timeout", "reason": timeout_reason,
                                  "quality_assessment": "not_run",
                                  "partial_artifacts_retained": True})
        print(json.dumps({"status": timeout_reason, "completed_cells": len(ledger_rows(ledger)),
                          "total_cells": len(cells), "ledger": str(ledger)}))
        return 2
    rows = ledger_rows(ledger)
    checked_prefix(rows, cells)
    try:
        verify_run_dependencies(manifest, output)
        drift_error = None
    except (OSError, KeyError, ValueError, TypeError) as exc:
        drift_error = f"{type(exc).__name__}: {exc}"
    status_counts: dict[str, int] = {}
    for row in rows:
        status_counts[row["status"]] = status_counts.get(row["status"], 0) + 1
    complete = len(rows) == len(cells)
    print(json.dumps({"status": "input_drift" if drift_error
                      else "complete" if complete else "worker_incomplete",
                      "worker_exit_code": child.returncode, "completed_cells": len(rows),
                      "total_cells": len(cells), "status_counts": status_counts,
                      "drift_error": drift_error,
                      "ledger": str(ledger), "run_sha256": manifest["run_sha256"]}, sort_keys=True))
    return 0 if complete and child.returncode == 0 and drift_error is None else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--runtime", type=Path, default=HERE / "runtime_cases.json")
    parser.add_argument("--runtime-digest", type=Path, default=HERE / "runtime_cases.json.sha256")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--model-config", type=Path, default=ROOT / "configs/model.yaml")
    parser.add_argument("--rag-config", type=Path, default=ROOT / "configs/rag.yaml")
    parser.add_argument("--table-setup-module", type=Path,
                        help="Reviewed field-table fixture setup helper; omitted means setup_blocked")
    parser.add_argument("--model-id")
    parser.add_argument("--max-tokens", type=int, required=False)
    parser.add_argument("--case-filter", help="Comma-separated frozen case IDs")
    parser.add_argument("--arms", help="Comma-separated retrieval configuration IDs")
    parser.add_argument("--trials", help="Comma-separated subset of 1,2")
    parser.add_argument("--calibration", action="store_true", help="Only the two setup prompts")
    parser.add_argument("--mock", action="store_true", help="No model/provider call")
    parser.add_argument("--timeout-seconds", type=float, default=7200)
    parser.add_argument("--cell-timeout-seconds", type=float, default=600)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.worker:
        return worker_main(args.worker)
    if args.output_dir is None or args.max_tokens is None:
        parser.error("--output-dir and --max-tokens are required")
    return parent_main(args)


if __name__ == "__main__":
    raise SystemExit(main())
