"""Reviewed private-table setup for the frozen sv24-08 diagnostic.

Only the exposed pilot manifest and fixture are read. The gold-case file is
never opened, and no answer or expected value is placed in session context.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from agronomy_agent.server.storage.field_data_store import (
    commit_import,
    preview_import,
    query_import,
)


ROOT = Path(__file__).resolve().parents[3]
PILOT = ROOT / "data/eval/field_data_pilot_v1"
BUNDLE_ID = "akron-01"
CASE_ID = "sv24-08"


def _sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def reviewed_table_dependencies() -> dict[str, str]:
    """Hash the exact exposed pilot inputs used by the reviewed setup."""
    manifest_path = PILOT / "manifest.json"
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    if manifest.get("schema_version") != "field_data_pilot.v1":
        raise ValueError("unexpected reviewed pilot manifest schema")
    matches = [bundle for bundle in manifest["bundles"] if bundle.get("id") == BUNDLE_ID]
    if len(matches) != 1:
        raise ValueError("reviewed akron-01 bundle missing or duplicated")
    bundle = matches[0]
    fixture_path = (PILOT / bundle["fixture_path"]).resolve()
    if not fixture_path.is_relative_to(PILOT.resolve()):
        raise ValueError("reviewed fixture escaped pilot directory")
    fixture_bytes = fixture_path.read_bytes()
    fixture_sha = _sha256(fixture_bytes)
    if fixture_sha != bundle["fixture_sha256"] or len(fixture_bytes) != bundle["fixture_bytes"]:
        raise ValueError("reviewed fixture checksum or byte count mismatch")
    mapping = bundle["mapping"]
    if not isinstance(mapping, dict):
        raise ValueError("reviewed mapping is not a mapping")
    mapping_sha = _sha256(json.dumps(mapping, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8"))
    return {
        "pilot_manifest_sha256": _sha256(manifest_bytes),
        "pilot_fixture_sha256": fixture_sha,
        "pilot_mapping_sha256": mapping_sha,
    }


def setup_table_case(store: Any, session_id: str, case: dict[str, Any], cell_dir: str | Path) -> dict[str, Any]:
    """Commit the reviewed source table for an isolated store/session.

    Return the trusted session_context accepted by AgentExecutionRequest and
    a source-bound setup receipt. Any mismatch raises ValueError, leaving the
    runner to record this case as setup-blocked.
    """
    if case.get("id") != CASE_ID or case.get("stratum") != "source_table_lookup":
        raise ValueError("table setup is restricted to frozen sv24-08")
    if not store.get_session(session_id, include_turns=False):
        raise ValueError("table setup requires an existing isolated session")
    fixture_relative = case.get("field_context", {}).get("imported_fixture")
    dependencies = reviewed_table_dependencies()
    manifest_bytes = (PILOT / "manifest.json").read_bytes()
    if _sha256(manifest_bytes) != dependencies["pilot_manifest_sha256"]:
        raise ValueError("reviewed pilot manifest changed during table setup")
    manifest = json.loads(manifest_bytes)
    if manifest.get("schema_version") != "field_data_pilot.v1":
        raise ValueError("unexpected reviewed pilot manifest schema")
    matches = [bundle for bundle in manifest["bundles"] if bundle.get("id") == BUNDLE_ID]
    if len(matches) != 1:
        raise ValueError("reviewed akron-01 bundle missing or duplicated")
    bundle = matches[0]
    canonical_fixture = (PILOT / bundle["fixture_path"]).resolve()
    if fixture_relative != str(canonical_fixture.relative_to(ROOT)):
        raise ValueError("case fixture differs from reviewed akron-01 bundle")
    fixture = canonical_fixture.read_bytes()
    fixture_sha = _sha256(fixture)
    if fixture_sha != dependencies["pilot_fixture_sha256"]:
        raise ValueError("reviewed fixture changed during table setup")
    if fixture_sha != bundle["fixture_sha256"] or len(fixture) != bundle["fixture_bytes"]:
        raise ValueError("reviewed fixture checksum or byte count mismatch")
    if not isinstance(bundle.get("row_count"), int) or bundle["row_count"] <= 0:
        raise ValueError("reviewed bundle row count missing")
    mapping_sha = _sha256(json.dumps(bundle["mapping"], ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8"))
    if mapping_sha != dependencies["pilot_mapping_sha256"]:
        raise ValueError("reviewed mapping changed during table setup")
    cell_identity = str(Path(cell_dir).resolve()) + "\0" + session_id
    workspace_id = "synthetic-table-" + _sha256(cell_identity.encode())[:20]
    field = store.create_phase4_field_context(
        workspace={"id": workspace_id, "organization_id": "synthetic-validation"},
        created_by_user_id="synthetic-validation",
        payload={"display_name": "Synthetic Akron table case", "region_text": "Akron research site, Colorado",
                 "country": "United States", "province_state": "Colorado", "crop_current": "wheat",
                 "metadata": {"diagnostic_case_id": CASE_ID, "synthetic": True,
                              "geometry_status": "no reviewed polygon; sample points are not field boundary"}},
    )
    preview = preview_import(store, field, "synthetic-validation", canonical_fixture.name, fixture)
    if preview.get("status") != "preview" or preview["profile"].get("row_count") != bundle["row_count"]:
        raise ValueError("reviewed fixture preview row count mismatch")
    committed = commit_import(store, field, preview["import_id"], bundle["mapping"])["import"]
    if (committed.get("status") != "committed"
            or committed.get("field_id") != field["id"]
            or committed.get("source_sha256") != fixture_sha
            or committed.get("row_count") != bundle["row_count"]):
        raise ValueError("reviewed fixture commit contract mismatch")
    # Observe the stored rows through the same registered query backing the
    # customer app. This is a setup check, not the model's answer or gold input.
    counted = query_import(store, field["id"], committed["import_id"], {"operation": "count"})
    if counted.get("value") != committed["row_count"]:
        raise ValueError("stored table count differs from committed row count")
    return {
        "session_context": {
            "field_context": {"field_context_id": field["id"]},
            "field_context_id": field["id"],
            "field_access_authorized": True,
            "field_access_workspace_id": field["workspace_id"],
        },
        "setup_receipt": {
            "status": "reviewed_private_import_committed",
            "case_id": CASE_ID,
            "bundle_id": BUNDLE_ID,
            "field_context_id": field["id"],
            "workspace_id": field["workspace_id"],
            "import_id": committed["import_id"],
            "manifest_sha256": _sha256(manifest_bytes),
            "fixture_sha256": fixture_sha,
            "pilot_mapping_sha256": dependencies["pilot_mapping_sha256"],
            "committed_source_sha256": committed["source_sha256"],
            "mapping_sha256": committed["mapping_sha256"],
            "committed_row_count": committed["row_count"],
            "stored_count_value": counted["value"],
            "stored_count_receipt_sha256": counted.get("receipt_sha256"),
        },
    }
