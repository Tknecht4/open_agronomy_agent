"""Build and verify the immutable field-v2 evaluation instrument archive.

Run from any directory. This allowlist deliberately includes offline grading
material and must never be used as a model-host capsule.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
import tempfile


ROOT = Path(__file__).resolve().parents[3]
ARTIFACT_DIR = ROOT / "docs/reviews/artifacts/system-validation-20260928"
ARCHIVE = ARTIFACT_DIR / "instrument-field-v2.tar.gz"
MANIFEST = ARTIFACT_DIR / "instrument-field-v2-manifest.json"
METADATA_ARCHIVE = ARTIFACT_DIR / "run-metadata-field-v2.tar.gz"
METADATA_MANIFEST = ARTIFACT_DIR / "run-metadata-field-v2-manifest.json"
RUNNER = "outputs/system-validation-20260928/runner/run_retrieval_2x2_field_v2.py"
RUNNER_SHA256 = "84e64d8d045d156cc17ceb7bad1d1b90e607974bc316d623dbbfa1c2c6c069ec"

# Preserve the original instrument's frozen runtime, gold, cohort, and helper.
# Add only source/receipts needed to reconstruct the field-v2 instrument.
FILES = (
    "outputs/system-validation-20260928/runner/run_retrieval_2x2.py",
    "outputs/system-validation-20260928/runner/runtime_cases.json",
    "outputs/system-validation-20260928/runner/runtime_cases.json.sha256",
    "outputs/system-validation-20260928/runner/audit_preflight.py",
    "outputs/system-validation-20260928/runner/README.md",
    "outputs/system-validation-20260928/runner/grading_local.json",
    "outputs/system-validation-20260928/runner/grading_local.json.sha256",
    "outputs/system-validation-20260928/cohort/table_setup.py",
    "outputs/system-validation-20260928/cohort/cohort.json",
    "outputs/system-validation-20260928/cohort/manifest.json",
    "outputs/system-validation-20260928/cohort/README.md",
    RUNNER,
    "outputs/system-validation-20260928/runner/README-field-v2.md",
    "outputs/system-validation-20260928/cohort/build_cohort.py",
    "outputs/system-validation-20260928/cohort/table_setup_proof.json",
    "outputs/system-validation-20260928/runner/prepare_inputs.py",
    "outputs/system-validation-20260928/runner/derive_model_profile.py",
    "outputs/system-validation-20260928/colab/build_capsule_v2.py",
    "outputs/system-validation-20260928/colab/capsule-files-v2.json",
    "outputs/system-validation-20260928/colab/capsule-summary-v2.json",
    "outputs/system-validation-20260928/colab/launch_calibration.py",
    "outputs/system-validation-20260928/colab/launch_qwen_calibration.py",
    "outputs/system-validation-20260928/colab/verify_field_v2.py",
    "outputs/system-validation-20260928/colab/launch_field_v2.py",
    "outputs/system-validation-20260928/colab/collect_gemma_field_v2.py",
    "outputs/system-validation-20260928/colab/collect_qwen_field_v2.py",
    "docs/reviews/artifacts/system-validation-20260928/field-v2-runner-delta.json",
    "docs/reviews/artifacts/system-validation-20260928/field-v2-mock-proof.json",
    "outputs/system-validation-20260928/analysis/export_public_run.py",
    "outputs/system-validation-20260928/analysis/restore_public_run.py",
    "outputs/system-validation-20260928/analysis/package_evaluation_artifacts.py",
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def source_bytes() -> dict[str, bytes]:
    payloads: dict[str, bytes] = {}
    for relative in sorted(FILES):
        path = ROOT / relative
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f"missing, symlinked, or escaped package file: {relative}")
        data = path.read_bytes()
        # A code guard containing the literal '/Users/' is not a private path;
        # require a username component before rejecting an actual home path.
        if re.search(rb"/(?:Users|home)/[A-Za-z0-9._-]+", data):
            raise ValueError(f"private home path in package file: {relative}")
        if re.search(rb"(?:hf_|ghp_|sk-)[A-Za-z0-9_-]{20,}", data):
            raise ValueError(f"possible credential in package file: {relative}")
        payloads[relative] = data
    if sha256(payloads[RUNNER]) != RUNNER_SHA256:
        raise ValueError("field-v2 runner bytes differ from final reviewed source")
    return payloads


def archive_bytes(payloads: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=buffer, compresslevel=9, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as tar:
            for relative, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(relative)
                entry.size = len(data)
                entry.mode = 0o644
                entry.mtime = 0
                entry.uid = entry.gid = 0
                entry.uname = entry.gname = ""
                tar.addfile(entry, io.BytesIO(data))
    return buffer.getvalue()


def build() -> None:
    if ARCHIVE.exists() or MANIFEST.exists():
        raise FileExistsError("field-v2 instrument is immutable; verify existing files")
    payloads = source_bytes()
    archive = archive_bytes(payloads)
    manifest = {
        "schema_version": "system_validation_field_v2_instrument_manifest.v1",
        "archive": ARCHIVE.name,
        "sha256": sha256(archive),
        "bytes": len(archive),
        "runner_sha256": RUNNER_SHA256,
        "files": {
            relative: {"sha256": sha256(data), "bytes": len(data)}
            for relative, data in sorted(payloads.items())
        },
        "boundary": (
            "Exposed development evaluation archive, including frozen gold and rubrics. "
            "Keep local for grading; never upload the complete archive to a model host, "
            "runtime retrieval, or training. Original instrument.tar.gz is unchanged."
        ),
        "extraction": "Extract at repository root to restore original repository-relative paths.",
        "verification": (
            "python outputs/system-validation-20260928/analysis/"
            "package_evaluation_artifacts.py verify"
        ),
        "privacy_scan": (
            "Explicit safe-file allowlist; reject actual private home-directory "
            "paths and credential-shaped literals. A bare source-code guard "
            "prefix without a username is not a private path."
        ),
    }
    ARCHIVE.write_bytes(archive)
    MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    verify()


def verify() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    archive = ARCHIVE.read_bytes()
    if manifest["sha256"] != sha256(archive) or manifest["bytes"] != len(archive):
        raise ValueError("archive hash or size mismatch")
    if set(manifest["files"]) != set(FILES):
        raise ValueError("manifest member set differs from allowlist")
    with tempfile.TemporaryDirectory(prefix="field-v2-instrument-verify-") as temporary:
        extracted = Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as tar:
            members = tar.getmembers()
            if [member.name for member in members] != sorted(FILES):
                raise ValueError("archive member set or ordering mismatch")
            for member in members:
                if not member.isfile() or member.mtime != 0 or member.uid != 0 or member.gid != 0:
                    raise ValueError(f"unsafe or non-deterministic archive member: {member.name}")
                data = tar.extractfile(member).read()
                expected = manifest["files"][member.name]
                if sha256(data) != expected["sha256"] or len(data) != expected["bytes"]:
                    raise ValueError(f"member hash or size mismatch: {member.name}")
                target = extracted / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                if sha256(target.read_bytes()) != expected["sha256"]:
                    raise ValueError(f"extracted member hash mismatch: {member.name}")
    if manifest["runner_sha256"] != RUNNER_SHA256:
        raise ValueError("runner identity mismatch")
    print(json.dumps({"archive_sha256": manifest["sha256"], "files_verified": len(members)}))


def build_metadata(run_arguments: list[str]) -> None:
    """Freeze exact native cell plans/manifests after all four exports exist."""
    if METADATA_ARCHIVE.exists() or METADATA_MANIFEST.exists():
        raise FileExistsError("run metadata archive is immutable; verify existing files")
    names = {"gemma-v1", "qwen-v1-partial", "gemma-field-v2", "qwen-field-v2"}
    if len(run_arguments) != 4:
        raise ValueError("supply exactly four --run NAME=REPO_RELATIVE_RUN_DIR arguments")
    runs: dict[str, str] = {}
    for argument in run_arguments:
        name, separator, relative = argument.partition("=")
        if not separator or name not in names or name in runs:
            raise ValueError(f"unknown or duplicate run: {argument}")
        runs[name] = relative
    if set(runs) != names:
        raise ValueError("all four named runs are required")
    payloads: dict[str, bytes] = {}
    run_receipts: dict[str, dict[str, str]] = {}
    for name, relative in sorted(runs.items()):
        run_path = (ROOT / relative).resolve()
        if not run_path.is_relative_to(ROOT):
            raise ValueError(f"run path escapes repository: {relative}")
        receipt_path = ARTIFACT_DIR / f"{name}-raw-receipt.json"
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        manifest_path = run_path / "run_manifest.json"
        native_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if native_manifest["run_sha256"] != receipt["run_sha256"]:
            raise ValueError(f"native run identity differs from raw export: {name}")
        for basename in ("cell_plan.json", "run_manifest.json"):
            path = run_path / basename
            if not path.is_file() or path.is_symlink():
                raise ValueError(f"missing or symlinked native metadata: {path}")
            data = path.read_bytes()
            if re.search(rb"/(?:Users|home)/[A-Za-z0-9._-]+", data):
                raise ValueError(f"private home path in native metadata: {path}")
            payloads[path.relative_to(ROOT).as_posix()] = data
        run_receipts[name] = {
            "native_run_dir": run_path.relative_to(ROOT).as_posix(),
            "run_sha256": receipt["run_sha256"],
            "raw_receipt_sha256": sha256(receipt_path.read_bytes()),
        }
    archive = archive_bytes(payloads)
    manifest = {
        "schema_version": "system_validation_field_v2_run_metadata_manifest.v1",
        "archive": METADATA_ARCHIVE.name,
        "sha256": sha256(archive),
        "bytes": len(archive),
        "files": {relative: {"sha256": sha256(data), "bytes": len(data)}
                  for relative, data in sorted(payloads.items())},
        "runs": run_receipts,
        "boundary": (
            "Exact native cell_plan.json and run_manifest.json bytes for four retained runs. "
            "No raw traces, SQLite, model weights, private balances, or grades. "
            "Pair with separately hash-bound public raw exports."
        ),
    }
    METADATA_ARCHIVE.write_bytes(archive)
    METADATA_MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    verify_metadata()


def verify_metadata() -> None:
    manifest = json.loads(METADATA_MANIFEST.read_text(encoding="utf-8"))
    archive = METADATA_ARCHIVE.read_bytes()
    if sha256(archive) != manifest["sha256"] or len(archive) != manifest["bytes"]:
        raise ValueError("run metadata archive hash or size mismatch")
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as tar:
        members = tar.getmembers()
        if [member.name for member in members] != sorted(manifest["files"]):
            raise ValueError("run metadata member set or ordering mismatch")
        for member in members:
            if not member.isfile() or member.mtime != 0 or member.uid != 0 or member.gid != 0:
                raise ValueError(f"unsafe run metadata member: {member.name}")
            data = tar.extractfile(member).read()
            expected = manifest["files"][member.name]
            if sha256(data) != expected["sha256"] or len(data) != expected["bytes"]:
                raise ValueError(f"run metadata member mismatch: {member.name}")
    print(json.dumps({"metadata_archive_sha256": manifest["sha256"], "files_verified": len(members)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("build", "verify", "build-metadata", "verify-metadata"))
    parser.add_argument("--run", action="append", default=[], metavar="NAME=REPO_RELATIVE_RUN_DIR")
    args = parser.parse_args()
    if args.action == "build-metadata":
        build_metadata(args.run)
    else:
        {"build": build, "verify": verify, "verify-metadata": verify_metadata}[args.action]()
