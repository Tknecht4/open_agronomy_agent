#!/usr/bin/env python3
"""Read-only mechanical audit of the pinned Gemma 2x2 result; never loads grading files."""

from __future__ import annotations

import collections
import hashlib
import json
import statistics
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
COLAB = ROOT / "outputs/system-validation-20260928/colab/results-v1"
RUN = COLAB / "outputs/gemma-retrieval-192"
RUNNER = ROOT / "outputs/system-validation-20260928/runner"
PILOT = ROOT / "data/eval/field_data_pilot_v1"
ARMS = ("retrieval_neither", "retrieval_document_only", "retrieval_graph_only", "retrieval_both")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def summary(values: list[float]) -> dict[str, float | int | None]:
    if not values:
        return {"n": 0, "sum": None, "mean": None, "median": None, "p95": None,
                "min": None, "max": None}
    ordered = sorted(values)
    return {"n": len(values), "sum": round(sum(values), 3),
            "mean": round(statistics.mean(values), 3),
            "median": round(statistics.median(values), 3),
            "p95": round(ordered[min(len(ordered) - 1, int(len(ordered) * .95 + .999999) - 1)], 3),
            "min": round(ordered[0], 3), "max": round(ordered[-1], 3)}


def group_summary(items: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "cells": len(items),
        "draft_model_calls": sum(item["draft_call"] for item in items),
        "editor_model_calls": sum(item["editor_call"] for item in items),
        "generation_bypasses": sum(item["bypass"] for item in items),
        "draft_at_640_tokens": sum(item["draft_at_cap"] for item in items),
        "editor_at_220_tokens": sum(item["editor_at_cap"] for item in items),
        "editor_evidence_truncated": sum(item["editor_evidence_truncated"] for item in items),
        "document_hits": sum(item["document_hits"] for item in items),
        "graph_hits": sum(item["graph_hits"] for item in items),
        "ledger_seconds": summary([item["ledger_seconds"] for item in items]),
        "core_seconds": summary([item["core_seconds"] for item in items]),
        "draft_generation_seconds": summary([item["draft_seconds"] for item in items
                                              if item["draft_seconds"] is not None]),
        "editor_generation_seconds": summary([item["editor_seconds"] for item in items
                                               if item["editor_seconds"] is not None]),
    }


def main() -> None:
    failures: list[str] = []
    manifest = json.loads((RUN / "run_manifest.json").read_text())
    plan = json.loads((RUN / "cell_plan.json").read_text())
    rows = [json.loads(line) for line in (RUN / "ledger.jsonl").read_text().splitlines() if line.strip()]
    runtime = json.loads((RUNNER / "runtime_cases.json").read_text())
    by_case = {case["id"]: case for case in runtime["cases"]}
    capsule = json.loads((COLAB / "capsule-files.json").read_text())
    driver = json.loads((COLAB / "primary-status.json").read_text())
    provision = json.loads((COLAB / "system-validation-provision.json").read_text())
    worker_log = (RUN / "worker.log").read_text()
    driver_log = (COLAB / "primary-driver.log").read_text()

    basis = {key: value for key, value in manifest.items() if key not in {
        "run_sha256", "runtime_path", "runtime_digest_path", "model_config_path",
        "rag_source_path", "rag_profile_path", "table_setup_module_path",
    }}
    if canonical(basis) != manifest["run_sha256"]:
        failures.append("run_manifest_identity")
    if canonical(plan) != manifest["cells_sha256"] or len(plan) != 192 or len(rows) != 192:
        failures.append("cell_plan_or_ledger_count")
    if manifest.get("mock") is not False or manifest.get("model_backend") != "mlx":
        failures.append("backend_declaration")
    if sha(RUN / "rag_public_offline.yaml") != manifest["rag_public_profile_sha256"]:
        failures.append("run_rag_profile_hash")
    local_bindings = {
        "runner_sha256": RUNNER / "run_retrieval_2x2.py",
        "table_setup_module_sha256": ROOT / "outputs/system-validation-20260928/cohort/table_setup.py",
        "runtime_sha256": RUNNER / "runtime_cases.json",
        "runtime_digest_sha256": RUNNER / "runtime_cases.json.sha256",
        "model_config_sha256": ROOT / "configs/model.yaml",
        "rag_source_sha256": ROOT / "configs/rag.yaml",
    }
    for key, path in local_bindings.items():
        if sha(path) != manifest[key]:
            failures.append(f"local_hash:{key}")
    for path, expected in {**manifest["source_sha256"],
                           **manifest["corpus_artifact_sha256"]}.items():
        local = ROOT / path
        if not local.is_file() or sha(local) != expected:
            failures.append(f"local_source_or_corpus:{path}")
    pilot_manifest_bytes = (PILOT / "manifest.json").read_bytes()
    pilot = json.loads(pilot_manifest_bytes)
    bundle = next((item for item in pilot["bundles"] if item.get("id") == "akron-01"), None)
    if bundle is None:
        failures.append("pilot_bundle_missing")
        bundle = {"fixture_path": "fixtures/akron-01.csv", "mapping": {}}
    table_hashes = {
        "pilot_manifest_sha256": hashlib.sha256(pilot_manifest_bytes).hexdigest(),
        "pilot_fixture_sha256": sha(PILOT / bundle["fixture_path"]),
        "pilot_mapping_sha256": canonical(bundle["mapping"]),
    }
    if table_hashes != manifest["table_dependencies_sha256"]:
        failures.append("pilot_table_dependency_hashes")
    capsule_mismatches = []
    for relative, expected in {
        **manifest["source_sha256"], **manifest["corpus_artifact_sha256"],
        "configs/model.yaml": manifest["model_config_sha256"],
        "configs/rag.yaml": manifest["rag_source_sha256"],
        "outputs/system-validation-20260928/runner/run_retrieval_2x2.py": manifest["runner_sha256"],
        "outputs/system-validation-20260928/cohort/table_setup.py": manifest["table_setup_module_sha256"],
        "outputs/system-validation-20260928/runner/runtime_cases.json": manifest["runtime_sha256"],
        "data/eval/field_data_pilot_v1/manifest.json": table_hashes["pilot_manifest_sha256"],
        "data/eval/field_data_pilot_v1/fixtures/akron-01.csv": table_hashes["pilot_fixture_sha256"],
    }.items():
        if (capsule["files"].get(relative) or {}).get("sha256") != expected:
            capsule_mismatches.append(relative)
    if capsule_mismatches:
        failures.append("capsule_hashes")
    if (driver.get("status"), driver.get("exit_code")) != ("completed", 0):
        failures.append("driver_status")
    if '"drift_error": null' not in driver_log or '"status": "complete"' not in driver_log:
        failures.append("driver_end_drift_receipt")
    if "Traceback" in worker_log:
        failures.append("worker_traceback")

    records: list[dict[str, Any]] = []
    identity_statuses = collections.Counter()
    bypass_reasons = collections.Counter()
    budget_statuses = collections.Counter()
    editor_budget_statuses = collections.Counter()
    editor_actions = collections.Counter()
    stage_states = collections.Counter()
    cold_loads: list[dict[str, Any]] = []
    slowest_editor: dict[str, Any] | None = None
    stale_bypass_stats = 0
    prior_draft_stats: dict[str, Any] | None = None
    table_receipts = 0
    for index, row in enumerate(rows):
        cell = plan[index]
        cell_id = cell["cell_id"]
        if (row.get("cell_id"), row.get("cell_index"), row.get("run_sha256")) != (
            cell_id, index, manifest["run_sha256"]
        ) or row.get("status") != "completed_execution":
            failures.append(f"ledger_identity_or_status:{cell_id}")
        if row.get("case_sha256") != canonical(by_case[cell["case_id"]]):
            failures.append(f"case_identity:{cell_id}")
        execution = json.loads((RUN / row["cell_result"]).read_text())["execution"]
        trace = execution["turn"]["trace"]
        metadata = trace["metadata"]
        stages = execution["stage_receipts"]
        if len(stages) != 17 or row.get("stage_receipt_count") != 17:
            failures.append(f"stage_count:{cell_id}")
        if len({item["stage_id"] for item in stages}) != 17:
            failures.append(f"stage_unique:{cell_id}")
        stage_states.update(item["state"] for item in stages)
        answer_stages = execution["answer_stages"]
        for name, field in (("draft", "draft_sha256"), ("post_verification", "post_verification_sha256"),
                            ("final", "answer_sha256")):
            if answer_stages[name]["sha256"] != row.get(field):
                failures.append(f"answer_stage_hash:{cell_id}:{name}")
            if hashlib.sha256(answer_stages[name]["text"].encode("utf-8")).hexdigest() != answer_stages[name]["sha256"]:
                failures.append(f"answer_stage_text_hash:{cell_id}:{name}")
        if execution["answer"] != answer_stages["final"]["text"]:
            failures.append(f"answer_stage_text:{cell_id}")
        if canonical(trace.get("prompt_messages") or []) != row.get("prompt_sha256"):
            failures.append(f"prompt_hash:{cell_id}")
        if cell["arm"] in {"retrieval_neither", "retrieval_graph_only"} and trace.get("retrieved_docs"):
            failures.append(f"disabled_documents:{cell_id}")
        if cell["arm"] in {"retrieval_neither", "retrieval_document_only"} and trace.get("graph_hits"):
            failures.append(f"disabled_graph:{cell_id}")
        if row.get("quality_assessment") != "ungraded" or row.get("claim_eligible") is not False:
            failures.append(f"claim_boundary:{cell_id}")
        identity = row.get("model_identity") or {}
        identity_statuses[identity.get("status")] += 1
        if (identity.get("backend") != "mlx_local" or identity.get("status") != "verified_direct_loader"
                or identity.get("configured_model_id") != manifest["model_id"]
                or identity.get("configured_model_revision") != manifest["model_revision"]
                or (not row.get("generation_bypass") and identity.get("response_model_id") != manifest["model_id"])
                or (row.get("generation_bypass") and identity.get("response_model_id") is not None)
                or identity.get("verification_errors")):
            failures.append(f"loader_identity:{cell_id}")
        if cell["case_id"] == "sv24-08":
            table_receipts += 1
            setup_path = RUN / "cells" / cell_id / "setup_receipt.json"
            setup = json.loads(setup_path.read_text())
            if (canonical(setup) != row.get("setup_receipt_sha256")
                    or setup.get("status") != "reviewed_private_import_committed"
                    or setup.get("manifest_sha256") != table_hashes["pilot_manifest_sha256"]
                    or setup.get("fixture_sha256") != table_hashes["pilot_fixture_sha256"]
                    or setup.get("pilot_mapping_sha256") != table_hashes["pilot_mapping_sha256"]
                    or setup.get("stored_count_value") != 13
                    or setup.get("committed_row_count") != 13):
                failures.append(f"table_receipt:{cell_id}")
        elif row.get("setup_receipt_sha256") is not None:
            failures.append(f"unexpected_table_receipt:{cell_id}")

        bypass = bool(row.get("generation_bypass"))
        draft_stats = row.get("generation_stats") or {}
        editor_stats = row.get("verification_generation_stats") or {}
        if bypass:
            bypass_reasons[row["generation_bypass"].get("reason")] += 1
            if draft_stats == prior_draft_stats:
                stale_bypass_stats += 1
        else:
            prior_draft_stats = draft_stats
            if not draft_stats or (draft_stats.get("seed_application") or {}).get("status") != "applied":
                failures.append(f"draft_generation_receipt:{cell_id}")
            if draft_stats.get("prompt_cache_enabled") is not False or draft_stats.get("prompt_cache_hit"):
                failures.append(f"draft_prompt_cache:{cell_id}")
            if draft_stats.get("model_load_ms") is not None:
                cold_loads.append({"cell_id": cell_id, "model_load_seconds": round(draft_stats["model_load_ms"] / 1000, 3)})
        if editor_stats and ((editor_stats.get("seed_application") or {}).get("status") != "applied"
                             or editor_stats.get("prompt_cache_enabled") is not False):
            failures.append(f"editor_generation_receipt:{cell_id}")
        if editor_stats and (slowest_editor is None or
                             editor_stats["generation_elapsed_ms"] > slowest_editor["generation_elapsed_ms"]):
            slowest_editor = {"cell_id": cell_id,
                              "generation_elapsed_ms": editor_stats["generation_elapsed_ms"],
                              "time_to_first_token_ms": editor_stats.get("time_to_first_token_ms"),
                              "decode_ms": editor_stats.get("decode_ms"),
                              "generation_tokens": editor_stats.get("generation_tokens"),
                              "model_load_ms": editor_stats.get("model_load_ms")}
        budget = row.get("context_budget") or {}
        verification = metadata.get("answer_verification") or {}
        editor_budget = verification.get("editor_context_budget") or {}
        budget_statuses[budget.get("status")] += 1
        if editor_budget:
            editor_budget_statuses[editor_budget.get("status")] += 1
        editor_actions[verification.get("intervention_action")] += 1
        if bypass and budget.get("status") != "generation_bypassed":
            failures.append(f"bypass_budget:{cell_id}")
        if not bypass and budget.get("status") != "within_budget":
            failures.append(f"draft_budget:{cell_id}")
        if editor_budget and editor_budget.get("status") != "within_budget":
            failures.append(f"editor_budget:{cell_id}")
        records.append({
            "cell_id": cell_id, "case_id": cell["case_id"], "arm": cell["arm"],
            "stratum": by_case[cell["case_id"]]["stratum"], "trial": cell["trial"],
            "answer_sha256": row["answer_sha256"], "draft_sha256": row["draft_sha256"],
            "bypass": bypass, "draft_call": not bypass, "editor_call": bool(editor_stats),
            "draft_at_cap": not bypass and draft_stats.get("generation_tokens") == 640,
            "editor_at_cap": editor_stats.get("generation_tokens") == 220,
            "editor_evidence_truncated": editor_budget.get("evidence_truncated") is True,
            "document_hits": len(trace.get("retrieved_docs") or []),
            "graph_hits": len(trace.get("graph_hits") or []),
            "ledger_seconds": row["elapsed_seconds"],
            "core_seconds": execution["turn"]["system_state"]["latency_ms"] / 1000,
            "draft_seconds": None if bypass else draft_stats["generation_elapsed_ms"] / 1000,
            "editor_seconds": editor_stats["generation_elapsed_ms"] / 1000 if editor_stats else None,
            "history_available": budget.get("history_turns_available"),
            "history_included": budget.get("history_turns_included"),
            "draft_prompt_tokens": draft_stats.get("prompt_tokens") if not bypass else None,
            "editor_prompt_tokens": editor_stats.get("prompt_tokens") if editor_stats else None,
            "draft_generation_tokens": draft_stats.get("generation_tokens") if not bypass else None,
            "editor_generation_tokens": editor_stats.get("generation_tokens") if editor_stats else None,
        })

    paired: dict[tuple[str, str], list[dict[str, Any]]] = collections.defaultdict(list)
    for item in records:
        paired[(item["case_id"], item["arm"])].append(item)
    if len(paired) != 96 or any(len(pair) != 2 or {p["trial"] for p in pair} != {1, 2}
                                for pair in paired.values()):
        failures.append("paired_trial_shape")
    answer_changed = [f"{case}:{arm}" for (case, arm), pair in paired.items()
                      if len(pair) == 2 and pair[0]["answer_sha256"] != pair[1]["answer_sha256"]]
    draft_changed = [f"{case}:{arm}" for (case, arm), pair in paired.items()
                     if len(pair) == 2 and pair[0]["draft_sha256"] != pair[1]["draft_sha256"]]

    all_stats = group_summary(records)
    ledger_total = all_stats["ledger_seconds"]["sum"]
    core_total = all_stats["core_seconds"]["sum"]
    draft_total = all_stats["draft_generation_seconds"]["sum"]
    editor_total = all_stats["editor_generation_seconds"]["sum"]
    driver_total = driver["seconds"]
    report = {
        "schema_version": "system_validation_gemma_mechanics.v1",
        "scope": "execution mechanics only; no answer grading or grader file access",
        "input": {"run_directory": str(RUN.relative_to(ROOT)),
                  "run_sha256": manifest["run_sha256"], "ledger_sha256": sha(RUN / "ledger.jsonl"),
                  "manifest_sha256": sha(RUN / "run_manifest.json"),
                  "capsule_sha256": sha(COLAB / "capsule-files.json"),
                  "driver_status_sha256": sha(COLAB / "primary-status.json")},
        "validity": {"status": "pass" if not failures else "fail", "failures": failures,
                     "completed_cells": sum(r.get("status") == "completed_execution" for r in rows),
                     "stage_receipts_per_cell": 17, "table_setup_receipts": table_receipts,
                     "source_files_checked": len(manifest["source_sha256"]),
                     "corpus_artifacts_checked": len(manifest["corpus_artifact_sha256"]),
                     "capsule_mismatches": capsule_mismatches,
                     "driver_exit_code": driver.get("exit_code"),
                     "worker_traceback_observed": "Traceback" in worker_log,
                     "loader_identity_statuses": dict(identity_statuses),
                     "model_id": manifest["model_id"], "model_revision": manifest["model_revision"],
                     "runner_sha256": manifest["runner_sha256"],
                     "table_helper_sha256": manifest["table_setup_module_sha256"],
                     "source_snapshot_commit": capsule.get("source_commit"),
                     "source_snapshot_tracked_diff_sha256": capsule.get("tracked_diff_sha256"),
                     "provisioned_model_weights_sha256": provision["models"][0]["files"]["model.safetensors"]["sha256"],
                     "model_weights_live_rehash_available": False},
        "counts": {"cells": len(records), "cases": len(by_case), "arms": list(ARMS),
                   "bypass_reasons": dict(bypass_reasons),
                   "draft_model_calls": all_stats["draft_model_calls"],
                   "editor_model_calls": all_stats["editor_model_calls"],
                   "stale_draft_generation_stats_on_bypass_cells": stale_bypass_stats,
                   "generation_fallback_rows": sum(r.get("generation_fallback") is not None for r in rows),
                   "generation_unavailable_rows": sum(r.get("generation_unavailable") is not None for r in rows),
                   "budget_statuses": dict(budget_statuses),
                   "editor_budget_statuses": dict(editor_budget_statuses),
                   "editor_evidence_truncated": all_stats["editor_evidence_truncated"],
                   "draft_at_640_tokens": all_stats["draft_at_640_tokens"],
                   "editor_at_220_tokens": all_stats["editor_at_220_tokens"],
                   "editor_actions": {str(k): v for k, v in editor_actions.items()},
                   "stage_states": dict(stage_states),
                   "history_available_included": {f"{a}/{b}": n for (a, b), n in
                                                  collections.Counter((x["history_available"], x["history_included"])
                                                                      for x in records).items()}},
        "timing": {"driver_wall_seconds": round(driver_total, 3),
                   "ledger_cell_seconds": all_stats["ledger_seconds"],
                   "core_seconds": all_stats["core_seconds"],
                   "draft_generation_seconds": all_stats["draft_generation_seconds"],
                   "editor_generation_seconds": all_stats["editor_generation_seconds"],
                   "observed_cold_model_loads": cold_loads,
                   "slowest_editor_call": slowest_editor,
                   "warm_cells_excluding_first": group_summary(records[1:])["ledger_seconds"],
                   "driver_minus_ledger_seconds": round(driver_total - ledger_total, 3),
                   "ledger_minus_core_seconds": round(ledger_total - core_total, 3),
                   "core_minus_generation_elapsed_seconds": round(core_total - draft_total - editor_total, 3),
                   "boundaries": {
                       "driver": "driver subprocess wall time, including setup, inter-cell work, polling and teardown",
                       "ledger": "run_cell execute elapsed only; excludes worker startup and most cell setup",
                       "core": "turn system_state latency_ms; includes model and non-model product work",
                       "generation": "generation_elapsed_ms for actual draft/editor calls only; excludes cold model load and other work",
                       "residual": "differences are aggregate boundary gaps, not isolated retrieval timings",
                   }},
        "by_arm": {arm: group_summary([item for item in records if item["arm"] == arm]) for arm in ARMS},
        "by_stratum": {name: group_summary([item for item in records if item["stratum"] == name])
                       for name in sorted({item["stratum"] for item in records})},
        "repeatability": {"case_arm_pairs": len(paired),
                          "different_answer_hash_pairs": answer_changed,
                          "different_draft_hash_pairs": draft_changed,
                          "non_table_pairs_with_same_answer_hash": sum(case != "sv24-08" and
                              len(pair) == 2 and pair[0]["answer_sha256"] == pair[1]["answer_sha256"]
                              for (case, _), pair in paired.items()),
                          "table_hash_difference_context": "Each table cell has an isolated import ID and derived receipt hashes; hash differences alone do not show model stochasticity."},
        "limits": ["No answer correctness or safety grades are computed here.",
                   "No peak GPU or system memory telemetry was collected during the run.",
                   "No retrieval-only duration can be inferred from aggregate timing gaps.",
                   "Generation token count equal to a configured cap is a cap-adjacent observation; stop reason is not recorded.",
                   "Cold model weights are bound by the provisioning receipt, not rehashed from this local result package."],
    }
    output = HERE / "gemma-mechanics.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    md = ["# Gemma retrieval 2×2: mechanical audit", "",
          f"Run `{manifest['run_sha256']}`: **{report['validity']['status']}** mechanical validity, "
          f"{len(records)}/192 completed cells, {table_receipts}/8 table setup receipts, "
          f"{len(failures)} audit failures. No answer grading was performed.", "",
          "## Identity and execution", "",
          f"The capsule and local checkout match {len(manifest['source_sha256'])} source and "
          f"{len(manifest['corpus_artifact_sha256'])} corpus hashes in the run manifest. "
          f"All 192 identity receipts report `verified_direct_loader` for pinned "
          f"`{manifest['model_id']}` revision `{manifest['model_revision']}`. "
          "The 80 bypass cells have no response model ID; the 112 draft calls bind a response model ID. "
          f"The driver exited 0 and reported no end drift. The provision receipt binds the "
          f"model weight SHA-256 `{report['validity']['provisioned_model_weights_sha256']}`; "
          "the transferred result contains no model weights to rehash.", "",
          f"All 192 cells have 17 stage receipts. {all_stats['draft_model_calls']} cells made a draft model call; "
          f"{all_stats['editor_model_calls']} made an editor call; {all_stats['generation_bypasses']} bypassed generation. "
          f"No generation fallback or unavailable rows were recorded. The 80 bypass rows retain the immediately "
          "preceding draft `generation_stats`; those fields are stale and excluded from model-call timing. "
          f"All 112 actual draft calls report applied seed 42 and disabled prompt cache.", "",
          "## Timing boundaries", "",
          "| Boundary | Total seconds | Mean seconds per recorded unit |", "|---|---:|---:|",
          f"| Driver wall (one run) | {driver_total:.3f} | — |",
          f"| Ledger cell elapsed (192) | {ledger_total:.3f} | {all_stats['ledger_seconds']['mean']:.3f} |",
          f"| Product core latency (192) | {core_total:.3f} | {all_stats['core_seconds']['mean']:.3f} |",
          f"| Draft generation elapsed (112 calls) | {draft_total:.3f} | {all_stats['draft_generation_seconds']['mean']:.3f} |",
          f"| Editor generation elapsed (54 calls) | {editor_total:.3f} | {all_stats['editor_generation_seconds']['mean']:.3f} |", "",
          f"The first call recorded {cold_loads[0]['model_load_seconds']:.3f}s of model loading; the other 191 "
          f"draft-stat receipts say `already_loaded` (including stale bypass receipts). "
          f"Excluding the first cell, ledger median is {report['timing']['warm_cells_excluding_first']['median']:.3f}s. "
          f"Driver minus ledger is {report['timing']['driver_minus_ledger_seconds']:.3f}s; "
          f"ledger minus core is {report['timing']['ledger_minus_core_seconds']:.3f}s; "
          f"core minus draft/editor generation elapsed is {report['timing']['core_minus_generation_elapsed_seconds']:.3f}s. "
          "These are boundary gaps, not retrieval-only measurements. The cold load sits outside generation elapsed. "
          f"The slowest editor call took {slowest_editor['generation_elapsed_ms'] / 1000:.3f}s, "
          f"including {slowest_editor['time_to_first_token_ms'] / 1000:.3f}s to first token, "
          "with no new model load recorded; this one cell materially raises the document-only total. "
          "No during-run peak memory measure is available.", "",
          "## Arms", "", "| Arm | Cells | Draft calls | Editor calls | Bypasses | Doc hits | Graph hits | Ledger total s | Ledger median s | Core total s |",
          "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for arm in ARMS:
        item = report["by_arm"][arm]
        md.append(f"| {arm} | {item['cells']} | {item['draft_model_calls']} | "
                  f"{item['editor_model_calls']} | {item['generation_bypasses']} | "
                  f"{item['document_hits']} | {item['graph_hits']} | "
                  f"{item['ledger_seconds']['sum']:.3f} | {item['ledger_seconds']['median']:.3f} | "
                  f"{item['core_seconds']['sum']:.3f} |")
    md += ["", "## Strata", "", "| Stratum | Cells | Draft calls | Editor calls | Bypasses | Ledger total s | Ledger median s |",
           "|---|---:|---:|---:|---:|---:|---:|"]
    for name, item in report["by_stratum"].items():
        md.append(f"| {name} | {item['cells']} | {item['draft_model_calls']} | "
                  f"{item['editor_model_calls']} | {item['generation_bypasses']} | "
                  f"{item['ledger_seconds']['sum']:.3f} | {item['ledger_seconds']['median']:.3f} |")
    md += ["", "## Caps, context and repeated trials", "",
           f"No draft call reported 640 generated tokens (maximum "
           f"{max(item['draft_generation_tokens'] for item in records if item['draft_call'])}). "
           f"{all_stats['editor_at_220_tokens']}/54 editor calls reported exactly the 220-token cap; "
           "the receipts do not record a stop reason, so exact-cap counts are not confirmed length stops. "
           f"All 112 draft context budgets and all {sum(editor_budget_statuses.values())} editor context budgets "
           f"report `within_budget`; {all_stats['editor_evidence_truncated']} editor budgets explicitly report "
           "evidence truncation. The 80 bypass cells have `generation_bypassed` and no counted prompt budget.", "",
           f"The fixed-history receipt pattern is {dict(report['counts']['history_available_included'])}. "
           f"Across 96 case-arm pairs, {len(answer_changed)} final and {len(draft_changed)} draft hashes changed "
           "between trials; all four changed pairs are `sv24-08` table cells with fresh per-cell import IDs "
           "and derived receipt hashes. The other 92 answer hashes match. This is a byte-repeatability "
           "observation, not a quality grade.", "",
           "The JSON report retains per-arm and per-stratum distributions, provenance checks and residual limits. "
           "No grader inputs or files were read.", ""]
    (HERE / "gemma-mechanics.md").write_text("\n".join(md))
    print(json.dumps({"status": report["validity"]["status"], "failures": failures,
                      "run_sha256": manifest["run_sha256"], "output": str(output)}, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
