#!/usr/bin/env python3
"""Read-only Gemma field-v2 mechanics audit. Never opens quality grades or gold cases.

Usage: python3 gemma-field-v2-mechanics.py --run PATH/outputs/gemma-field-v2-192
       [--collection-root PATH] [--output PATH] [--source-ref COMMIT]
       [--runner PATH] [--runner-delta-receipt JSON]
The collection root is inferred as the run directory's grandparent. Partial
collections remain incomplete evidence; no absent cell is imputed as a pass.
Field-v2 runs require a delta receipt with runner_relative_path, runner_sha256,
remote_verified_sha256, and base_capsule_sha256.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import statistics
import subprocess
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
FREEZE = "2b4028560c18def902463b4da44ef2c5c69467b1"
ARMS = ("retrieval_neither", "retrieval_document_only", "retrieval_graph_only", "retrieval_both")


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def canonical(value: Any) -> str:
    return sha_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())


def read_json(path: Path, missing: list[str]) -> Any | None:
    if not path.is_file():
        missing.append(str(path))
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        missing.append(f"{path}: {type(exc).__name__}")
        return None


def locate(explicit: Path | None, candidates: list[Path], missing: list[str]) -> tuple[Path | None, Any | None]:
    paths = [explicit] if explicit else candidates
    for path in paths:
        if path is not None and path.is_file():
            return path, read_json(path, missing)
    missing.append("one of: " + ", ".join(map(str, paths)))
    return None, None


def measure(values: list[float]) -> dict[str, float | int | None]:
    if not values:
        return {"n": 0, "sum": None, "mean": None, "median": None, "p95": None, "min": None, "max": None}
    ordered = sorted(values)
    return {"n": len(values), "sum": round(sum(values), 3), "mean": round(statistics.mean(values), 3),
            "median": round(statistics.median(values), 3),
            "p95": round(ordered[min(len(ordered)-1, (95*len(ordered)+99)//100-1)], 3),
            "min": round(ordered[0], 3), "max": round(ordered[-1], 3)}


def group(records: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "attempts": len(records), "completed": sum(x["completed"] for x in records),
        "draft_calls": sum(x["draft_call"] for x in records), "editor_calls": sum(x["editor_call"] for x in records),
        "bypasses": sum(x["bypass"] for x in records), "fallbacks": sum(x["fallback"] for x in records),
        "unavailable": sum(x["unavailable"] for x in records),
        "draft_at_640": sum(x["draft_at_cap"] for x in records),
        "editor_at_220": sum(x["editor_at_cap"] for x in records),
        "editor_evidence_truncated": sum(x["editor_evidence_truncated"] for x in records),
        "draft_history_clipped": sum(x["draft_history_clipped"] for x in records),
        "history_omitted_on_bypass": sum(x["history_omitted_on_bypass"] for x in records),
        "editor_budget_non_within": sum(x["editor_budget_non_within"] for x in records),
        "document_hits": sum(x["document_hits"] for x in records),
        "graph_hits": sum(x["graph_hits"] for x in records),
        "ledger_seconds": measure([x["ledger_seconds"] for x in records if x["ledger_seconds"] is not None]),
        "core_seconds": measure([x["core_seconds"] for x in records if x["core_seconds"] is not None]),
        "draft_generation_seconds": measure([x["draft_seconds"] for x in records if x["draft_seconds"] is not None]),
        "editor_generation_seconds": measure([x["editor_seconds"] for x in records if x["editor_seconds"] is not None]),
        "cold_model_load_seconds": measure([x["cold_seconds"] for x in records if x["cold_seconds"] is not None]),
        "draft_prompt_tokens": measure([x["draft_prompt_tokens"] for x in records if isinstance(x["draft_prompt_tokens"], (int,float))]),
        "editor_prompt_tokens": measure([x["editor_prompt_tokens"] for x in records if isinstance(x["editor_prompt_tokens"], (int,float))]),
        "draft_generation_tokens": measure([x["draft_generation_tokens"] for x in records if isinstance(x["draft_generation_tokens"], (int,float))]),
        "editor_generation_tokens": measure([x["editor_generation_tokens"] for x in records if isinstance(x["editor_generation_tokens"], (int,float))]),
    }


def git_sha(ref: str, relative: str) -> str | None:
    result = subprocess.run(["git", "show", f"{ref}:{relative}"], cwd=ROOT, capture_output=True)
    return sha_bytes(result.stdout) if result.returncode == 0 else None


def source_checks(manifest: dict[str, Any], capsule: dict[str, Any] | None, ref: str) -> dict[str, Any]:
    files = capsule.get("files", {}) if isinstance(capsule, dict) else {}
    mismatches = []
    for relative, expected in manifest.get("source_sha256", {}).items():
        frozen = git_sha(ref, relative)
        packed = (files.get(relative) or {}).get("sha256")
        if frozen != expected or packed != expected:
            mismatches.append({"path": relative, "expected": expected, "frozen_git": frozen, "capsule": packed})
    return {"frozen_ref": ref, "source_file_count": len(manifest.get("source_sha256", {})),
            "mismatches": mismatches, "capsule_source_commit": capsule.get("source_commit") if capsule else None,
            "comparison_boundary": "manifest versus frozen Git blob bytes and capsule-v2 inventory; live checkout excluded"}


def expected_field_context(raw: dict[str, Any]) -> dict[str, Any]:
    if not raw:
        return {}
    def field_text(key: str, *legacy: Any) -> str:
        if key in raw:
            return str(raw[key] or "")
        return next((str(value) for value in legacy if value), "")
    result = {
        "crop": field_text("crop", raw.get("crop_current")),
        "region": field_text("region", raw.get("region_text")),
        "jurisdiction": field_text("jurisdiction", raw.get("province_state"), raw.get("province"), raw.get("country")),
    }
    if "enable_public_adapters" in raw:
        result["enable_public_adapters"] = raw["enable_public_adapters"]
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--collection-root", type=Path)
    parser.add_argument("--capsule", type=Path)
    parser.add_argument("--runner", type=Path, help="Runner file used by this manifest; defaults by schema")
    parser.add_argument("--runner-delta-receipt", type=Path, help="Required for field-v2 runner absent from base capsule")
    parser.add_argument("--status", type=Path)
    parser.add_argument("--driver-log", type=Path)
    parser.add_argument("--provision", type=Path)
    parser.add_argument("--source-ref", default=FREEZE)
    parser.add_argument("--output", type=Path, default=HERE / "gemma-field-v2-mechanics.json")
    args = parser.parse_args()
    run = args.run.resolve()
    collection = (args.collection_root or run.parent.parent).resolve()
    missing: list[str] = []
    failures: list[str] = []
    manifest = read_json(run / "run_manifest.json", missing)
    plan = read_json(run / "cell_plan.json", missing)
    if not isinstance(manifest, dict) or not isinstance(plan, list):
        raise SystemExit("run manifest and cell plan are required")
    capsule_path, capsule = locate(args.capsule, [collection / "capsule-files.json",
        ROOT / "outputs/system-validation-20260928/colab/capsule-files-v2.json"], missing)
    status_path, status = locate(args.status, [collection / "gemma-field-v2-status.json",
        collection / "primary-status.json"], missing)
    provision_path, provision = locate(args.provision, [collection / "system-validation-provision.json",
        ROOT / "outputs/system-validation-20260928/colab/results-v1/system-validation-provision.json"], missing)
    runtime = read_json(ROOT / "outputs/system-validation-20260928/runner/runtime_cases.json", missing)
    cases = {x["id"]: x for x in (runtime or {}).get("cases", [])}
    if canonical({k:v for k,v in manifest.items() if k not in {"run_sha256", "runtime_path", "runtime_digest_path",
        "model_config_path", "rag_source_path", "rag_profile_path", "table_setup_module_path"}}) != manifest.get("run_sha256"):
        failures.append("manifest_identity")
    if canonical(plan) != manifest.get("cells_sha256") or len(plan) != 192 or manifest.get("cell_count") != 192:
        failures.append("plan_identity_or_shape")
    if manifest.get("schema_version") != "system_validation_retrieval_2x2_field_delivery_run.v2" or manifest.get("field_adapter_version") != "stored_field_to_product_context.v2":
        failures.append("field_v2_manifest_contract")
    if (manifest.get("mock"), manifest.get("model_backend"), manifest.get("model_id"),
        manifest.get("model_revision")) != (False, "mlx", "mlx-community/gemma-4-e2b-it-4bit",
        "238767527555cb75a05732a84dff5d6ba0dd6809"):
        failures.append("model_or_backend_declaration")
    if ({x["arm"] for x in plan} != set(ARMS) or len({x["case_id"] for x in plan}) != 24
        or {x["trial"] for x in plan} != {1,2}
        or len({(x["case_id"],x["arm"],x["trial"]) for x in plan}) != 192
        or any(sum(x["arm"]==arm for x in plan)!=48 for arm in ARMS)):
        failures.append("arm_case_trial_shape")
    source = source_checks(manifest, capsule, args.source_ref)
    if source["mismatches"]:
        failures.append("frozen_source_or_capsule_mismatch")
    if source["source_file_count"] != 147:
        failures.append("frozen_source_file_count")
    if len(manifest.get("corpus_artifact_sha256", {})) != 14:
        failures.append("frozen_corpus_artifact_count")
    field_v2 = manifest.get("schema_version") == "system_validation_retrieval_2x2_field_delivery_run.v2"
    default_runner = ("run_retrieval_2x2_field_v2.py" if field_v2 else "run_retrieval_2x2.py")
    runner_path = (args.runner or ROOT / "outputs/system-validation-20260928/runner" / default_runner).resolve()
    runner_relative = str(runner_path.relative_to(ROOT)) if runner_path.is_relative_to(ROOT) else None
    runner_local_hash = sha(runner_path) if runner_path.is_file() else None
    runner_capsule_hash = ((capsule or {}).get("files", {}).get(runner_relative or "") or {}).get("sha256")
    delta_path, delta = locate(args.runner_delta_receipt,
        [collection / "field-v2-runner-delta.json"], missing)
    base_capsule_summary = read_json(ROOT / "outputs/system-validation-20260928/colab/capsule-summary-v2.json", missing) if field_v2 else None
    if field_v2:
        if delta is None:
            missing.append("field-v2 runner needs --runner-delta-receipt")
        elif (delta.get("runner_relative_path") != runner_relative
              or delta.get("runner_sha256") != manifest.get("runner_sha256")
              or delta.get("remote_verified_sha256") != manifest.get("runner_sha256")
              or delta.get("base_capsule_sha256") != (base_capsule_summary or {}).get("sha256")):
            failures.append("runner_delta_receipt")
    elif runner_capsule_hash != manifest.get("runner_sha256"):
        failures.append("runner_capsule_hash")
    if runner_local_hash != manifest.get("runner_sha256"):
        failures.append("runner_local_hash")
    bindings = {
        "runtime_sha256": ROOT / "outputs/system-validation-20260928/runner/runtime_cases.json",
        "runtime_digest_sha256": ROOT / "outputs/system-validation-20260928/runner/runtime_cases.json.sha256",
        "table_setup_module_sha256": ROOT / "outputs/system-validation-20260928/cohort/table_setup.py",
        "model_config_sha256": ROOT / "configs/model.yaml",
        "rag_source_sha256": ROOT / "configs/rag.yaml",
    }
    binding_checks = {}
    binding_checks["runner_sha256"] = {"expected":manifest.get("runner_sha256"),"local":runner_local_hash,
        "capsule":runner_capsule_hash,"runner_relative_path":runner_relative,
        "delta_receipt_path":str(delta_path) if delta_path else None,
        "delta_receipt_sha256":sha(delta_path) if delta_path and delta_path.is_file() else None}
    for key, path in bindings.items():
        actual = sha(path) if path.is_file() else None
        packed = ((capsule or {}).get("files", {}).get(str(path.relative_to(ROOT))) or {}).get("sha256")
        binding_checks[key] = {"expected": manifest.get(key), "local": actual, "capsule": packed}
        if actual != manifest.get(key) or packed != manifest.get(key):
            failures.append(f"binding:{key}")
    if (run / "rag_public_offline.yaml").is_file() and sha(run / "rag_public_offline.yaml") != manifest.get("rag_public_profile_sha256"):
        failures.append("rag_profile_hash")
    elif not (run / "rag_public_offline.yaml").is_file():
        missing.append(str(run / "rag_public_offline.yaml"))
    corpus_mismatches = []
    for relative, expected in manifest.get("corpus_artifact_sha256", {}).items():
        path = ROOT / relative
        actual = sha(path) if path.is_file() else None
        packed = ((capsule or {}).get("files", {}).get(relative) or {}).get("sha256")
        if actual != expected or packed != expected:
            corpus_mismatches.append({"path":relative,"expected":expected,"local":actual,"capsule":packed})
    if corpus_mismatches:
        failures.append("corpus_hash_mismatch")
    pilot = ROOT / "data/eval/field_data_pilot_v1"
    pilot_manifest = read_json(pilot / "manifest.json", missing) or {}
    bundle = next((x for x in pilot_manifest.get("bundles", []) if x.get("id")=="akron-01"), {})
    table_hashes = {"pilot_manifest_sha256": sha(pilot / "manifest.json") if (pilot / "manifest.json").is_file() else None,
        "pilot_fixture_sha256": sha(pilot / bundle["fixture_path"]) if bundle.get("fixture_path") and (pilot / bundle["fixture_path"]).is_file() else None,
        "pilot_mapping_sha256": canonical(bundle["mapping"]) if "mapping" in bundle else None}
    if table_hashes != manifest.get("table_dependencies_sha256"):
        failures.append("table_dependency_hashes")
    if capsule:
        for relative, expected in {
            "data/eval/field_data_pilot_v1/manifest.json":table_hashes["pilot_manifest_sha256"],
            "data/eval/field_data_pilot_v1/fixtures/akron-01.csv":table_hashes["pilot_fixture_sha256"],
        }.items():
            if ((capsule.get("files", {}).get(relative) or {}).get("sha256")) != expected:
                failures.append(f"capsule_table:{relative}")
    if status and (status.get("status"),status.get("exit_code")) != ("completed",0):
        failures.append("driver_not_completed_zero") if status.get("status") not in {"running", "preparing"} else None
    provision_model = next((item for item in (provision or {}).get("models", [])
        if item.get("model_id")==manifest["model_id"]), None)
    if provision and (provision_model is None or provision_model.get("revision")!=manifest["model_revision"]):
        failures.append("provisioned_model_identity")
    gpu_path, gpu_provision = locate(None, [collection / "system-validation-provision.json",
        ROOT / "outputs/system-validation-20260928/colab/results-v1/system-validation-provision.json"], missing)
    driver_log_path = args.driver_log or collection / "gemma-field-v2-driver.log"
    end_receipt = None
    if driver_log_path.is_file():
        for line in reversed(driver_log_path.read_text().splitlines()):
            try: item=json.loads(line)
            except json.JSONDecodeError: continue
            if isinstance(item,dict) and "drift_error" in item and "completed_cells" in item:
                end_receipt=item;break
        if status and status.get("status")=="completed" and (not end_receipt or end_receipt.get("drift_error") is not None
            or end_receipt.get("status")!="complete" or end_receipt.get("run_sha256")!=manifest["run_sha256"]):
            failures.append("driver_end_drift_receipt")
    driver_log_available = driver_log_path.is_file()
    worker_log_path=run/"worker.log"
    if worker_log_path.is_file():
        if "Traceback" in worker_log_path.read_text(): failures.append("worker_traceback")
    else: missing.append(str(worker_log_path))

    ledger = run / "ledger.jsonl"
    rows = []
    if ledger.is_file():
        for line_no, line in enumerate(ledger.read_text().splitlines(),1):
            if not line.strip(): continue
            try: rows.append(json.loads(line))
            except json.JSONDecodeError: missing.append(f"ledger_unparseable_line:{line_no}")
    else: missing.append(str(ledger))
    plan_by_id = {x["cell_id"]:x for x in plan}
    plan_index = {x["cell_id"]:i for i,x in enumerate(plan)}
    seen = set()
    records=[]
    stage_states=collections.Counter(); identity_statuses=collections.Counter(); budget_statuses=collections.Counter(); editor_budget_statuses=collections.Counter()
    error_rows=[]; table_receipts=0
    for row in rows:
        cell_id = row.get("cell_id")
        if cell_id in seen: failures.append(f"duplicate_ledger_cell:{cell_id}")
        seen.add(cell_id)
        cell = plan_by_id.get(cell_id)
        if cell is None:
            failures.append(f"unplanned_cell:{cell_id}"); continue
        case = cases.get(cell["case_id"])
        if case is None or row.get("case_sha256") != canonical(case): failures.append(f"case_identity:{cell_id}")
        if (row.get("run_sha256") != manifest.get("run_sha256") or row.get("arm") != cell["arm"]
            or row.get("trial") != cell["trial"] or row.get("cell_index") != plan_index[cell_id]):
            failures.append(f"ledger_identity:{cell_id}")
        completed = row.get("status") == "completed_execution"
        if not completed:
            error_rows.append({"cell_id":cell_id,"status":row.get("status"),"error":row.get("error")})
        execution_path = run / str(row.get("cell_result") or f"cells/{cell_id}/execution.json")
        envelope = read_json(execution_path, missing) if completed else None
        execution = (envelope or {}).get("execution") if isinstance(envelope,dict) else None
        trace = ((execution or {}).get("turn") or {}).get("trace") or {}
        metadata = trace.get("metadata") or {}
        stages = (execution or {}).get("stage_receipts") or []
        if completed:
            configuration=(envelope or {}).get("component_configuration") or {}
            components=configuration.get("components") or {}
            expected_documents=cell["arm"] in {"retrieval_document_only","retrieval_both"}
            expected_graph=cell["arm"] in {"retrieval_graph_only","retrieval_both"}
            if (configuration.get("configuration_id")!=cell["arm"]
                or components.get("document_retrieval") is not expected_documents
                or components.get("graph_retrieval") is not expected_graph):
                failures.append(f"component_control:{cell_id}")
            if len(stages)!=17 or row.get("stage_receipt_count")!=17 or len({x.get("stage_id") for x in stages})!=17:
                failures.append(f"stage_receipts:{cell_id}")
            stage_states.update(x.get("state") for x in stages)
            answer_stages = execution.get("answer_stages") or {}
            for key, rowkey in (("draft","draft_sha256"),("post_verification","post_verification_sha256"),("final","answer_sha256")):
                item=answer_stages.get(key) or {}
                if item.get("sha256")!=row.get(rowkey) or sha_bytes(str(item.get("text","")).encode())!=item.get("sha256"):
                    failures.append(f"answer_stage:{cell_id}:{key}")
            if canonical(trace.get("prompt_messages") or [])!=row.get("prompt_sha256"):
                failures.append(f"prompt_hash:{cell_id}")
            if row.get("quality_assessment")!="ungraded" or row.get("claim_eligible") is not False:
                failures.append(f"claim_boundary:{cell_id}")
            if cell["arm"] in {"retrieval_neither","retrieval_graph_only"} and trace.get("retrieved_docs"):
                failures.append(f"disabled_documents:{cell_id}")
            if cell["arm"] in {"retrieval_neither","retrieval_document_only"} and trace.get("graph_hits"):
                failures.append(f"disabled_retrieval:{cell_id}")
            if cell["case_id"]=="sv24-08":
                setup_path=run/"cells"/cell_id/"setup_receipt.json"
                setup=read_json(setup_path,missing)
                table_receipts += int(setup is not None)
                if setup and (canonical(setup)!=row.get("setup_receipt_sha256") or setup.get("status")!="reviewed_private_import_committed"
                    or setup.get("manifest_sha256")!=table_hashes["pilot_manifest_sha256"]
                    or setup.get("fixture_sha256")!=table_hashes["pilot_fixture_sha256"]
                    or setup.get("pilot_mapping_sha256")!=table_hashes["pilot_mapping_sha256"]
                    or setup.get("committed_source_sha256")!=table_hashes["pilot_fixture_sha256"]
                    or setup.get("committed_row_count")!=13 or setup.get("stored_count_value")!=13):
                    failures.append(f"table_setup:{cell_id}")
            elif row.get("setup_receipt_sha256") is not None:
                failures.append(f"unexpected_table_setup:{cell_id}")
        identity=row.get("model_identity") or {}
        identity_statuses[identity.get("status")]+=1
        bypass=bool(row.get("generation_bypass"))
        fallback=bool(row.get("generation_fallback"))
        unavailable=bool(row.get("generation_unavailable"))
        actual_draft=completed and not (bypass or fallback or unavailable)
        draft_stats=row.get("generation_stats") or {}
        verification=metadata.get("answer_verification") or {}
        editor_stats=row.get("verification_generation_stats") or {}
        editor_output=verification.get("editor_output")
        actual_editor=completed and editor_output is not None and bool(editor_stats)
        if completed and field_v2:
            delivery=(envelope or {}).get("field_delivery_receipt") or {}
            delivery_file=read_json(run/"cells"/cell_id/"field_delivery.json",missing)
            if (not delivery or delivery!=delivery_file
                or canonical(delivery)!=row.get("field_delivery_receipt_sha256")
                or delivery.get("raw_source_field_record")!=(case or {}).get("field_context")
                or canonical(delivery.get("raw_source_field_record"))!=delivery.get("raw_source_field_record_sha256")
                or canonical(delivery.get("delivered_field_context"))!=delivery.get("delivered_field_context_sha256")
                or ((delivery.get("observed_delivery") or {}).get("compiled_field")
                    != ((metadata.get("field_context_compiler") or {}).get("field") or {}))):
                failures.append(f"field_delivery_receipt:{cell_id}")
            if not delivery.get("table_setup_override") and delivery.get("delivered_field_context")!=expected_field_context((case or {}).get("field_context") or {}):
                failures.append(f"field_projection:{cell_id}")
            prompt_status=(delivery.get("observed_delivery") or {}).get("generation_prompt_status")
            if not delivery.get("table_setup_override") and prompt_status != (
                "canonical_compiler_block_in_generation_prompt" if actual_draft else "not_applicable_no_generation"
            ):
                failures.append(f"field_generation_prompt_status:{cell_id}")
            if actual_draft and not delivery.get("table_setup_override"):
                prompt="\n".join(str(item.get("content") or "") for item in trace.get("prompt_messages") or [])
                expected_fields=((metadata.get("field_context_compiler") or {}).get("field") or {})
                if ("Compiled field context (source-bound):" not in prompt
                    or any(f"{key.capitalize()}: {value}" not in prompt for key,value in expected_fields.items()
                        if key in {"crop","region","jurisdiction"})
                    or (delivery.get("observed_delivery") or {}).get("generation_prompt_sha256")
                        != canonical(trace.get("prompt_messages") or [])):
                    failures.append(f"actual_field_prompt:{cell_id}")
        if completed:
            if (identity.get("backend")!="mlx_local" or identity.get("status")!="verified_direct_loader"
                or identity.get("configured_model_id")!=manifest["model_id"]
                or identity.get("configured_model_revision")!=manifest["model_revision"]
                or (actual_draft and identity.get("response_model_id")!=manifest["model_id"])
                or (not actual_draft and identity.get("response_model_id") is not None)
                or identity.get("verification_errors")):
                failures.append(f"loader_identity:{cell_id}")
        if actual_draft and not draft_stats: failures.append(f"missing_draft_stats:{cell_id}")
        if completed and editor_output is not None and not editor_stats:
            failures.append(f"editor_output_without_stats:{cell_id}")
        if actual_editor and (not editor_stats or (editor_stats.get("seed_application") or {}).get("status")!="applied"):
            failures.append(f"editor_stats:{cell_id}")
        budget=row.get("context_budget") or {}
        editor_budget=verification.get("editor_context_budget") or {}
        budget_statuses[budget.get("status")]+=1
        if editor_budget: editor_budget_statuses[editor_budget.get("status")]+=1
        records.append({
            "cell_id":cell_id,"case_id":cell["case_id"],"arm":cell["arm"],"trial":cell["trial"],
            "stratum":case.get("stratum") if case else None,"completed":completed,"status":row.get("status"),
            "answer_sha256":row.get("answer_sha256"),"draft_sha256":row.get("draft_sha256"),
            "bypass":bypass,"fallback":fallback,"unavailable":unavailable,
            "draft_call":actual_draft,"editor_call":actual_editor,
            "draft_at_cap":actual_draft and draft_stats.get("generation_tokens")==640,
            "editor_at_cap":actual_editor and editor_stats.get("generation_tokens")==220,
            "editor_evidence_truncated":editor_budget.get("evidence_truncated") is True,
            "draft_history_clipped":bool(actual_draft and (budget.get("history_turns_omitted") or budget.get("history_older_omitted_count"))),
            "history_omitted_on_bypass":bool(bypass and (budget.get("history_turns_omitted") or budget.get("history_older_omitted_count"))),
            "editor_budget_non_within":bool(editor_budget and editor_budget.get("status")!="within_budget"),
            "document_hits":len(trace.get("retrieved_docs") or []),"graph_hits":len(trace.get("graph_hits") or []),
            "ledger_seconds":row.get("elapsed_seconds") if isinstance(row.get("elapsed_seconds"),(int,float)) else None,
            "core_seconds":((execution or {}).get("turn") or {}).get("system_state",{}).get("latency_ms",None)/1000 if isinstance((((execution or {}).get("turn") or {}).get("system_state") or {}).get("latency_ms"),(int,float)) else None,
            "draft_seconds":draft_stats.get("generation_elapsed_ms")/1000 if actual_draft and isinstance(draft_stats.get("generation_elapsed_ms"),(int,float)) else None,
            "editor_seconds":editor_stats.get("generation_elapsed_ms")/1000 if actual_editor and isinstance(editor_stats.get("generation_elapsed_ms"),(int,float)) else None,
            "cold_seconds":draft_stats.get("model_load_ms")/1000 if actual_draft and isinstance(draft_stats.get("model_load_ms"),(int,float)) else None,
            "history_available":budget.get("history_turns_available"),"history_included":budget.get("history_turns_included"),
            "draft_prompt_tokens":draft_stats.get("prompt_tokens") if actual_draft else None,
            "editor_prompt_tokens":editor_stats.get("prompt_tokens") if actual_editor else None,
            "draft_generation_tokens":draft_stats.get("generation_tokens") if actual_draft else None,
            "editor_generation_tokens":editor_stats.get("generation_tokens") if actual_editor else None,
        })
    planned_ids=set(plan_by_id)
    missing_cells=sorted(planned_ids-seen)
    if len(rows)==192 and table_receipts!=8:
        failures.append("table_setup_receipt_count")
    pairs=collections.defaultdict(list)
    for item in records:
        if item["completed"]: pairs[(item["case_id"],item["arm"])].append(item)
    answer_changed=[];draft_changed=[]
    for (case,arm), pair in pairs.items():
        if len(pair)==2:
            if pair[0]["answer_sha256"]!=pair[1]["answer_sha256"]:answer_changed.append(f"{case}:{arm}")
            if pair[0]["draft_sha256"]!=pair[1]["draft_sha256"]:draft_changed.append(f"{case}:{arm}")
    overall=group(records)
    def diff(a:Any,b:Any)->float|None:
        return round(a-b,3) if isinstance(a,(int,float)) and isinstance(b,(int,float)) else None
    driver_seconds=(status or {}).get("seconds")
    ledger_seconds=overall["ledger_seconds"]["sum"]
    core_seconds=overall["core_seconds"]["sum"]
    draft_seconds=overall["draft_generation_seconds"]["sum"]
    editor_seconds=overall["editor_generation_seconds"]["sum"]
    report={
        "schema_version":"system_validation_gemma_field_v2_mechanics.v1",
        "scope":"mechanics and identity only; no grading, gold, or quality files read",
        "input":{"run":str(run),"run_sha256":manifest.get("run_sha256"),
            "manifest_sha256":sha(run/"run_manifest.json"),"ledger_sha256":sha(ledger) if ledger.is_file() else None,
            "capsule_path":str(capsule_path) if capsule_path else None,"capsule_sha256":sha(capsule_path) if capsule_path else None,
            "status_path":str(status_path) if status_path else None,"provision_path":str(provision_path) if provision_path else None},
        "validity":{"status":"fail" if failures else "incomplete" if missing or missing_cells or len(rows)<192
            or overall["completed"]<192 or not status or status.get("status")!="completed" else "pass",
            "failures":failures,"missing_inputs":missing,"missing_cell_ids":missing_cells,
            "planned_cells":len(plan),"ledger_attempts":len(rows),"completed_cells":overall["completed"],
            "error_rows":error_rows,"table_setup_receipts":table_receipts,
            "source":source,"bindings":binding_checks,"corpus_mismatches":corpus_mismatches,
            "driver_status":status,"loader_identity_statuses":dict(identity_statuses),
            "provisioned_model_id":(provision_model or {}).get("model_id"),
            "provisioned_model_revision":(provision_model or {}).get("revision"),
            "provisioned_snapshot":(provision_model or {}).get("snapshot"),
            "provisioned_file_hashes":(provision_model or {}).get("files"),
            "gpu_provision_path":str(gpu_path) if gpu_path else None,
            "gpu_probe":(gpu_provision or {}).get("gpu_probe"),
            "driver_end_receipt":end_receipt,
            "driver_log_available":driver_log_available,
            "end_drift_evidence":"direct_driver_log_receipt" if end_receipt else
                "inferred_from_exit_zero_and_runner_return_contract" if status and status.get("exit_code")==0 else "unavailable",
            "model_weights_live_rehash_available":False},
        "counts":{"arms":list(ARMS),"cases":len(cases),"by_status":dict(collections.Counter(x["status"] for x in records)),
            "planned_by_arm":dict(collections.Counter(x["arm"] for x in plan)),
            "attempted_by_arm":dict(collections.Counter(x["arm"] for x in records)),
            "missing_by_arm":dict(collections.Counter(plan_by_id[x]["arm"] for x in missing_cells)),
            "planned_by_stratum":dict(collections.Counter(cases[x["case_id"]]["stratum"] for x in plan if x["case_id"] in cases)),
            "draft_calls":overall["draft_calls"],"editor_calls":overall["editor_calls"],"bypasses":overall["bypasses"],
            "stale_generation_stats_on_bypass":sum(bool(x.get("generation_bypass") and x.get("generation_stats")) for x in rows),
            "fallbacks":overall["fallbacks"],"unavailable":overall["unavailable"],
            "draft_at_640":overall["draft_at_640"],"editor_at_220":overall["editor_at_220"],
            "budget_statuses":{str(k):v for k,v in budget_statuses.items()},
            "editor_budget_statuses":{str(k):v for k,v in editor_budget_statuses.items()},
            "editor_evidence_truncated":overall["editor_evidence_truncated"],
            "draft_history_clipped":overall["draft_history_clipped"],
            "history_omitted_on_bypass":overall["history_omitted_on_bypass"],
            "editor_budget_non_within":overall["editor_budget_non_within"],
            "stage_states":{str(k):v for k,v in stage_states.items()},
            "history_available_included":{f"{a}/{b}":n for (a,b),n in collections.Counter((x["history_available"],x["history_included"]) for x in records).items()}},
        "timing":{"driver_wall_seconds":driver_seconds,"ledger_cell_seconds":overall["ledger_seconds"],
            "core_seconds":overall["core_seconds"],"draft_generation_seconds":overall["draft_generation_seconds"],
            "editor_generation_seconds":overall["editor_generation_seconds"],
            "cold_model_load_seconds":overall["cold_model_load_seconds"],
            "warm_cells_excluding_first":group(records[1:])["ledger_seconds"],
            "driver_minus_ledger_seconds":diff(driver_seconds,ledger_seconds),
            "ledger_minus_core_seconds":diff(ledger_seconds,core_seconds),
            "core_minus_generation_elapsed_seconds":diff(core_seconds,draft_seconds+editor_seconds) if draft_seconds is not None and editor_seconds is not None else None,
            "boundary":"Ledger is run_cell elapsed; core is turn latency; model times are only actual completed draft/editor calls. Gaps are not retrieval-only time."},
        "by_arm":{arm:group([x for x in records if x["arm"]==arm]) for arm in ARMS},
        "by_stratum":{s:group([x for x in records if x["stratum"]==s]) for s in sorted({x["stratum"] for x in records if x["stratum"]})},
        "by_arm_stratum":{arm:{s:group([x for x in records if x["arm"]==arm and x["stratum"]==s])
            for s in sorted({x["stratum"] for x in records if x["stratum"]})} for arm in ARMS},
        "repeatability":{"complete_case_arm_pairs":sum(len(x)==2 for x in pairs.values()),
            "different_answer_hash_pairs":sorted(answer_changed),"different_draft_hash_pairs":sorted(draft_changed),
            "table_case_import_ids_can_change_hashes_without_model_stochasticity":True},
        "cell_records":records,
        "limits":["No answer correctness or safety grade is inferred.","No during-run peak memory is available.",
            "No retrieval-only duration is isolated.","At-cap token counts do not prove a length stop without stop reason.",
            "A provisioning hash is not a rehash of model weights from this local result package."],
    }
    if not driver_log_available:
        report["limits"].append("No standalone driver log was collected; end drift status is inferred from exit 0 and the frozen runner's return contract, not a directly observed log line.")
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"status":report["validity"]["status"],"attempts":len(rows),"completed":overall["completed"],
        "failures":len(failures),"missing_cells":len(missing_cells),"output":str(args.output)},sort_keys=True))
    if failures:raise SystemExit(1)

if __name__=="__main__":main()
