"""Audit a mock ledger for setup and receipt fidelity, without grading answers."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    root = args.run_dir.resolve()
    manifest = json.loads((root / "run_manifest.json").read_text(encoding="utf-8"))
    plan = json.loads((root / "cell_plan.json").read_text(encoding="utf-8"))
    rows = [json.loads(line) for line in (root / "ledger.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()]
    failures = []
    history_prompt_counts = Counter()
    counts = Counter(row.get("status") for row in rows)
    if not manifest["mock"]:
        failures.append("run_is_not_mock")
    if len(plan) != 192 or len(rows) != len(plan):
        failures.append("incomplete_192_cell_plan")
    if sha256(Path(manifest["runtime_path"])) != manifest["runtime_sha256"]:
        failures.append("runtime_input_hash_drift")
    for relative, expected in manifest["source_sha256"].items():
        if sha256(REPO / relative) != expected:
            failures.append(f"source_hash_drift:{relative}")
    for relative, expected in manifest["corpus_artifact_sha256"].items():
        if sha256(REPO / relative) != expected:
            failures.append(f"corpus_hash_drift:{relative}")
    helper = manifest.get("table_setup_module_path")
    if helper and sha256(Path(helper)) != manifest["table_setup_module_sha256"]:
        failures.append("table_setup_hash_drift")
    for index, row in enumerate(rows):
        if row.get("cell_id") != plan[index]["cell_id"] or row.get("cell_index") != index:
            failures.append(f"plan_prefix_mismatch:{index}")
        if row.get("run_sha256") != manifest["run_sha256"]:
            failures.append(f"run_identity_mismatch:{index}")
        if row.get("status") != "completed_execution":
            failures.append(f"noncompleted_cell:{row.get('cell_id')}:{row.get('status')}")
            continue
        result = json.loads((root / row["cell_result"]).read_text(encoding="utf-8"))
        execution = result["execution"]
        trace = execution["turn"]["trace"]
        receipts = {item["stage_id"]: item for item in execution["stage_receipts"]}
        if len(receipts) != 17 or execution["answer_stages"]["final"]["text"] != execution["answer"]:
            failures.append(f"execution_receipt_mismatch:{row['cell_id']}")
        if row["arm"] in {"retrieval_neither", "retrieval_graph_only"} and trace["retrieved_docs"]:
            failures.append(f"disabled_documents_present:{row['cell_id']}")
        if row["arm"] in {"retrieval_neither", "retrieval_document_only"} and trace["graph_hits"]:
            failures.append(f"disabled_graph_present:{row['cell_id']}")
        if row["case_id"] == "sv24-08":
            setup = json.loads((root / "cells" / row["cell_id"] / "setup_receipt.json").read_text(encoding="utf-8"))
            if (setup.get("status") != "reviewed_private_import_committed"
                    or setup.get("stored_count_value") != setup.get("committed_row_count")
                    or not row.get("setup_receipt_sha256")):
                failures.append(f"table_setup_mismatch:{row['cell_id']}")
        if row["case_id"] in {"sv24-21", "sv24-22", "sv24-23", "sv24-24"}:
            history_prompt_counts[json.dumps(row["context_budget"].get("history_turns_included"))] += 1
    proof = {
        "schema_version": "system_validation_mock_preflight_audit.v1",
        "run_sha256": manifest["run_sha256"],
        "ledger_sha256": sha256(root / "ledger.jsonl"),
        "cell_count": len(rows),
        "status_counts": dict(counts),
        "history_turns_in_prompt_counts": dict(history_prompt_counts),
        "table_setup_cells": sum(row.get("case_id") == "sv24-08" and row.get("status") == "completed_execution"
                                 for row in rows),
        "claim_eligible": False,
        "quality_assessment": "not_performed",
        "failures": failures,
        "status": "pass" if not failures else "fail",
    }
    (root / "preflight_proof.json").write_text(json.dumps(proof, indent=2, sort_keys=True) + "\n",
                                                encoding="utf-8")
    print(json.dumps(proof, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
