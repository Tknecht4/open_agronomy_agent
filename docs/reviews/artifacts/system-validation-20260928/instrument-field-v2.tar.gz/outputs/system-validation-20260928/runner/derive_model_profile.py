"""Create an explicit diagnostic output-cap profile without editing the active one."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[3]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT / "configs/model.yaml")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-tokens", type=int, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f"refusing to overwrite diagnostic profile: {output}")
    config = yaml.safe_load(source.read_text(encoding="utf-8"))
    if not isinstance(config, dict) or config.get("prompt_cache_enabled") is not False:
        raise ValueError("source profile must have prompt caching disabled")
    if (config.get("context_management") or {}).get("context_limit_tokens") != 8192:
        raise ValueError("source profile needs the fixed 8192-token context")
    original_cap = int(config.get("max_tokens") or 0)
    original_serving_cap = config.get("serving_max_tokens")
    if args.max_tokens < original_cap or args.max_tokens > 2048:
        raise ValueError("diagnostic output cap must be between source cap and 2048")
    verifier = config.get("answer_verification") or {}
    model_id = config.get("serving_model_id") or config.get("model_id")
    if (not isinstance(verifier, dict) or verifier.get("enabled") is not True
            or verifier.get("model_id") != model_id
            or verifier.get("model_revision") != config.get("model_revision")):
        raise ValueError("source draft/editor snapshot mismatch")
    parent_sha = digest(source)
    config["max_tokens"] = args.max_tokens
    config["serving_max_tokens"] = args.max_tokens
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    receipt = {
        "schema_version": "system_validation_diagnostic_model_profile.v1",
        "source_path": str(source),
        "source_sha256": parent_sha,
        "output_path": str(output),
        "output_sha256": digest(output),
        "changed_settings": {"max_tokens": [original_cap, args.max_tokens],
                             "serving_max_tokens": [original_serving_cap, args.max_tokens]},
        "model_id": model_id,
        "model_revision": config["model_revision"],
        "context_limit_tokens": 8192,
        "prompt_cache_enabled": False,
    }
    output.with_suffix(output.suffix + ".receipt.json").write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()
